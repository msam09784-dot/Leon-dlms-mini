/*
  LEON AUDIO - DLMS MINI 2 IN / 4 OUT - v0.9.4 BOOT LOGO ONLY
  v0.9.2: redraw the complete parameter page and graph immediately when the DSP channel changes; also refresh all EQ values when the selected band changes. No DSP/audio algorithms, routing, preset format, or GPIO changes. v0.9.1: boot branding changed to LEON AUDIO with small by Leon Production byline; EQ, CROSSOVER, DELAY and COMPRESSOR page titles no longer include INPUT. v0.9.0: faster preset SAVE/LOAD/RESET and preset-page rendering. Slot saved-state is cached after boot scan/save/load instead of reading five JSON files on every redraw; atomic writes perform one read-back verification; save/load avoid redundant full active-state writes when the preset pointer can restore the slot; load no longer blocks the UI for up to 400 ms. v0.8.9 ultra-light compressor remains unchanged. Gain/envelope detector updates once per 2 audio samples (24 kHz control rate), using the peak of each pair; attack/release coefficients are recalculated for the 2-sample interval. Compressor gain LUT reduced from 513 to 257 points (half the table RAM/build work) with interpolation retained. Preset SAVE/LOAD/RESET YA-BATAL dialogs and v0.8.6 power-cycle preset persistence are retained.
  UI uses the native 160x128 landscape coordinates of the ST7735S panel.
  Based on v0.3.8 audio/DSP engine. Local TFT UI opens on the 3x3 app grid; configuration pages show a left-side graph and right-side rotary edit list, 5-second LEON AUDIO boot splash, editable channel names (IN 1/IN 2 and OUT 1..4 defaults), fixed rotary increments with no Slow/Fast menu, independent named presets, HPF/LPF values and shared crossover bypass; RTA buffers monitor processed input L/R only, allocated in PSRAM; capture runs only on the RTA page.
  Target: ESP32-S3 N16R8 (16 MB Flash / 8 MB PSRAM)
  Audio: 48 kHz, PCM1808 stereo ADC, 2x PCM5102 stereo DAC.

  TFT: 1.8 inch ST7735S SPI, 160x128 landscape.
  Rotary: mechanical 5-pin encoder (A, B, COM + two switch contacts).

  Required libraries (Arduino Library Manager):
    - Adafruit GFX Library
    - Adafruit ST7735 and ST7789 Library
    - ArduinoJson 7.x
  ESP32 core: Espressif Arduino-ESP32 3.x.

  R11: BACK on a parameter page returns to the 3x3 app menu, not the live LEVEL MONITOR dashboard. Long-press from a parameter page also returns to the app menu.
  R10: all continuous numeric parameters use character-by-character digit editing. Keep all digits visible and draw an underscore cursor below the active digit. Applies to gain, EQ gain/Q/frequency, HPF/LPF, delay, threshold, ratio, attack and release. Temporary out-of-range digit combinations are allowed while editing; final value is clamped safely when editing ends.
  R10b: while editing discrete selectors such as CH, band, ON/OFF, combined filter+slope, phase and preset slot, preserve the complete text value and underline the active value; never replace its first character with an underscore.
  R9: draw a visible rounded outline around EVERY parameter row in all right-side edit panels. The selected row is cyan, and turns yellow while editing; unselected rows use the subtle panel edge. This makes fields such as HPF:20k and LPF:120Hz clearly read as boxed controls without changing rotary behavior or the left-side graph.
  R8: preserve the initial HOME screen as the 3x3 app grid; long press on the grid toggles MASTER MUTE; edit EQ/HPF/LPF frequency one digit at a time using the same rotate-and-press sequence as name editing; compact each right-panel row to one line to eliminate overlapping/doubled text; remove obsolete duplicate graph renderers and repeated graph values.
  R13: add a persistent 4-pixel (~1 mm) neon-green perimeter frame to the 160x128 TFT; reposition small footer/header elements so they remain readable.
  R14: reapply the perimeter frame after full, partial, graph, meter and RTA redraws; standardize content margins and parameter panel geometry; constrain page titles so they cannot collide with the status badge.
  R12: use the user's final pin map: TFT SCLK12/MOSI13/CS10/DC9/RST8; rotary16/17/18;
  PCM1808 BCLK4/WS5/DOUT7/MCLK15; DAC1 DIN6; DAC2 DIN21. BCLK/WS shared.
  I2S0 generates shared clocks; I2S1 takes BCLK/WS input from the same GPIO4/5 pads
  through the GPIO matrix while I2S0 keeps those pads driving the shared audio bus.
  No external clock feedback jumper to GPIO17/18 is required. RTA is INPUT L/R only.
  ST7735S panel uses the standard 160x128 landscape geometry. If the module uses
  a different tab variant or column/row offset, adjust initR only after testing.
  Compressor uses a 24 kHz control update rate with 2-sample peak capture and a 257-point interpolated gain LUT. Audio output remains 48 kHz. This source has not yet been compiled with the ESP32 toolchain or tested on
  hardware. Test first with amplifier mute/volume low and verify all four outputs.
*/
#include <Arduino.h>
#include "NumericEditField.h"  // Declared in a header so Arduino auto-prototypes see the type.
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include "LEON_AUDIO_logo.h"  // Replace logo.png and run KONVERSI_LOGO.bat to change the boot logo.
#include <FFat.h>
#include <ArduinoJson.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <driver/i2s_std.h>
#include <driver/gpio.h>
#include <esp_heap_caps.h>
#include <esp_err.h>

// ----------------------------- USER CONFIG -----------------------------
static constexpr uint32_t SAMPLE_RATE = 48000;
static constexpr size_t BLOCK_FRAMES = 64;  // 1.33 ms blocks for lower control/audio latency
static constexpr size_t EQ_BANDS = 9;
static constexpr size_t COMPRESSOR_LUT_SIZE = 257; // 256 intervals; half the previous table memory
static constexpr float COMPRESSOR_LUT_MAX_U = 0.99902415f; // level ratio coverage ~= 4096:1
static constexpr float COMPRESSOR_LUT_INV_MAX_U = 1.0009768f;
static constexpr uint8_t COMPRESSOR_CONTROL_DIV = 2; // update detector/gain at 24 kHz; audio remains 48 kHz
static constexpr float FIXED_INPUT_LR_BOOST_DB = 1.0f;   // was +6 dB; reduce net input level by exactly 5 dB
static constexpr float FIXED_OUTPUT_BOOST_HZ = 9000.0f;  // neutral identity biquad frequency placeholder
static constexpr float FIXED_OUTPUT_BOOST_DB = 0.0f;     // remove hidden +10 dB boost; output EQ remains flat unless user edits it
static constexpr float FIXED_OUTPUT_BOOST_Q = 0.4f;
static constexpr size_t MAX_DELAY_SAMPLES = 14400;  // 300 ms at 48 kHz

// USER FINAL PIN MAP - ESP32-S3 DevKitC-1 N16R8.
// I2S0 MASTER drives the shared BCLK/LRCK pair. ADC and both DAC modules connect
// to these same clock nets. I2S1 SLAVE reads the same GPIO pads via input matrix.
static constexpr gpio_num_t PIN_I2S0_BCLK = GPIO_NUM_4;
static constexpr gpio_num_t PIN_I2S0_WS   = GPIO_NUM_5;
static constexpr gpio_num_t PIN_DAC1_DIN  = GPIO_NUM_6;  // PCM5102 #1: OUT1=L, OUT2=R
static constexpr gpio_num_t PIN_ADC_DOUT  = GPIO_NUM_7;  // PCM1808 DOUT -> ESP32-S3
static constexpr gpio_num_t PIN_DAC2_DIN  = GPIO_NUM_21; // PCM5102 #2: OUT3=L, OUT4=R
static constexpr gpio_num_t PIN_ADC_MCLK  = GPIO_NUM_15; // 12.288 MHz -> PCM1808 SCKI
// Important: same physical BCLK/WS pads are input sources for I2S1 SLAVE.
// GPIO input-enable and output-signal routing are independent on ESP32-S3.
static constexpr gpio_num_t PIN_I2S1_BCLK_IN = PIN_I2S0_BCLK;
static constexpr gpio_num_t PIN_I2S1_WS_IN   = PIN_I2S0_WS;

// User final local UI wiring: 1.8-inch ST7735S SPI + rotary encoder.
static constexpr int8_t PIN_TFT_SCLK = 12;
static constexpr int8_t PIN_TFT_MOSI = 13;
static constexpr int8_t PIN_TFT_CS   = 10;
static constexpr int8_t PIN_TFT_DC   = 9;
static constexpr int8_t PIN_TFT_RST  = 8;
static constexpr int8_t PIN_ROTARY_A  = 16; // CLK / A
static constexpr int8_t PIN_ROTARY_B  = 17; // DT / B
static constexpr int8_t PIN_ROTARY_SW = 18; // encoder push switch

// ----------------------------- DATA MODEL ------------------------------
struct EqBand {
  bool enabled;
  float frequency;
  float gainDb;
  float q;
};

struct InputDspConfig {
  bool crossoverBypass;
  float hpfHz;
  uint8_t hpfType;
  uint8_t hpfSlope;
  float lpfHz;
  uint8_t lpfType;
  uint8_t lpfSlope;
  float delayMs;
  bool dynamicsEnabled;
  float thresholdDb;
  float ratio;
  float attackMs;
  float releaseMs;
};

struct OutputConfig {
  uint8_t source;       // 0 = Left, 1 = Right, 2 = Mix L+R
  float gainDb;
  bool mute;
  bool polarityInvert;
  bool crossoverBypass; // single bypass for the complete HPF + LPF section
  bool hpfEnabled;      // legacy preset compatibility only
  float hpfHz;
  uint8_t hpfType;      // 0 Butterworth, 1 Linkwitz-Riley, 2 Bessel
  uint8_t hpfSlope;     // 12, 24, 36, 48 dB/oct
  bool lpfEnabled;
  float lpfHz;
  uint8_t lpfType;      // 0 Butterworth, 1 Linkwitz-Riley, 2 Bessel
  uint8_t lpfSlope;
  float delayMs;
  bool dynamicsEnabled;
  float thresholdDb;
  float ratio;
  float attackMs;
  float releaseMs;
  EqBand eq[EQ_BANDS];
};

struct DeviceConfig {
  float inputGainDb[2];
  bool inputMute[2];       // independent mute for input L/R
  EqBand inputEq[2][EQ_BANDS];
  InputDspConfig inputDsp[2];
  bool inputRoute[2][4];   // checkbox routing: IN1/IN2 -> OUT1..OUT4
  OutputConfig output[4];
};

static DeviceConfig gConfig;
static portMUX_TYPE gConfigMux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t gConfigRevision = 1;
static bool configDirty = false;
static uint32_t lastConfigChange = 0;
static bool storageReady = false;

// ----------------------------- I2S HANDLES ------------------------------
static i2s_chan_handle_t i2s0Tx = nullptr;
static i2s_chan_handle_t i2s0Rx = nullptr;
static i2s_chan_handle_t i2s1Tx = nullptr;
static bool audioReady = false;
static bool displayReady = false;

// Native ST7735S 1.8-inch TFT. The UI was originally designed for 160x128,
// so no coordinate scaling or display wrapper is used.
static Adafruit_ST7735 tft(PIN_TFT_CS, PIN_TFT_DC, PIN_TFT_RST);

// RTA uses three PSRAM banks for stereo input L/R blocks so the audio task does not wait for UI spectrum calculation.
static constexpr size_t RTA_SAMPLES = 4096;
static constexpr size_t RTA_BANDS = 20;
static constexpr uint8_t RTA_BANKS = 3;
static float *gRtaBuffers[RTA_BANKS][2] = {}; // stereo INPUT L/R only
static float *gRtaSnapshot[2] = {};
static float gRtaWindow[RTA_SAMPLES] = {};
static portMUX_TYPE gRtaMux = portMUX_INITIALIZER_UNLOCKED;
static volatile uint32_t gRtaSequence = 0;
static volatile uint8_t gRtaPublishedBank = 1;
static volatile int8_t gRtaReadBank = -1;
static uint8_t gRtaWriteBank = 0; // audio-task owned except during bank swap
static bool gRtaMemoryReady = false;
static uint32_t gRtaDrawnSequence = 0;
static float gRtaLevels[2][RTA_BANDS] = {}; // [0]=input L, [1]=input R
static float gRtaPeakDb[2] = {-90.0f, -90.0f};
static volatile bool gRtaCaptureEnabled = false; // capture only while the RTA page is open

// Low-rate peak telemetry for the opening input/output monitor screen.
static portMUX_TYPE gMeterMux = portMUX_INITIALIZER_UNLOCKED;
static float gInputPeakLinear[2] = {0.0f, 0.0f};
static float gOutputPeakLinear[4] = {0.0f, 0.0f, 0.0f, 0.0f};
static volatile bool gMasterMute = true; // safe startup: outputs remain muted until user deliberately unmutes
// Fixed encoder step size; no user-selectable Slow/Fast modes.

// ----------------------------- DSP ENGINE -------------------------------
struct Biquad {
  float b0 = 1.0f, b1 = 0.0f, b2 = 0.0f, a1 = 0.0f, a2 = 0.0f;
  float z1 = 0.0f, z2 = 0.0f;
  inline float process(float x) {
    const float y = b0 * x + z1;
    z1 = b1 * x - a1 * y + z2;
    z2 = b2 * x - a2 * y;
    return y;
  }
  void reset() { z1 = 0.0f; z2 = 0.0f; }
};

// Short linear ramps for gain changes. Filter coefficient updates are handled
// while the output is briefly faded down (see audioTask) to avoid clicks.
struct SmoothValue {
  float current = 1.0f;
  float target = 1.0f;
  float step = 0.0f;
  uint32_t remaining = 0;

  void setTarget(float value, uint32_t samples, bool immediate = false) {
    target = value;
    if (immediate || samples == 0) {
      current = target;
      step = 0.0f;
      remaining = 0;
    } else {
      remaining = samples;
      step = (target - current) / (float)samples;
    }
  }

  inline float next() {
    if (remaining > 0) {
      current += step;
      if (--remaining == 0) current = target;
    }
    return current;
  }
};

static constexpr uint32_t GAIN_RAMP_SAMPLES = 240; // 5 ms
static constexpr uint32_t CONFIG_FADE_DOWN_SAMPLES = 64; // 1.33 ms at 48 kHz
static constexpr uint32_t CONFIG_FADE_UP_SAMPLES = 96;   // 2.00 ms at 48 kHz

struct CompressorCurve {
  float thresholdLinear = 1.0f;
  float inverseThreshold = 1.0f;
  bool ratioActive = false;
  float gainLut[COMPRESSOR_LUT_SIZE] = {};
};

struct ProcessorState {
  Biquad inputEq[2][EQ_BANDS];
  Biquad inputHpf[2][4];
  Biquad inputLpf[2][4];
  Biquad outputEq[4][EQ_BANDS];
  Biquad outputFixed9k[4]; // 0 dB identity biquad; no hidden 9 kHz tonal boost
  Biquad hpf[4][4];
  Biquad lpf[4][4];
  float compressorEnvelope[4] = {0, 0, 0, 0};
  float inputCompressorEnvelope[2] = {0, 0};
  // The detector collects the peak of each two-sample group. Gain is held
  // between control updates, reducing compressor math while preserving peaks.
  float compressorPeakHold[4] = {0, 0, 0, 0};
  float inputCompressorPeakHold[2] = {0, 0};
  float compressorGainHold[4] = {1, 1, 1, 1};
  float inputCompressorGainHold[2] = {1, 1};
  uint8_t compressorControlPhase[4] = {0, 0, 0, 0};
  uint8_t inputCompressorControlPhase[2] = {0, 0};
  CompressorCurve compressorCurve[4];
  CompressorCurve inputCompressorCurve[2];
  float muteGain[4] = {1, 1, 1, 1};
  size_t delayPosition[4] = {0, 0, 0, 0};
  size_t delayValidSamples[4] = {0, 0, 0, 0};
  size_t inputDelayPosition[2] = {0, 0};
  size_t inputDelayValidSamples[2] = {0, 0};
  float attackCoeff[4] = {0, 0, 0, 0};
  float releaseCoeff[4] = {0, 0, 0, 0};
  float inputAttackCoeff[2] = {0, 0};
  float inputReleaseCoeff[2] = {0, 0};
  SmoothValue inputGainLinear[2];
  float inputMuteGain[2] = {1.0f, 1.0f};
  SmoothValue outputGainLinear[4];
  uint32_t configuredRevision = 0;
};
static ProcessorState dsp;
static DeviceConfig dspAppliedConfig;
static bool dspAppliedConfigValid = false;
// Published by the audio task after a complete DSP configuration revision is applied.
static volatile uint32_t gDspAppliedRevision = 0;
static float *delayBuffer[4] = {nullptr, nullptr, nullptr, nullptr};
static float *inputDelayBuffer[2] = {nullptr, nullptr};

// ----------------------------- UTILITIES --------------------------------
static float clampf(float x, float lo, float hi) {
  if (x < lo) return lo;
  if (x > hi) return hi;
  return x;
}
static float dbToLinear(float db) { return powf(10.0f, db / 20.0f); }
static void updateCompressorThreshold(CompressorCurve &curve, float thresholdDb) {
  curve.thresholdLinear = dbToLinear(clampf(thresholdDb, -60.0f, 12.0f));
  curve.inverseThreshold = 1.0f / max(curve.thresholdLinear, 1.0e-6f);
}

// Build the static curve outside the sample loop. The lookup coordinate
// u=(levelRatio-1)/(levelRatio+3) maps levelRatio 1..about 4096 to 0..0.999024.
// A small linear interpolation in the audio loop replaces log10f + expf
// for every sample and for each of the six input/output compressor channels.
static void buildCompressorGainLut(CompressorCurve &curve, float ratio) {
  const float safeRatio = clampf(ratio, 1.0f, 20.0f);
  const float exponent = 1.0f - (1.0f / safeRatio);
  curve.ratioActive = exponent > 0.000001f;
  for (size_t i = 0; i < COMPRESSOR_LUT_SIZE; ++i) {
    if (!curve.ratioActive) {
      curve.gainLut[i] = 1.0f;
      continue;
    }
    const float u = COMPRESSOR_LUT_MAX_U * (float)i / (float)(COMPRESSOR_LUT_SIZE - 1);
    const float levelRatio = (1.0f + 3.0f * u) / (1.0f - u);
    curve.gainLut[i] = powf(1.0f / levelRatio, exponent);
  }
}

static inline float compressorGainFromLut(float envelope, const CompressorCurve &curve) {
  if (!curve.ratioActive || envelope <= curve.thresholdLinear) return 1.0f;
  const float levelRatio = envelope * curve.inverseThreshold;
  const float u = (levelRatio - 1.0f) / (levelRatio + 3.0f);
  const float position = (u * COMPRESSOR_LUT_INV_MAX_U) * (float)(COMPRESSOR_LUT_SIZE - 1);
  if (position >= (float)(COMPRESSOR_LUT_SIZE - 1)) return curve.gainLut[COMPRESSOR_LUT_SIZE - 1];
  const size_t index = (size_t)position;
  const float fraction = position - (float)index;
  const float a = curve.gainLut[index];
  const float b = curve.gainLut[index + 1];
  return a + (b - a) * fraction;
}
static float safeFrequency(float hz) { return clampf(hz, 20.0f, 20000.0f); }
enum CrossoverFilterType : uint8_t { FILTER_BUTTERWORTH = 0, FILTER_LINKWITZ_RILEY = 1, FILTER_BESSEL = 2 };
static uint8_t normalizeCrossoverSlope(int value) {
  if (value >= 48) return 48;
  if (value >= 36) return 36;
  if (value >= 24) return 24;
  return 12;
}

static uint8_t slopeStages(uint8_t type, uint8_t slope) {
  if (type == FILTER_LINKWITZ_RILEY && slope <= 12) return 2; // LR2: two first-order sections
  if (type == FILTER_LINKWITZ_RILEY && slope == 36) return 3; // LR6: three cascaded biquad sections
  if (slope >= 48) return 4;
  if (slope >= 36) return 3; // 6th-order Butterworth/Bessel
  if (slope >= 24) return 2;
  return 1;
}

static float crossoverQ(uint8_t type, uint8_t slope, int stage) {
  stage = constrain(stage, 0, 3);
  if (type == FILTER_LINKWITZ_RILEY) {
    if (slope <= 12) return 0.70710678f; // not used by first-order LR2 sections
    if (slope == 36) {
      static const float q[3] = {0.5f, 1.0f, 1.0f};
      return q[stage]; // LR6 pole-pair Q values
    }
    if (slope >= 48) {
      static const float q[4] = {0.5411961f, 1.3065630f, 0.5411961f, 1.3065630f};
      return q[stage]; // LR8 = two cascaded 4th-order Butterworth sections
    }
    return 0.70710678f; // LR4 = two cascaded 2nd-order Butterworth sections
  }
  if (type == FILTER_BESSEL) {
    if (slope >= 48) {
      static const float q[4] = {0.50599107f, 0.55960916f, 0.71085207f, 1.22566943f};
      return q[stage];
    }
    if (slope >= 36) {
      static const float q[3] = {0.5103178247f, 0.6111945469f, 1.0233139538f};
      return q[stage]; // 6th-order Bessel pole pairs
    }
    if (slope >= 24) {
      static const float q[2] = {0.52193458f, 0.80553828f};
      return q[stage & 1];
    }
    return 0.57735027f;
  }
  if (slope >= 48) {
    static const float q[4] = {0.5097956f, 0.6013449f, 0.8999762f, 2.5629154f};
    return q[stage];
  }
  if (slope >= 36) {
    static const float q[3] = {0.51763809f, 0.70710678f, 1.93185165f};
    return q[stage]; // 6th-order Butterworth pole pairs
  }
  if (slope >= 24) {
    static const float q[2] = {0.5411961f, 1.3065630f};
    return q[stage & 1];
  }
  return 0.70710678f;
}

static void setFirstOrder(Biquad &bq, float fs, float f, bool highpass) {
  f = clampf(f, 20.0f, fs * 0.45f);
  const float k = tanf(PI * f / fs);
  const float den = 1.0f + k;
  if (highpass) {
    bq.b0 = 1.0f / den;
    bq.b1 = -bq.b0;
  } else {
    bq.b0 = k / den;
    bq.b1 = bq.b0;
  }
  bq.b2 = 0.0f;
  bq.a1 = (k - 1.0f) / den;
  bq.a2 = 0.0f;
}

static void setLowpass(Biquad &bq, float fs, float f, float q);
static void setHighpass(Biquad &bq, float fs, float f, float q);

static float crossoverSectionFrequency(float fs, float overallHz, uint8_t type, uint8_t slope, int stage) {
  if (type != FILTER_BESSEL) return overallHz;
  float scale = 1.27201965f;
  if (slope >= 48) {
    static const float scales[4] = {1.77846591f, 1.83209260f, 1.95319576f, 2.18872623f};
    scale = scales[constrain(stage, 0, 3)];
  } else if (slope >= 36) {
    static const float scales[3] = {1.60391913f, 1.68916827f, 1.90470761f};
    scale = scales[constrain(stage, 0, 2)];
  } else if (slope >= 24) {
    static const float scales[2] = {1.43017156f, 1.60335752f};
    scale = scales[constrain(stage, 0, 1)];
  }
  // Pre-warp so each Bessel pole pair lands at its analog prototype pole radius.
  const float tanBase = tanf(PI * clampf(overallHz, 20.0f, fs * 0.45f) / fs);
  return (fs / PI) * atanf(scale * tanBase);
}

static void configureCrossoverSection(Biquad &bq, float fs, float f, uint8_t type, uint8_t slope, int stage, bool highpass) {
  if (type == FILTER_LINKWITZ_RILEY && slope <= 12) {
    setFirstOrder(bq, fs, f, highpass);
    return;
  }
  const float q = crossoverQ(type, slope, stage);
  const float stageHz = crossoverSectionFrequency(fs, f, type, slope, stage);
  if (highpass) setHighpass(bq, fs, stageHz, q);
  else setLowpass(bq, fs, stageHz, q);
}

static void setPeaking(Biquad &bq, float fs, float f, float gainDb, float q) {
  f = clampf(f, 20.0f, fs * 0.45f);
  q = clampf(q, 0.4f, 12.0f);
  gainDb = clampf(gainDb, -15.0f, 15.0f);
  const float A = powf(10.0f, gainDb / 40.0f);
  const float w0 = 2.0f * PI * f / fs;
  const float c = cosf(w0), s = sinf(w0);
  const float alpha = s / (2.0f * q);
  const float a0 = 1.0f + alpha / A;
  bq.b0 = (1.0f + alpha * A) / a0;
  bq.b1 = (-2.0f * c) / a0;
  bq.b2 = (1.0f - alpha * A) / a0;
  bq.a1 = (-2.0f * c) / a0;
  bq.a2 = (1.0f - alpha / A) / a0;
}

static void setLowpass(Biquad &bq, float fs, float f, float q) {
  f = clampf(f, 20.0f, fs * 0.45f);
  q = clampf(q, 0.45f, 3.0f);
  const float w0 = 2.0f * PI * f / fs;
  const float c = cosf(w0), s = sinf(w0), alpha = s / (2.0f * q);
  const float a0 = 1.0f + alpha;
  bq.b0 = ((1.0f - c) * 0.5f) / a0;
  bq.b1 = (1.0f - c) / a0;
  bq.b2 = ((1.0f - c) * 0.5f) / a0;
  bq.a1 = (-2.0f * c) / a0;
  bq.a2 = (1.0f - alpha) / a0;
}

static void setHighpass(Biquad &bq, float fs, float f, float q) {
  f = clampf(f, 20.0f, fs * 0.45f);
  q = clampf(q, 0.45f, 3.0f);
  const float w0 = 2.0f * PI * f / fs;
  const float c = cosf(w0), s = sinf(w0), alpha = s / (2.0f * q);
  const float a0 = 1.0f + alpha;
  bq.b0 = ((1.0f + c) * 0.5f) / a0;
  bq.b1 = (-(1.0f + c)) / a0;
  bq.b2 = ((1.0f + c) * 0.5f) / a0;
  bq.a1 = (-2.0f * c) / a0;
  bq.a2 = (1.0f - alpha) / a0;
}

static DeviceConfig makeDefaultConfig() {
  DeviceConfig defaults{};
  const float defaultFreq[EQ_BANDS] = {31.5f, 63.0f, 125.0f, 250.0f, 500.0f, 1000.0f, 2000.0f, 4000.0f, 8000.0f};
  for (int ch = 0; ch < 6; ++ch) {
    for (size_t b = 0; b < EQ_BANDS; ++b) {
      EqBand *eq = (ch < 2) ? &defaults.inputEq[ch][b] : &defaults.output[ch - 2].eq[b];
      eq->enabled = false; // factory STANDARD: EQ bypassed
      eq->frequency = defaultFreq[b];
      eq->gainDb = 0.0f;
      eq->q = 1.0f;
    }
  }
  defaults.inputGainDb[0] = 0.0f;
  defaults.inputGainDb[1] = 0.0f;
  defaults.inputMute[0] = false;
  defaults.inputMute[1] = false;
  for (int ch = 0; ch < 2; ++ch) {
    InputDspConfig &in = defaults.inputDsp[ch];
    in.crossoverBypass = true;
    in.hpfHz = 80.0f; in.hpfType = FILTER_BUTTERWORTH; in.hpfSlope = 24;
    in.lpfHz = 18000.0f; in.lpfType = FILTER_BUTTERWORTH; in.lpfSlope = 24;
    in.delayMs = 0.0f; in.dynamicsEnabled = false;
    in.thresholdDb = 0.0f; in.ratio = 1.0f; in.attackMs = 10.0f; in.releaseMs = 100.0f;
  }
  for (int i = 0; i < 4; ++i) {
    OutputConfig &o = defaults.output[i];
    o.source = 2; // default routing: MIX L+R; DSP effects remain bypassed
    o.gainDb = 0.0f;
    o.mute = false;
    o.polarityInvert = false;
    o.crossoverBypass = true;
    o.hpfEnabled = false;
    o.hpfHz = 80.0f;
    o.hpfType = FILTER_BUTTERWORTH;
    o.hpfSlope = 24;
    o.lpfEnabled = false;
    o.lpfHz = 18000.0f;
    o.lpfType = FILTER_BUTTERWORTH;
    o.lpfSlope = 24;
    o.delayMs = 0.0f;
    o.dynamicsEnabled = false;
    o.thresholdDb = 0.0f;
    o.ratio = 1.0f; // neutral ratio while dynamics are OFF
    o.attackMs = 10.0f;
    o.releaseMs = 100.0f;
  }
  // Factory routing mirrors the previous MIX L+R source on every output.
  for (int inCh = 0; inCh < 2; ++inCh)
    for (int outCh = 0; outCh < 4; ++outCh)
      defaults.inputRoute[inCh][outCh] = true;
  return defaults;
}

static void setDefaults() {
  DeviceConfig defaults = makeDefaultConfig();
  portENTER_CRITICAL(&gConfigMux);
  gConfig = defaults;
  ++gConfigRevision;
  portEXIT_CRITICAL(&gConfigMux);
  configDirty = true;
  lastConfigChange = millis();
}

// ----------------------------- JSON STATE -------------------------------
static void addEqArray(JsonArray arr, const EqBand *eq) {
  for (size_t i = 0; i < EQ_BANDS; ++i) {
    JsonObject b = arr.add<JsonObject>();
    b["en"] = eq[i].enabled;
    b["f"] = eq[i].frequency;
    b["g"] = eq[i].gainDb;
    b["q"] = eq[i].q;
  }
}

static String serializeState() {
  DeviceConfig snapshot;
  portENTER_CRITICAL(&gConfigMux);
  snapshot = gConfig;
  portEXIT_CRITICAL(&gConfigMux);

  JsonDocument doc;
  JsonObject input = doc["input"].to<JsonObject>();
  input["gainL"] = snapshot.inputGainDb[0];
  input["gainR"] = snapshot.inputGainDb[1];
  input["muteL"] = snapshot.inputMute[0];
  input["muteR"] = snapshot.inputMute[1];
  JsonArray inEq = input["eq"].to<JsonArray>();
  JsonArray inDsp = input["dsp"].to<JsonArray>();
  for (int ch = 0; ch < 2; ++ch) {
    JsonArray row = inEq.add<JsonArray>();
    addEqArray(row, snapshot.inputEq[ch]);
    const InputDspConfig &d = snapshot.inputDsp[ch];
    JsonObject v = inDsp.add<JsonObject>();
    v["xoverBypass"] = d.crossoverBypass;
    v["hpf"] = d.hpfHz; v["hpfType"] = d.hpfType; v["hpfSlope"] = d.hpfSlope;
    v["lpf"] = d.lpfHz; v["lpfType"] = d.lpfType; v["lpfSlope"] = d.lpfSlope;
    v["delay"] = d.delayMs; v["dynOn"] = d.dynamicsEnabled;
    v["threshold"] = d.thresholdDb; v["ratio"] = d.ratio;
    v["attack"] = d.attackMs; v["release"] = d.releaseMs;
  }
  JsonArray matrix = doc["matrix"].to<JsonArray>();
  for (int inCh = 0; inCh < 2; ++inCh) {
    JsonArray row = matrix.add<JsonArray>();
    for (int outCh = 0; outCh < 4; ++outCh) row.add(snapshot.inputRoute[inCh][outCh]);
  }
  JsonArray outputs = doc["outputs"].to<JsonArray>();
  for (int i = 0; i < 4; ++i) {
    const OutputConfig &o = snapshot.output[i];
    JsonObject v = outputs.add<JsonObject>();
    v["source"] = o.source; v["gain"] = o.gainDb; v["mute"] = o.mute; v["polarity"] = o.polarityInvert;
    v["xoverBypass"] = o.crossoverBypass;
    v["hpfOn"] = o.hpfEnabled; v["hpf"] = o.hpfHz; v["hpfType"] = o.hpfType; v["hpfSlope"] = o.hpfSlope;
    v["lpfOn"] = o.lpfEnabled; v["lpf"] = o.lpfHz; v["lpfType"] = o.lpfType; v["lpfSlope"] = o.lpfSlope;
    v["delay"] = o.delayMs; v["dynOn"] = o.dynamicsEnabled;
    v["threshold"] = o.thresholdDb; v["ratio"] = o.ratio;
    v["attack"] = o.attackMs; v["release"] = o.releaseMs;
    JsonArray eq = v["eq"].to<JsonArray>(); addEqArray(eq, o.eq);
  }
  String out;
  serializeJson(doc, out);
  return out;
}

static void readEqArray(JsonArrayConst arr, EqBand *eq) {
  for (size_t i = 0; i < EQ_BANDS && i < arr.size(); ++i) {
    JsonObjectConst b = arr[i].as<JsonObjectConst>();
    eq[i].enabled = b["en"] | eq[i].enabled;
    eq[i].frequency = clampf(b["f"] | eq[i].frequency, 20.0f, 20000.0f);
    eq[i].gainDb = clampf(b["g"] | eq[i].gainDb, -15.0f, 15.0f);
    eq[i].q = clampf(b["q"] | eq[i].q, 0.4f, 12.0f);
  }
}

static bool validateEqArray(JsonArrayConst bands) {
  if (bands.size() != EQ_BANDS) return false;
  for (size_t b = 0; b < EQ_BANDS; ++b) {
    JsonObjectConst band = bands[b].as<JsonObjectConst>();
    if (band.isNull() || band["f"].isNull() || band["g"].isNull() ||
        band["q"].isNull() || band["en"].isNull()) return false;
  }
  return true;
}

static bool validateStateDocument(JsonDocument &doc) {
  if (doc["input"].isNull() || doc["outputs"].isNull()) return false;
  JsonObjectConst input = doc["input"].as<JsonObjectConst>();
  if (input["gainL"].isNull() || input["gainR"].isNull() ||
      input["muteL"].isNull() || input["muteR"].isNull()) return false;
  JsonArrayConst inEq = input["eq"].as<JsonArrayConst>();
  if (inEq.size() != 2 || !validateEqArray(inEq[0].as<JsonArrayConst>()) ||
      !validateEqArray(inEq[1].as<JsonArrayConst>())) return false;

  JsonArrayConst matrix = doc["matrix"].as<JsonArrayConst>();
  if (!matrix.isNull()) {
    if (matrix.size() != 2) return false;
    for (int inCh = 0; inCh < 2; ++inCh) {
      JsonArrayConst row = matrix[inCh].as<JsonArrayConst>();
      if (row.size() != 4) return false;
      for (int outCh = 0; outCh < 4; ++outCh) if (row[outCh].isNull()) return false;
    }
  }
  JsonArrayConst outputs = doc["outputs"].as<JsonArrayConst>();
  if (outputs.size() != 4) return false;
  static const char *const required[] = {
    "source", "gain", "mute", "polarity", "hpfOn", "hpf", "hpfType", "hpfSlope",
    "lpfOn", "lpf", "lpfType", "lpfSlope", "delay", "dynOn", "threshold",
    "ratio", "attack", "release"
  };
  for (size_t ch = 0; ch < 4; ++ch) {
    JsonObjectConst output = outputs[ch].as<JsonObjectConst>();
    if (output.isNull()) return false;
    for (const char *key : required) if (output[key].isNull()) return false;
    if (!validateEqArray(output["eq"].as<JsonArrayConst>())) return false;
  }
  return true;
}

static bool applyJsonState(const String &json) {
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, json);
  if (err || !validateStateDocument(doc)) return false;

  // Every load starts from a fresh factory structure. Nothing is merged with
  // the previously active preset, preventing values from one slot leaking to another.
  DeviceConfig next = makeDefaultConfig();
  JsonObjectConst input = doc["input"].as<JsonObjectConst>();
  next.inputGainDb[0] = clampf(input["gainL"].as<float>(), -30.0f, 12.0f);
  next.inputGainDb[1] = clampf(input["gainR"].as<float>(), -30.0f, 12.0f);
  next.inputMute[0] = input["muteL"].as<bool>();
  next.inputMute[1] = input["muteR"].as<bool>();
  JsonArrayConst inEq = input["eq"].as<JsonArrayConst>();
  JsonArrayConst inDsp = input["dsp"].as<JsonArrayConst>();
  for (int ch = 0; ch < 2; ++ch) {
    readEqArray(inEq[ch].as<JsonArrayConst>(), next.inputEq[ch]);
    if (ch < (int)inDsp.size()) {
      JsonObjectConst v = inDsp[ch].as<JsonObjectConst>();
      InputDspConfig &d = next.inputDsp[ch];
      d.crossoverBypass = v["xoverBypass"] | d.crossoverBypass;
      d.hpfHz = clampf(v["hpf"] | d.hpfHz, 20.0f, 20000.0f);
      d.hpfType = (uint8_t)constrain((int)(v["hpfType"] | d.hpfType), 0, 2);
      { const int x = v["hpfSlope"] | d.hpfSlope; d.hpfSlope = normalizeCrossoverSlope(x); }
      d.lpfHz = clampf(v["lpf"] | d.lpfHz, 20.0f, 20000.0f);
      d.lpfType = (uint8_t)constrain((int)(v["lpfType"] | d.lpfType), 0, 2);
      { const int x = v["lpfSlope"] | d.lpfSlope; d.lpfSlope = normalizeCrossoverSlope(x); }
      d.delayMs = clampf(v["delay"] | d.delayMs, 0.0f, 300.0f);
      d.dynamicsEnabled = v["dynOn"] | d.dynamicsEnabled;
      d.thresholdDb = clampf(v["threshold"] | d.thresholdDb, -60.0f, 12.0f);
      d.ratio = clampf(v["ratio"] | d.ratio, 1.0f, 20.0f);
      d.attackMs = clampf(v["attack"] | d.attackMs, 0.1f, 100.0f);
      d.releaseMs = clampf(v["release"] | d.releaseMs, 10.0f, 1000.0f);
    }
  }

  JsonArrayConst outs = doc["outputs"].as<JsonArrayConst>();
  for (int i = 0; i < 4; ++i) {
    JsonObjectConst v = outs[i].as<JsonObjectConst>();
    OutputConfig &o = next.output[i];
    o.source = (uint8_t)constrain((int)v["source"].as<int>(), 0, 2);
    o.gainDb = clampf(v["gain"].as<float>(), -60.0f, 12.0f);
    o.mute = v["mute"].as<bool>();
    o.polarityInvert = v["polarity"].as<bool>();
    o.hpfEnabled = v["hpfOn"].as<bool>();
    o.crossoverBypass = v["xoverBypass"].is<bool>() ? v["xoverBypass"].as<bool>() : !(o.hpfEnabled || v["lpfOn"].as<bool>());
    o.hpfHz = clampf(v["hpf"].as<float>(), 20.0f, 20000.0f);
    o.hpfType = (uint8_t)constrain((int)v["hpfType"].as<int>(), 0, 2);
    const int hpfSlope = v["hpfSlope"].as<int>();
    o.hpfSlope = normalizeCrossoverSlope(hpfSlope);
    o.lpfEnabled = v["lpfOn"].as<bool>();
    o.lpfHz = clampf(v["lpf"].as<float>(), 20.0f, 20000.0f);
    o.lpfType = (uint8_t)constrain((int)v["lpfType"].as<int>(), 0, 2);
    const int lpfSlope = v["lpfSlope"].as<int>();
    o.lpfSlope = normalizeCrossoverSlope(lpfSlope);
    o.delayMs = clampf(v["delay"].as<float>(), 0.0f, 300.0f);
    o.dynamicsEnabled = v["dynOn"].as<bool>();
    o.thresholdDb = clampf(v["threshold"].as<float>(), -60.0f, 12.0f);
    o.ratio = clampf(v["ratio"].as<float>(), 1.0f, 20.0f);
    o.attackMs = clampf(v["attack"].as<float>(), 0.1f, 100.0f);
    o.releaseMs = clampf(v["release"].as<float>(), 10.0f, 1000.0f);
    readEqArray(v["eq"].as<JsonArrayConst>(), o.eq);
    const uint8_t legacySource = o.source;
    next.inputRoute[0][i] = (legacySource == 0 || legacySource == 2);
    next.inputRoute[1][i] = (legacySource == 1 || legacySource == 2);
  }
  JsonArrayConst matrix = doc["matrix"].as<JsonArrayConst>();
  if (!matrix.isNull()) {
    for (int inCh = 0; inCh < 2; ++inCh) {
      JsonArrayConst row = matrix[inCh].as<JsonArrayConst>();
      for (int outCh = 0; outCh < 4; ++outCh) next.inputRoute[inCh][outCh] = row[outCh].as<bool>();
    }
  }

  portENTER_CRITICAL(&gConfigMux);
  gConfig = next;
  ++gConfigRevision;
  portEXIT_CRITICAL(&gConfigMux);
  configDirty = true;
  lastConfigChange = millis();
  return true;
}

// Verify that the complete state just applied to gConfig matches the stored JSON.
// This catches a partial/mismatched load before the UI reports success.
static bool activeConfigMatchesJson(const String &json) {
  JsonDocument doc;
  if (deserializeJson(doc, json) || !validateStateDocument(doc)) return false;
  uint32_t revision = 0;
  DeviceConfig c;
  portENTER_CRITICAL(&gConfigMux);
  c = gConfig;
  portEXIT_CRITICAL(&gConfigMux);
  auto sameFloat = [](float a, float b) { return fabsf(a - b) <= 0.002f; };
  JsonObjectConst input = doc["input"].as<JsonObjectConst>();
  if (!sameFloat(c.inputGainDb[0], input["gainL"].as<float>()) ||
      !sameFloat(c.inputGainDb[1], input["gainR"].as<float>()) ||
      c.inputMute[0] != input["muteL"].as<bool>() ||
      c.inputMute[1] != input["muteR"].as<bool>()) return false;
  JsonArrayConst inEq = input["eq"].as<JsonArrayConst>();
  JsonArrayConst inDsp = input["dsp"].as<JsonArrayConst>();
  for (int ch = 0; ch < 2; ++ch) {
    JsonArrayConst arr = inEq[ch].as<JsonArrayConst>();
    for (size_t b = 0; b < EQ_BANDS; ++b) {
      JsonObjectConst v = arr[b].as<JsonObjectConst>();
      const EqBand &e = c.inputEq[ch][b];
      if (e.enabled != v["en"].as<bool>() ||
          !sameFloat(e.frequency, v["f"].as<float>()) ||
          !sameFloat(e.gainDb, v["g"].as<float>()) ||
          !sameFloat(e.q, v["q"].as<float>())) return false;
    }
    if (ch < (int)inDsp.size()) {
      JsonObjectConst v = inDsp[ch].as<JsonObjectConst>();
      const InputDspConfig &d = c.inputDsp[ch];
      if (d.crossoverBypass != (v["xoverBypass"] | d.crossoverBypass) ||
          !sameFloat(d.hpfHz, v["hpf"] | d.hpfHz) || d.hpfType != (v["hpfType"] | d.hpfType) ||
          d.hpfSlope != (v["hpfSlope"] | d.hpfSlope) || !sameFloat(d.lpfHz, v["lpf"] | d.lpfHz) ||
          d.lpfType != (v["lpfType"] | d.lpfType) || d.lpfSlope != (v["lpfSlope"] | d.lpfSlope) ||
          !sameFloat(d.delayMs, v["delay"] | d.delayMs) ||
          d.dynamicsEnabled != (v["dynOn"] | d.dynamicsEnabled) ||
          !sameFloat(d.thresholdDb, v["threshold"] | d.thresholdDb) ||
          !sameFloat(d.ratio, v["ratio"] | d.ratio) ||
          !sameFloat(d.attackMs, v["attack"] | d.attackMs) ||
          !sameFloat(d.releaseMs, v["release"] | d.releaseMs)) return false;
    }
  }
  JsonArrayConst storedMatrix = doc["matrix"].as<JsonArrayConst>();
  if (!storedMatrix.isNull()) {
    for (int inCh = 0; inCh < 2; ++inCh) {
      JsonArrayConst row = storedMatrix[inCh].as<JsonArrayConst>();
      for (int outCh = 0; outCh < 4; ++outCh)
        if (c.inputRoute[inCh][outCh] != row[outCh].as<bool>()) return false;
    }
  }
  JsonArrayConst outs = doc["outputs"].as<JsonArrayConst>();
  for (int ch = 0; ch < 4; ++ch) {
    JsonObjectConst v = outs[ch].as<JsonObjectConst>();
    const OutputConfig &o = c.output[ch];
    if (o.source != v["source"].as<uint8_t>() ||
        !sameFloat(o.gainDb, v["gain"].as<float>()) ||
        o.mute != v["mute"].as<bool>() || o.polarityInvert != v["polarity"].as<bool>() ||
        o.crossoverBypass != (v["xoverBypass"].is<bool>() ? v["xoverBypass"].as<bool>() : !(v["hpfOn"].as<bool>() || v["lpfOn"].as<bool>())) ||
        o.hpfEnabled != v["hpfOn"].as<bool>() || !sameFloat(o.hpfHz, v["hpf"].as<float>()) ||
        o.hpfType != v["hpfType"].as<uint8_t>() || o.hpfSlope != v["hpfSlope"].as<uint8_t>() ||
        o.lpfEnabled != v["lpfOn"].as<bool>() || !sameFloat(o.lpfHz, v["lpf"].as<float>()) ||
        o.lpfType != v["lpfType"].as<uint8_t>() || o.lpfSlope != v["lpfSlope"].as<uint8_t>() ||
        !sameFloat(o.delayMs, v["delay"].as<float>()) ||
        o.dynamicsEnabled != v["dynOn"].as<bool>() ||
        !sameFloat(o.thresholdDb, v["threshold"].as<float>()) ||
        !sameFloat(o.ratio, v["ratio"].as<float>()) ||
        !sameFloat(o.attackMs, v["attack"].as<float>()) ||
        !sameFloat(o.releaseMs, v["release"].as<float>())) return false;
    JsonArrayConst eq = v["eq"].as<JsonArrayConst>();
    for (size_t b = 0; b < EQ_BANDS; ++b) {
      JsonObjectConst band = eq[b].as<JsonObjectConst>();
      const EqBand &e = o.eq[b];
      if (e.enabled != band["en"].as<bool>() ||
          !sameFloat(e.frequency, band["f"].as<float>()) ||
          !sameFloat(e.gainDb, band["g"].as<float>()) ||
          !sameFloat(e.q, band["q"].as<float>())) return false;
    }
  }
  return true;
}

static DeviceConfig copyConfig(uint32_t &revision) {
  DeviceConfig copy;
  portENTER_CRITICAL(&gConfigMux); copy = gConfig; revision = gConfigRevision; portEXIT_CRITICAL(&gConfigMux);
  return copy;
}

// ----------------------------- DSP CONFIG -------------------------------
static bool sameEq(const EqBand &a, const EqBand &b) {
  return a.enabled == b.enabled && fabsf(a.frequency - b.frequency) < 0.001f &&
         fabsf(a.gainDb - b.gainDb) < 0.001f && fabsf(a.q - b.q) < 0.001f;
}

static bool eqIsActive(const EqBand &e) {
  return e.enabled && fabsf(e.gainDb) > 0.001f;
}

static void configureDsp(const DeviceConfig &c, uint32_t revision) {
  if (dsp.configuredRevision == revision) {
    gDspAppliedRevision = revision;
    return;
  }
  const bool firstConfig = !dspAppliedConfigValid;

  // A gain-only adjustment must not recalculate every biquad coefficient.
  for (int ch = 0; ch < 2; ++ch) {
    if (firstConfig || fabsf(c.inputGainDb[ch] - dspAppliedConfig.inputGainDb[ch]) > 0.001f)
      dsp.inputGainLinear[ch].setTarget(dbToLinear(c.inputGainDb[ch] + FIXED_INPUT_LR_BOOST_DB), GAIN_RAMP_SAMPLES, firstConfig);
    for (size_t b = 0; b < EQ_BANDS; ++b) {
      const EqBand &e = c.inputEq[ch][b];
      if (firstConfig || !sameEq(e, dspAppliedConfig.inputEq[ch][b])) {
        const bool wasActive = !firstConfig && eqIsActive(dspAppliedConfig.inputEq[ch][b]);
        setPeaking(dsp.inputEq[ch][b], SAMPLE_RATE, e.frequency, e.enabled ? e.gainDb : 0.0f, e.q);
        if (!wasActive && eqIsActive(e)) dsp.inputEq[ch][b].reset();
      }
    }
  }

  for (int ch = 0; ch < 2; ++ch) {
    const InputDspConfig &in = c.inputDsp[ch];
    const InputDspConfig &oldIn = dspAppliedConfig.inputDsp[ch];
    const bool hpfChanged = firstConfig || fabsf(in.hpfHz - oldIn.hpfHz) > 0.001f || in.hpfType != oldIn.hpfType || in.hpfSlope != oldIn.hpfSlope;
    const bool lpfChanged = firstConfig || fabsf(in.lpfHz - oldIn.lpfHz) > 0.001f || in.lpfType != oldIn.lpfType || in.lpfSlope != oldIn.lpfSlope;
    if (hpfChanged) for (int st = 0; st < 4; ++st) configureCrossoverSection(dsp.inputHpf[ch][st], SAMPLE_RATE, in.hpfHz, in.hpfType, in.hpfSlope, st, true);
    if (lpfChanged) for (int st = 0; st < 4; ++st) configureCrossoverSection(dsp.inputLpf[ch][st], SAMPLE_RATE, in.lpfHz, in.lpfType, in.lpfSlope, st, false);
    if (firstConfig || hpfChanged || lpfChanged || oldIn.crossoverBypass != in.crossoverBypass) {
      for (int st = 0; st < 4; ++st) { dsp.inputHpf[ch][st].reset(); dsp.inputLpf[ch][st].reset(); }
    }
    if (firstConfig || (oldIn.delayMs <= 0.01f && in.delayMs > 0.01f)) {
      dsp.inputDelayPosition[ch] = 0; dsp.inputDelayValidSamples[ch] = 0;
    }
    if (firstConfig || fabsf(in.attackMs - oldIn.attackMs) > 0.001f) dsp.inputAttackCoeff[ch] = expf(-(float)COMPRESSOR_CONTROL_DIV / (SAMPLE_RATE * (in.attackMs / 1000.0f)));
    if (firstConfig || fabsf(in.releaseMs - oldIn.releaseMs) > 0.001f) dsp.inputReleaseCoeff[ch] = expf(-(float)COMPRESSOR_CONTROL_DIV / (SAMPLE_RATE * (in.releaseMs / 1000.0f)));
    if (firstConfig || fabsf(in.thresholdDb - oldIn.thresholdDb) > 0.001f)
      updateCompressorThreshold(dsp.inputCompressorCurve[ch], in.thresholdDb);
    if (firstConfig || fabsf(in.ratio - oldIn.ratio) > 0.001f)
      buildCompressorGainLut(dsp.inputCompressorCurve[ch], in.ratio);
    if (firstConfig || (!oldIn.dynamicsEnabled && in.dynamicsEnabled)) {
      dsp.inputCompressorEnvelope[ch] = 0.0f;
      dsp.inputCompressorPeakHold[ch] = 0.0f;
      dsp.inputCompressorGainHold[ch] = 1.0f;
      dsp.inputCompressorControlPhase[ch] = 0;
    }
  }

  for (int ch = 0; ch < 4; ++ch) {
    const OutputConfig &o = c.output[ch];
    const OutputConfig &old = dspAppliedConfig.output[ch];
    if (firstConfig) {
      setPeaking(dsp.outputFixed9k[ch], SAMPLE_RATE, FIXED_OUTPUT_BOOST_HZ,
                 FIXED_OUTPUT_BOOST_DB, FIXED_OUTPUT_BOOST_Q);
      dsp.outputFixed9k[ch].reset();
    }
    if (firstConfig || fabsf(o.gainDb - old.gainDb) > 0.001f)
      dsp.outputGainLinear[ch].setTarget(dbToLinear(o.gainDb), GAIN_RAMP_SAMPLES, firstConfig);

    for (size_t b = 0; b < EQ_BANDS; ++b) {
      const EqBand &e = o.eq[b];
      if (firstConfig || !sameEq(e, old.eq[b])) {
        const bool wasActive = !firstConfig && eqIsActive(old.eq[b]);
        setPeaking(dsp.outputEq[ch][b], SAMPLE_RATE, e.frequency, e.enabled ? e.gainDb : 0.0f, e.q);
        if (!wasActive && eqIsActive(e)) dsp.outputEq[ch][b].reset();
      }
    }

    const bool hpfChanged = firstConfig ||
      fabsf(o.hpfHz - old.hpfHz) > 0.001f || o.hpfType != old.hpfType || o.hpfSlope != old.hpfSlope;
    if (hpfChanged) {
      for (int st = 0; st < 4; ++st)
        configureCrossoverSection(dsp.hpf[ch][st], SAMPLE_RATE, o.hpfHz, o.hpfType, o.hpfSlope, st, true);
    }

    const bool lpfChanged = firstConfig ||
      fabsf(o.lpfHz - old.lpfHz) > 0.001f || o.lpfType != old.lpfType || o.lpfSlope != old.lpfSlope;
    if (lpfChanged) {
      for (int st = 0; st < 4; ++st)
        configureCrossoverSection(dsp.lpf[ch][st], SAMPLE_RATE, o.lpfHz, o.lpfType, o.lpfSlope, st, false);
    }
    if (firstConfig || hpfChanged || lpfChanged || old.crossoverBypass != o.crossoverBypass) {
      for (int st = 0; st < 4; ++st) { dsp.hpf[ch][st].reset(); dsp.lpf[ch][st].reset(); }
    }

    if (firstConfig || (old.delayMs <= 0.01f && o.delayMs > 0.01f)) {
      dsp.delayPosition[ch] = 0;
      dsp.delayValidSamples[ch] = 0;
    }

    if (firstConfig || fabsf(o.attackMs - old.attackMs) > 0.001f)
      dsp.attackCoeff[ch] = expf(-(float)COMPRESSOR_CONTROL_DIV / (SAMPLE_RATE * (o.attackMs / 1000.0f)));
    if (firstConfig || fabsf(o.releaseMs - old.releaseMs) > 0.001f)
      dsp.releaseCoeff[ch] = expf(-(float)COMPRESSOR_CONTROL_DIV / (SAMPLE_RATE * (o.releaseMs / 1000.0f)));
    if (firstConfig || fabsf(o.thresholdDb - old.thresholdDb) > 0.001f)
      updateCompressorThreshold(dsp.compressorCurve[ch], o.thresholdDb);
    if (firstConfig || fabsf(o.ratio - old.ratio) > 0.001f)
      buildCompressorGainLut(dsp.compressorCurve[ch], o.ratio);
    if (firstConfig || (!old.dynamicsEnabled && o.dynamicsEnabled)) {
      dsp.compressorEnvelope[ch] = 0.0f;
      dsp.compressorPeakHold[ch] = 0.0f;
      dsp.compressorGainHold[ch] = 1.0f;
      dsp.compressorControlPhase[ch] = 0;
    }
  }

  dspAppliedConfig = c;
  dspAppliedConfigValid = true;
  dsp.configuredRevision = revision;
  // Publish only after every input/output coefficient and ramp target is updated.
  gDspAppliedRevision = revision;
}

static inline float runDynamics(float x, int ch, const CompressorCurve &curve) {
  float &peak = dsp.compressorPeakHold[ch];
  const float level = fabsf(x);
  if (level > peak) peak = level;

  uint8_t &phase = dsp.compressorControlPhase[ch];
  if (++phase >= COMPRESSOR_CONTROL_DIV) {
    phase = 0;
    float &env = dsp.compressorEnvelope[ch];
    const float blockPeak = peak;
    peak = 0.0f;
    const float coeff = (blockPeak > env) ? dsp.attackCoeff[ch] : dsp.releaseCoeff[ch];
    env = coeff * env + (1.0f - coeff) * blockPeak;
    dsp.compressorGainHold[ch] = compressorGainFromLut(env, curve);
  }
  return x * dsp.compressorGainHold[ch];
}

static inline float runInputDelay(float x, int ch, float delayMs) {
  float *buf = inputDelayBuffer[ch];
  if (!buf) return x;
  const float samples = clampf(delayMs, 0.0f, 300.0f) * (SAMPLE_RATE / 1000.0f);
  const size_t whole = (size_t)samples;
  const float frac = samples - (float)whole;
  const size_t ringSize = MAX_DELAY_SAMPLES + 1;
  const size_t pos = dsp.inputDelayPosition[ch];
  buf[pos] = x;
  const size_t validBefore = dsp.inputDelayValidSamples[ch];
  dsp.inputDelayValidSamples[ch] = min(ringSize, validBefore + 1);
  float y = x;
  if (validBefore > whole) {
    const size_t i1 = (pos + ringSize - whole) % ringSize;
    const size_t i2 = (i1 + ringSize - 1) % ringSize;
    y = buf[i1] * (1.0f - frac) + buf[i2] * frac;
  }
  dsp.inputDelayPosition[ch] = (pos + 1) % ringSize;
  return y;
}

static inline float runInputDynamics(float x, int ch, const CompressorCurve &curve) {
  float &peak = dsp.inputCompressorPeakHold[ch];
  const float level = fabsf(x);
  if (level > peak) peak = level;

  uint8_t &phase = dsp.inputCompressorControlPhase[ch];
  if (++phase >= COMPRESSOR_CONTROL_DIV) {
    phase = 0;
    float &env = dsp.inputCompressorEnvelope[ch];
    const float blockPeak = peak;
    peak = 0.0f;
    const float coeff = (blockPeak > env) ? dsp.inputAttackCoeff[ch] : dsp.inputReleaseCoeff[ch];
    env = coeff * env + (1.0f - coeff) * blockPeak;
    dsp.inputCompressorGainHold[ch] = compressorGainFromLut(env, curve);
  }
  return x * dsp.inputCompressorGainHold[ch];
}

static inline float runDelay(float x, int ch, float delayMs) {
  float *buf = delayBuffer[ch];
  if (!buf) return x;
  const float samples = clampf(delayMs, 0.0f, 300.0f) * (SAMPLE_RATE / 1000.0f);
  const size_t whole = (size_t)samples;
  const float frac = samples - (float)whole;
  const size_t ringSize = MAX_DELAY_SAMPLES + 1;
  const size_t pos = dsp.delayPosition[ch];
  buf[pos] = x;
  const size_t validBefore = dsp.delayValidSamples[ch];
  dsp.delayValidSamples[ch] = min(ringSize, validBefore + 1);
  float y = x; // bypass while the newly enabled delay line is being primed
  if (validBefore > whole) {
    const size_t i1 = (pos + ringSize - whole) % ringSize;
    const size_t i2 = (i1 + ringSize - 1) % ringSize;
    y = buf[i1] * (1.0f - frac) + buf[i2] * frac;
  }
  dsp.delayPosition[ch] = (pos + 1) % ringSize;
  return y;
}

// ----------------------------- AUDIO TASK ------------------------------
static inline float softLimitSample(float x) {
  // Gentle knee above about -0.9 dBFS. This reduces harsh digital clipping
  // caused by downstream EQ/output gain boosts; it cannot repair ADC clipping.
  const float ax = fabsf(x);
  const float knee = 0.90f;
  const float ceiling = 0.985f;
  if (ax <= knee) return x;
  const float span = ceiling - knee;
  const float shaped = knee + span * tanhf((ax - knee) / span);
  return copysignf((shaped < ceiling) ? shaped : ceiling, x);
}

// ----------------------------- AUDIO TASK ------------------------------
static void audioTask(void *parameter) {
  static int32_t input[BLOCK_FRAMES * 2];
  static int32_t outputA[BLOCK_FRAMES * 2];
  static int32_t outputB[BLOCK_FRAMES * 2];
  static size_t rtaWritePosition = 0;
  (void)parameter;

  // Initialize the software mute gains to the requested safe boot state before audio samples flow.
  for (int ch = 0; ch < 4; ++ch) dsp.muteGain[ch] = gMasterMute ? 0.0f : 1.0f;

  DeviceConfig activeConfig{};
  DeviceConfig pendingConfig{};
  uint32_t activeRevision = 0;
  uint32_t pendingRevision = 0;
  bool activeConfigValid = false;
  bool pendingConfigValid = false;
  float configFade = 1.0f;
  float fadeDownStep = 0.0f;
  float fadeUpStep = 0.0f;
  uint32_t fadeDownRemaining = 0;
  uint32_t fadeUpRemaining = 0;

  for (;;) {
    size_t bytesRead = 0;
    const esp_err_t readErr = i2s_channel_read(i2s0Rx, input, sizeof(input), &bytesRead, 1000);
    if (readErr != ESP_OK || bytesRead < (sizeof(int32_t) * 2)) {
      static uint32_t lastRxErrLog = 0;
      static uint32_t rxErrCount = 0;
      ++rxErrCount;
      const uint32_t nowMs = millis();
      if ((uint32_t)(nowMs - lastRxErrLog) >= 2000U) {
        Serial.printf("I2S RX read warning: %s, bytes=%u, count=%u\n",
                      esp_err_to_name(readErr), (unsigned)bytesRead, (unsigned)rxErrCount);
        lastRxErrLog = nowMs;
      }
      vTaskDelay(1);
      continue;
    }
    const size_t frames = min((size_t)(bytesRead / (sizeof(int32_t) * 2)), (size_t)BLOCK_FRAMES);
    float blockInputPeak[2] = {0.0f, 0.0f};
    float blockOutputPeak[4] = {0.0f, 0.0f, 0.0f, 0.0f};

    uint32_t latestRevision = 0;
    DeviceConfig latestConfig = copyConfig(latestRevision);
    if (!activeConfigValid) {
      activeConfig = latestConfig;
      activeRevision = latestRevision;
      configureDsp(activeConfig, activeRevision);
      dsp.inputMuteGain[0] = activeConfig.inputMute[0] ? 0.0f : 1.0f;
      dsp.inputMuteGain[1] = activeConfig.inputMute[1] ? 0.0f : 1.0f;
      activeConfigValid = true;
    } else if (latestRevision != activeRevision) {
      // Keep only the newest requested state while a transition is in progress.
      pendingConfig = latestConfig;
      pendingRevision = latestRevision;
      if (!pendingConfigValid) {
        pendingConfigValid = true;
        fadeUpRemaining = 0;
        fadeDownRemaining = CONFIG_FADE_DOWN_SAMPLES;
        fadeDownStep = configFade / (float)CONFIG_FADE_DOWN_SAMPLES;
      }
    }

    const DeviceConfig &c = activeConfig;
    for (size_t n = 0; n < frames; ++n) {
      if (fadeDownRemaining > 0) {
        configFade -= fadeDownStep;
        if (--fadeDownRemaining == 0) configFade = 0.0f;
      } else if (fadeUpRemaining > 0) {
        configFade += fadeUpStep;
        if (--fadeUpRemaining == 0) configFade = 1.0f;
      }

      // PCM1808 24-bit I2S samples are left-aligned in 32-bit slots.
      const float rawL = (float)(input[n * 2] >> 8) / 8388608.0f;
      const float rawR = (float)(input[n * 2 + 1] >> 8) / 8388608.0f;
      blockInputPeak[0] = max(blockInputPeak[0], fabsf(rawL));
      blockInputPeak[1] = max(blockInputPeak[1], fabsf(rawR));
      // Input mute is ramped over 10 ms to avoid clicks when muting/unmuting.
      const float inputMuteStep = 1.0f / (SAMPLE_RATE * 0.010f);
      const float targetInputMuteL = c.inputMute[0] ? 0.0f : 1.0f;
      const float targetInputMuteR = c.inputMute[1] ? 0.0f : 1.0f;
      if (dsp.inputMuteGain[0] < targetInputMuteL) dsp.inputMuteGain[0] = min(targetInputMuteL, dsp.inputMuteGain[0] + inputMuteStep);
      else if (dsp.inputMuteGain[0] > targetInputMuteL) dsp.inputMuteGain[0] = max(targetInputMuteL, dsp.inputMuteGain[0] - inputMuteStep);
      if (dsp.inputMuteGain[1] < targetInputMuteR) dsp.inputMuteGain[1] = min(targetInputMuteR, dsp.inputMuteGain[1] + inputMuteStep);
      else if (dsp.inputMuteGain[1] > targetInputMuteR) dsp.inputMuteGain[1] = max(targetInputMuteR, dsp.inputMuteGain[1] - inputMuteStep);

      float inL = rawL * dsp.inputGainLinear[0].next() * dsp.inputMuteGain[0];
      float inR = rawR * dsp.inputGainLinear[1].next() * dsp.inputMuteGain[1];

      // INPUT 9-BAND EQ runs BEFORE input HPF/LPF crossover. Factory/default curve is FLAT:
      // every band is 0 dB and OFF; users can shape the full-range signal before crossover.
      for (size_t b = 0; b < EQ_BANDS; ++b) {
        if (eqIsActive(c.inputEq[0][b])) inL = dsp.inputEq[0][b].process(inL);
        if (eqIsActive(c.inputEq[1][b])) inR = dsp.inputEq[1][b].process(inR);
      }
      // Complete independent DSP chains for ADC INPUT L and INPUT R.
      const InputDspConfig &inCfgL = c.inputDsp[0];
      const InputDspConfig &inCfgR = c.inputDsp[1];
      if (!inCfgL.crossoverBypass) {
        const uint8_t stages = slopeStages(inCfgL.hpfType, inCfgL.hpfSlope);
        for (uint8_t st = 0; st < stages; ++st) inL = dsp.inputHpf[0][st].process(inL);
        const uint8_t lStages = slopeStages(inCfgL.lpfType, inCfgL.lpfSlope);
        for (uint8_t st = 0; st < lStages; ++st) inL = dsp.inputLpf[0][st].process(inL);
      }
      if (!inCfgR.crossoverBypass) {
        const uint8_t stages = slopeStages(inCfgR.hpfType, inCfgR.hpfSlope);
        for (uint8_t st = 0; st < stages; ++st) inR = dsp.inputHpf[1][st].process(inR);
        const uint8_t lStages = slopeStages(inCfgR.lpfType, inCfgR.lpfSlope);
        for (uint8_t st = 0; st < lStages; ++st) inR = dsp.inputLpf[1][st].process(inR);
      }
      if (inCfgL.delayMs > 0.01f) inL = runInputDelay(inL, 0, inCfgL.delayMs);
      if (inCfgR.delayMs > 0.01f) inR = runInputDelay(inR, 1, inCfgR.delayMs);
      if (inCfgL.dynamicsEnabled) inL = runInputDynamics(inL, 0, dsp.inputCompressorCurve[0]);
      if (inCfgR.dynamicsEnabled) inR = runInputDynamics(inR, 1, dsp.inputCompressorCurve[1]);

      float outSample[4];
      for (int ch = 0; ch < 4; ++ch) {
        const OutputConfig &o = c.output[ch];
        float y = 0.0f;
        uint8_t routeCount = 0;
        if (c.inputRoute[0][ch]) { y += inL; ++routeCount; }
        if (c.inputRoute[1][ch]) { y += inR; ++routeCount; }
        if (routeCount > 1) y *= (1.0f / (float)routeCount);
        // No checked route means silence on this output.
        y *= dsp.outputGainLinear[ch].next();
        if (!o.crossoverBypass) {
          const uint8_t hStages = slopeStages(o.hpfType, o.hpfSlope);
          for (uint8_t st = 0; st < hStages; ++st) y = dsp.hpf[ch][st].process(y);
          const uint8_t lStages = slopeStages(o.lpfType, o.lpfSlope);
          for (uint8_t st = 0; st < lStages; ++st) y = dsp.lpf[ch][st].process(y);
        }
        for (size_t b = 0; b < EQ_BANDS; ++b) {
          if (eqIsActive(o.eq[b])) y = dsp.outputEq[ch][b].process(y);
        }
        // Neutral 0 dB identity section. No hidden high-frequency enhancement is applied.
        y = dsp.outputFixed9k[ch].process(y);
        if (o.delayMs > 0.01f) y = runDelay(y, ch, o.delayMs);
        if (o.dynamicsEnabled) y = runDynamics(y, ch, dsp.compressorCurve[ch]);
        if (o.polarityInvert) y = -y;
        const float targetMute = (o.mute || gMasterMute) ? 0.0f : 1.0f;
        const float muteStep = 1.0f / (SAMPLE_RATE * 0.010f);
        if (dsp.muteGain[ch] < targetMute) dsp.muteGain[ch] = min(targetMute, dsp.muteGain[ch] + muteStep);
        else if (dsp.muteGain[ch] > targetMute) dsp.muteGain[ch] = max(targetMute, dsp.muteGain[ch] - muteStep);

        y *= dsp.muteGain[ch];
        y *= configFade;
        y = softLimitSample(y);
        outSample[ch] = y;
        blockOutputPeak[ch] = max(blockOutputPeak[ch], fabsf(y));
      }

      if (gRtaCaptureEnabled && gRtaMemoryReady) {
        // Stereo RTA tap: processed PCM1808 input L/R, before matrix routing and output DSP.
        // This keeps the analyser tied to the two input channels, never to OUT1..OUT4.
        gRtaBuffers[gRtaWriteBank][0][rtaWritePosition] = inL;
        gRtaBuffers[gRtaWriteBank][1][rtaWritePosition] = inR;
        if (++rtaWritePosition >= RTA_SAMPLES) {
          portENTER_CRITICAL(&gRtaMux);
          const uint8_t completedBank = gRtaWriteBank;
          gRtaPublishedBank = completedBank;
          ++gRtaSequence;
          int8_t nextWriteBank = -1;
          for (uint8_t bank = 0; bank < RTA_BANKS; ++bank) {
            if (bank != gRtaPublishedBank && (int8_t)bank != gRtaReadBank) {
              nextWriteBank = (int8_t)bank;
              break;
            }
          }
          if (nextWriteBank >= 0) gRtaWriteBank = (uint8_t)nextWriteBank;
          portEXIT_CRITICAL(&gRtaMux);
          rtaWritePosition = 0;
        }
      } else {
        rtaWritePosition = 0;
      }

      const int32_t q0 = (int32_t)lrintf(outSample[0] * 8388607.0f) * 256;
      const int32_t q1 = (int32_t)lrintf(outSample[1] * 8388607.0f) * 256;
      const int32_t q2 = (int32_t)lrintf(outSample[2] * 8388607.0f) * 256;
      const int32_t q3 = (int32_t)lrintf(outSample[3] * 8388607.0f) * 256;
      outputA[n * 2] = q0;
      outputA[n * 2 + 1] = q1;
      outputB[n * 2] = q2;
      outputB[n * 2 + 1] = q3;
    }

    // Publish only one small peak snapshot per audio block; TFT reads it outside the real-time loop.
    portENTER_CRITICAL(&gMeterMux);
    gInputPeakLinear[0] = blockInputPeak[0];
    gInputPeakLinear[1] = blockInputPeak[1];
    for (int ch = 0; ch < 4; ++ch) gOutputPeakLinear[ch] = blockOutputPeak[ch];
    portEXIT_CRITICAL(&gMeterMux);

    // Apply filter/routing changes only after the previous block has faded to zero.
    size_t writtenA = 0, writtenB = 0;
    const size_t outBytes = frames * 2 * sizeof(int32_t);
    const esp_err_t wa = i2s_channel_write(i2s0Tx, outputA, outBytes, &writtenA, 1000);
    const esp_err_t wb = i2s_channel_write(i2s1Tx, outputB, outBytes, &writtenB, 1000);
    if (wa != ESP_OK || wb != ESP_OK || writtenA != outBytes || writtenB != outBytes) {
      // Reported on the serial port without printing on every audio block.
      static uint32_t lastErrLog = 0;
      if (millis() - lastErrLog > 2000) {
        Serial.printf("I2S TX write warning: A=%s (%u/%u), B=%s (%u/%u)\n",
          esp_err_to_name(wa), (unsigned)writtenA, (unsigned)outBytes,
          esp_err_to_name(wb), (unsigned)writtenB, (unsigned)outBytes);
        lastErrLog = millis();
      }
    }

    if (pendingConfigValid && fadeDownRemaining == 0) {
      activeConfig = pendingConfig;
      activeRevision = pendingRevision;
      configureDsp(activeConfig, activeRevision);
      pendingConfigValid = false;
      fadeUpRemaining = CONFIG_FADE_UP_SAMPLES;
      fadeUpStep = (1.0f - configFade) / (float)CONFIG_FADE_UP_SAMPLES;
    }
  }
}

// ----------------------------- I2S SETUP -------------------------------
static bool setupAudioI2S() {
  i2s_chan_config_t chan0 = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
  chan0.dma_desc_num = 8; // deeper DMA queue helps tolerate short UI/flash scheduling stalls
  chan0.dma_frame_num = BLOCK_FRAMES;
  esp_err_t err = i2s_new_channel(&chan0, &i2s0Tx, &i2s0Rx);
  if (err != ESP_OK) { Serial.printf("I2S0 alloc error: %s\n", esp_err_to_name(err)); return false; }

  i2s_std_config_t std0 = {};
  std0.clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(SAMPLE_RATE);
  std0.clk_cfg.mclk_multiple = I2S_MCLK_MULTIPLE_256; // 12.288 MHz for PCM1808 SCKI
  std0.slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO);
  std0.gpio_cfg.mclk = PIN_ADC_MCLK;
  std0.gpio_cfg.bclk = PIN_I2S0_BCLK;
  std0.gpio_cfg.ws = PIN_I2S0_WS;
  std0.gpio_cfg.dout = PIN_DAC1_DIN;
  std0.gpio_cfg.din = PIN_ADC_DOUT;
  std0.gpio_cfg.invert_flags.mclk_inv = false;
  std0.gpio_cfg.invert_flags.bclk_inv = false;
  std0.gpio_cfg.invert_flags.ws_inv = false;
  err = i2s_channel_init_std_mode(i2s0Tx, &std0);
  if (err != ESP_OK) { Serial.printf("I2S0 TX init error: %s\n", esp_err_to_name(err)); return false; }
  err = i2s_channel_init_std_mode(i2s0Rx, &std0);
  if (err != ESP_OK) { Serial.printf("I2S0 RX init error: %s\n", esp_err_to_name(err)); return false; }

  i2s_chan_config_t chan1 = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_1, I2S_ROLE_SLAVE);
  chan1.dma_desc_num = 8; // keep both DAC DMA queues balanced
  chan1.dma_frame_num = BLOCK_FRAMES;
  err = i2s_new_channel(&chan1, &i2s1Tx, nullptr);
  if (err != ESP_OK) { Serial.printf("I2S1 alloc error: %s\n", esp_err_to_name(err)); return false; }

  i2s_std_config_t std1 = {};
  std1.clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(SAMPLE_RATE);
  std1.clk_cfg.mclk_multiple = I2S_MCLK_MULTIPLE_256;
  std1.slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_STEREO);
  std1.gpio_cfg.mclk = I2S_GPIO_UNUSED;
  std1.gpio_cfg.bclk = PIN_I2S1_BCLK_IN;
  std1.gpio_cfg.ws = PIN_I2S1_WS_IN;
  std1.gpio_cfg.dout = PIN_DAC2_DIN;
  std1.gpio_cfg.din = I2S_GPIO_UNUSED;
  std1.gpio_cfg.invert_flags.mclk_inv = false;
  std1.gpio_cfg.invert_flags.bclk_inv = false;
  std1.gpio_cfg.invert_flags.ws_inv = false;
  err = i2s_channel_init_std_mode(i2s1Tx, &std1);
  if (err != ESP_OK) { Serial.printf("I2S1 TX init error: %s\n", esp_err_to_name(err)); return false; }

  // Route I2S1 slave clock inputs to the SAME GPIO4/GPIO5 pads driven by I2S0.
  // ESP-IDF enables each pad's input path without disconnecting its I2S0 output path.
  // Enable I2S1 first; then I2S0 starts the shared BCLK/WS clock net.
  err = i2s_channel_enable(i2s1Tx);
  if (err != ESP_OK) { Serial.printf("I2S1 enable error: %s\n", esp_err_to_name(err)); return false; }
  err = i2s_channel_enable(i2s0Tx);
  if (err != ESP_OK) { Serial.printf("I2S0 TX enable error: %s\n", esp_err_to_name(err)); return false; }
  err = i2s_channel_enable(i2s0Rx);
  if (err != ESP_OK) { Serial.printf("I2S0 RX enable error: %s\n", esp_err_to_name(err)); return false; }
  return true;
}

static bool allocateRtaMemory() {
  // 3 banks x 2 input channels + 2 snapshots = 8 x 4096 floats (~128 KiB) in PSRAM.
  for (uint8_t bank = 0; bank < RTA_BANKS; ++bank) {
    for (int ch = 0; ch < 2; ++ch) {
      gRtaBuffers[bank][ch] = (float *)heap_caps_calloc(
        RTA_SAMPLES, sizeof(float), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
      if (!gRtaBuffers[bank][ch]) goto fail;
    }
  }
  for (int ch = 0; ch < 2; ++ch) {
    gRtaSnapshot[ch] = (float *)heap_caps_calloc(
      RTA_SAMPLES, sizeof(float), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!gRtaSnapshot[ch]) goto fail;
  }
  gRtaWriteBank = 0;
  gRtaPublishedBank = 1;
  gRtaReadBank = -1;
  gRtaMemoryReady = true;
  return true;

fail:
  for (uint8_t bank = 0; bank < RTA_BANKS; ++bank) {
    for (int ch = 0; ch < 2; ++ch) {
      if (gRtaBuffers[bank][ch]) heap_caps_free(gRtaBuffers[bank][ch]);
      gRtaBuffers[bank][ch] = nullptr;
    }
  }
  for (int ch = 0; ch < 2; ++ch) {
    if (gRtaSnapshot[ch]) heap_caps_free(gRtaSnapshot[ch]);
    gRtaSnapshot[ch] = nullptr;
  }
  gRtaMemoryReady = false;
  return false;
}

static bool allocateDelayMemory() {
  const size_t bytes = (MAX_DELAY_SAMPLES + 1) * sizeof(float);
  for (int ch = 0; ch < 2; ++ch) {
    inputDelayBuffer[ch] = (float *)heap_caps_calloc(1, bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!inputDelayBuffer[ch]) inputDelayBuffer[ch] = (float *)heap_caps_calloc(1, bytes, MALLOC_CAP_8BIT);
    if (!inputDelayBuffer[ch]) { Serial.printf("Delay RAM allocation failed on input %d\n", ch + 1); return false; }
  }
  for (int ch = 0; ch < 4; ++ch) {
    delayBuffer[ch] = (float *)heap_caps_calloc(1, bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!delayBuffer[ch]) delayBuffer[ch] = (float *)heap_caps_calloc(1, bytes, MALLOC_CAP_8BIT);
    if (!delayBuffer[ch]) { Serial.printf("Delay RAM allocation failed on output %d\n", ch + 1); return false; }
  }
  return true;
}

// ----------------------------- FATFS STORAGE ----------------------------
static String storageReadText(const char *path) {
  if (!storageReady || !path) return String();
  const String backup = String(path) + ".bak";
  const String temp = String(path) + ".tmp";

  // Recover a valid backup after an interrupted power loss during atomic replacement.
  if (FFat.exists(backup.c_str())) {
    bool primaryValid = false;
    if (FFat.exists(path)) {
      File primary = FFat.open(path, FILE_READ);
      if (primary) {
        String probe = primary.readString();
        primary.close();
        JsonDocument check;
        primaryValid = probe.length() > 0 && !deserializeJson(check, probe);
      }
    }
    if (!primaryValid) {
      if (FFat.exists(path)) FFat.remove(path);
      if (!FFat.rename(backup.c_str(), path)) {
        Serial.printf("Storage recovery failed for %s\n", path);
      }
    } else {
      FFat.remove(backup.c_str());
    }
  }
  if (FFat.exists(temp.c_str())) FFat.remove(temp.c_str());
  File file = FFat.open(path, FILE_READ);
  if (!file) return String();
  String data = file.readString();
  file.close();
  return data;
}

static bool storageVerifyJsonFile(const char *path, const String &expected) {
  File checkFile = FFat.open(path, FILE_READ);
  if (!checkFile) return false;
  const size_t expectedSize = expected.length();
  const size_t actualSize = checkFile.size();
  String actual = checkFile.readString();
  checkFile.close();
  if (actualSize != expectedSize || actual != expected) return false;
  JsonDocument validation;
  return !deserializeJson(validation, actual);
}

static bool storageWriteAtomic(const char *path, const String &data) {
  if (!storageReady || !path || data.length() == 0) return false;
  const String temp = String(path) + ".tmp";
  const String backup = String(path) + ".bak";
  if (FFat.exists(temp.c_str())) FFat.remove(temp.c_str());

  File file = FFat.open(temp.c_str(), FILE_WRITE);
  if (!file) return false;
  const size_t written = file.print(data);
  file.flush();
  const size_t tempSize = file.size();
  file.close();
  // The byte count and flushed file size validate the temporary write. Do one
  // exact JSON read-back only AFTER rename; this avoids reading/parsing the same
  // large preset payload twice while retaining rollback protection.
  if (written != data.length() || tempSize != data.length()) {
    FFat.remove(temp.c_str());
    return false;
  }

  // Preserve the previous file until the newly renamed file has passed read-back validation.
  if (FFat.exists(backup.c_str())) FFat.remove(backup.c_str());
  const bool hadOld = FFat.exists(path);
  if (hadOld && !FFat.rename(path, backup.c_str())) {
    FFat.remove(temp.c_str());
    return false;
  }
  if (!FFat.rename(temp.c_str(), path)) {
    if (hadOld) FFat.rename(backup.c_str(), path);
    FFat.remove(temp.c_str());
    return false;
  }
  if (!storageVerifyJsonFile(path, data)) {
    FFat.remove(path);
    if (hadOld) FFat.rename(backup.c_str(), path);
    return false;
  }
  if (FFat.exists(backup.c_str())) FFat.remove(backup.c_str());
  return true;
}

// Channel names are global UI labels, stored separately from DSP presets so loading a
// program never overwrites the user's IN/OUT naming.
static constexpr const char *CHANNEL_NAMES_PATH = "/leon_channel_names.json";
static bool saveChannelNames();
static void loadChannelNames();
static void engageMasterMuteForStorage();

static constexpr const char *PRESET_DIRECTORY = "/leon_presets_v059";
static constexpr const char *EQ_FLAT_MIGRATION_PATH = "/leon_v085_eq_flat_saved.done";
static String programPath(int slot) {
  char path[64];
  snprintf(path, sizeof(path), "%s/program%d.json", PRESET_DIRECTORY, slot);
  return String(path);
}
// One-time v0.8.5 migration: make the currently active six-channel EQ bank flat.
// The five saved program files are deliberately not changed or deleted.
static bool flattenActiveEqForV085() {
  static const float flatFrequencies[EQ_BANDS] = {
    31.5f, 63.0f, 125.0f, 250.0f, 500.0f, 1000.0f, 2000.0f, 4000.0f, 8000.0f
  };
  bool changed = false;
  portENTER_CRITICAL(&gConfigMux);
  for (int ch = 0; ch < 2; ++ch) {
    for (size_t band = 0; band < EQ_BANDS; ++band) {
      EqBand &e = gConfig.inputEq[ch][band];
      if (e.enabled || fabsf(e.frequency - flatFrequencies[band]) > 0.001f ||
          fabsf(e.gainDb) > 0.001f || fabsf(e.q - 1.0f) > 0.001f) changed = true;
      e.enabled = false;
      e.frequency = flatFrequencies[band];
      e.gainDb = 0.0f;
      e.q = 1.0f;
    }
  }
  for (int ch = 0; ch < 4; ++ch) {
    for (size_t band = 0; band < EQ_BANDS; ++band) {
      EqBand &e = gConfig.output[ch].eq[band];
      if (e.enabled || fabsf(e.frequency - flatFrequencies[band]) > 0.001f ||
          fabsf(e.gainDb) > 0.001f || fabsf(e.q - 1.0f) > 0.001f) changed = true;
      e.enabled = false;
      e.frequency = flatFrequencies[band];
      e.gainDb = 0.0f;
      e.q = 1.0f;
    }
  }
  if (changed) ++gConfigRevision;
  portEXIT_CRITICAL(&gConfigMux);
  if (changed) {
    configDirty = true;
    lastConfigChange = millis();
  }
  return changed;
}

// ----------------------------- LOCAL TFT UI -----------------------------
// Modern dark-console palette (RGB565). UI uses vector icons and compact diagrams.
static constexpr uint16_t UI_BG       = 0x0007; // near-black navy
static constexpr uint16_t UI_PANEL    = 0x10A4; // deep blue panel
static constexpr uint16_t UI_PANEL2   = 0x2128; // selected / raised panel
static constexpr uint16_t UI_BLUE     = 0x125F; // electric blue
static constexpr uint16_t UI_CYAN     = 0x07FF; // cyan accent
static constexpr uint16_t UI_YELLOW   = 0xFFE0; // selection/value
static constexpr uint16_t UI_GREEN    = 0x07E0; // healthy / low level
static constexpr uint16_t UI_NEON_GREEN = 0x3FE2; // highlighter/neon green outer LCD frame (RGB565)
static constexpr uint16_t UI_RED      = 0xF986; // warning / edit
static constexpr uint16_t UI_WHITE    = 0xFFFF;
static constexpr uint16_t UI_GRID     = 0x2128;
static constexpr uint16_t UI_EDGE     = 0x4AAB; // replaced below for readability
enum UiPage : uint8_t { UI_HOME, UI_MENU_PAGE, UI_MATRIX, UI_LEVEL, UI_INPUT, UI_OUTPUT, UI_EQ, UI_CROSS, UI_DELAY, UI_DYNAMICS, UI_POLARITY, UI_RTA, UI_PRESET, UI_SYSTEM };
static UiPage uiPage = UI_HOME; // preserve the initial HOME screen as the 3x3 app grid
static int uiMenuIndex = 0; // app-grid selection
static int uiHomeIndex = 0; // 6 channel tiles + master mute
static uint32_t lastHomeMeterDraw = 0;
static int uiCursor = 0;
static bool uiEditing = false;
static bool uiDirty = true;
static bool rtaHold = false;
static uint8_t uiInputChannel = 0;
static uint8_t uiOutputChannel = 0;
static bool uiDspTargetInput = false; // shared EQ/XOVER/DELAY/COMP pages can edit either side
static uint8_t uiEqBand = 0;
static uint8_t uiPresetSlot = 1;
static PresetConfirmAction presetConfirmAction = PRESET_CONFIRM_NONE;
static bool presetConfirmYesSelected = false; // Safe default: BATAL is selected until the user rotates.
static uint8_t activePresetSlot = 0; // 0 = unsaved/standard active configuration
static bool lastPresetPointerClearPending = false;
static UiPage uiLastConfigPage = UI_EQ;
static uint8_t rotaryPrevState = 0;
static int8_t rotaryQuarterSteps = 0;
static bool rotaryButtonDown = false;
static bool rotaryLongHandled = false;
static bool rotaryRawLast = true;
static uint32_t rotaryRawChangedAt = 0;
static uint32_t rotaryDownAt = 0;
static uint32_t rotaryLastDetentUs = 0; // retained for diagnostics only
static char gPresetNames[5][13] = {"STANDARD", "STANDARD", "STANDARD", "STANDARD", "STANDARD"};
static uint8_t presetNamePos = 0;
static const char PRESET_CHARSET[] = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_";
static char gInputNames[2][11] = {"IN 1", "IN 2"};
static char gOutputNames[4][11] = {"OUT 1", "OUT 2", "OUT 3", "OUT 4"};
static uint8_t channelNamePos = 0;
static NumericEditField numericEditField = NUM_EDIT_NONE;
static char numericEditBuffer[12] = "";
static uint8_t numericEditPos = 0;

// Incremental TFT redraw state: encoder movement must never clear the whole display.
enum UiPartialMode : uint8_t { UI_PARTIAL_NONE, UI_PARTIAL_MENU, UI_PARTIAL_PAGE, UI_PARTIAL_VALUE, UI_PARTIAL_PRESET_NAME };
static UiPartialMode uiPartialMode = UI_PARTIAL_NONE;
static int uiPartialOldIndex = -1;
static int uiPartialOldWindow = -1;
static bool uiPartialGraphDirty = false;
static bool uiPartialValueOnly = false;
static bool uiPendingGraphRefresh = false;
static uint32_t lastGraphRefreshAt = 0;
static constexpr uint32_t GRAPH_REFRESH_INTERVAL_MS = 60;

static uint32_t presetChecksum(const String &text);
static bool readPresetEnvelope(uint8_t slot, JsonDocument &doc, String &stateOut, String &nameOut);
static bool presetSlotSaved(uint8_t slot);
// Rendering the PRESETS graph must never touch FFat. This cache is refreshed at
// boot and after a SAVE/LOAD validation, not while drawing each frame.
static bool gPresetSavedCache[5] = {false, false, false, false, false};

static void loadPresetNameCache() {
  for (uint8_t slot = 1; slot <= 5; ++slot) {
    gPresetSavedCache[slot - 1] = false;
    snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "STANDARD");
    JsonDocument envelope;
    String state, storedName;
    if (!readPresetEnvelope(slot, envelope, state, storedName)) continue;
    gPresetSavedCache[slot - 1] = true;
    snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "%s", storedName.c_str());
    int end = 11;
    while (end >= 0 && gPresetNames[slot - 1][end] == ' ') gPresetNames[slot - 1][end--] = '\0';
    if (!gPresetNames[slot - 1][0]) snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "STANDARD");
  }
}

static uint32_t lastUiDraw = 0;
static uint32_t lastRtaCompute = 0;
static uint32_t lastActiveSaveLog = 0;
static char uiNotice[22] = "";

static const char *const UI_MENU[] = {
  "MATRIX", "EQUALIZER", "CROSSOVER", "DELAY", "DYNAMICS", "GAIN", "PRESETS", "SYSTEM", "RTA"
};
static const float RTA_FREQUENCIES[RTA_BANDS] = {
  20.0f, 31.7f, 50.3f, 79.6f, 126.2f, 200.0f, 317.0f, 502.4f,
  796.2f, 1261.9f, 2000.0f, 3169.8f, 5023.8f, 6324.6f, 7962.1f,
  9000.0f, 11220.0f, 14125.0f, 17783.0f, 20000.0f
};

static const char *filterName(uint8_t type) {
  if (type == FILTER_LINKWITZ_RILEY) return "LINK-RILEY";
  if (type == FILTER_BESSEL) return "BESSEL";
  return "BUTTERWORTH";
}
static String formatHz(float hz) {
  // Compact display for the 160x128 TFT; exact integer Hz is shown while editing.
  const int value = (int)lroundf(clampf(hz, 20.0f, 20000.0f));
  if (value >= 10000) return String(value / 1000) + "k";
  if (value >= 1000) return String(value / 1000.0f, 1) + "k";
  return String(value) + "Hz";
}
static NumericEditField currentNumericEditField();
static String uiItemLabel(int index) {
  // Abbreviations are sized for one clean line in the 73-pixel right panel.
  static const char *const levelItems[] = {"BACK", "CH", "GAIN", "MUTE", "PHASE"};
  static const char *const eqItems[] = {"BACK", "CH", "BAND", "ON", "FREQ", "GAIN", "Q"};
  static const char *const crossItems[] = {"BACK", "CH", "BYP", "HPF", "H", "LPF", "L"};
  static const char *const delayItems[] = {"BACK", "CH", "DLY"};
  static const char *const dynItems[] = {"BACK", "CH", "COMP", "THR", "RATIO", "ATT", "REL"};
  static const char *const polarityItems[] = {"BACK", "CH", "PHASE"};
  static const char *const presetItems[] = {"BACK", "SLOT", "NAME", "STORE", "LOAD", "RESET"};
  static const char *const systemItems[] = {"BACK", "AUD", "RATE", "STOR"};
  switch (uiPage) {
    case UI_LEVEL: return levelItems[constrain(index, 0, 4)];
    case UI_EQ: return eqItems[constrain(index, 0, 6)];
    case UI_CROSS: return crossItems[constrain(index, 0, 6)];
    case UI_DELAY: return delayItems[constrain(index, 0, 2)];
    case UI_DYNAMICS: return dynItems[constrain(index, 0, 6)];
    case UI_POLARITY: return polarityItems[constrain(index, 0, 2)];
    case UI_PRESET: return presetItems[constrain(index, 0, 5)];
    case UI_SYSTEM: return systemItems[constrain(index, 0, 3)];
    default: return "";
  }
}
static int uiItemCount() {
  switch (uiPage) {
    case UI_MATRIX: return 8;
    case UI_LEVEL: return 5;
    case UI_EQ: return 7;
    case UI_CROSS: return 7;
    case UI_DELAY: return 3;
    case UI_DYNAMICS: return 7;
    case UI_POLARITY: return 3;
    case UI_PRESET: return 6;
    case UI_SYSTEM: return 4;
    default: return 0;
  }
}
static NumericEditField currentNumericEditField() {
  switch (uiPage) {
    case UI_LEVEL:
      if (uiCursor == 2) return uiDspTargetInput ? NUM_EDIT_INPUT_GAIN : NUM_EDIT_OUTPUT_GAIN;
      break;
    case UI_INPUT:
      if (uiCursor == 3) return NUM_EDIT_INPUT_GAIN;
      if (uiCursor == 5) return NUM_EDIT_DELAY_MS;
      break;
    case UI_OUTPUT:
      if (uiCursor == 4) return NUM_EDIT_OUTPUT_GAIN;
      break;
    case UI_EQ:
      if (uiCursor == 4) return NUM_EDIT_EQ_FREQ;
      if (uiCursor == 5) return NUM_EDIT_EQ_GAIN;
      if (uiCursor == 6) return NUM_EDIT_EQ_Q;
      break;
    case UI_CROSS:
      if (uiCursor == 3) return NUM_EDIT_HPF_FREQ;
      if (uiCursor == 5) return NUM_EDIT_LPF_FREQ;
      break;
    case UI_DELAY:
      if (uiCursor == 2) return NUM_EDIT_DELAY_MS;
      break;
    case UI_DYNAMICS:
      if (uiCursor == 3) return NUM_EDIT_THRESHOLD_DB;
      if (uiCursor == 4) return NUM_EDIT_RATIO;
      if (uiCursor == 5) return NUM_EDIT_ATTACK_MS;
      if (uiCursor == 6) return NUM_EDIT_RELEASE_MS;
      break;
    default: break;
  }
  return NUM_EDIT_NONE;
}

static String uiItemValue(int index, const DeviceConfig &c) {
  const OutputConfig &o = c.output[uiOutputChannel];
  const InputDspConfig &in = c.inputDsp[uiInputChannel];
  auto channelLabel = []() -> String {
    // Channel selectors always show stable IDs, even when custom names are enabled.
    return uiDspTargetInput ? (String("IN") + String(uiInputChannel + 1))
                            : (String("OUT") + String(uiOutputChannel + 1));
  };
  auto combinedFilterSlope = [](uint8_t type, uint8_t slope) -> String {
    const String typeText = (type == FILTER_LINKWITZ_RILEY) ? String("LINK-R") :
                            (type == FILTER_BESSEL) ? String("BESSEL") : String("BUTTER");
    // Compact 160x128 TFT notation: H:BESSEL 36 / L:LINK-R 24. Suffix is dB/oct.
    return typeText + String(" ") + String((int)slope);
  };

  if (numericEditField != NUM_EDIT_NONE && numericEditField == currentNumericEditField() && index == uiCursor) {
    String editValue(numericEditBuffer);
    if (numericEditField == NUM_EDIT_RATIO) editValue += ":1";
    return editValue;
  }

  switch (uiPage) {
    case UI_LEVEL:
      if (index == 1) return channelLabel();
      if (index == 2) return String(uiDspTargetInput ? c.inputGainDb[uiInputChannel] : o.gainDb, 1);
      if (index == 3) return (uiDspTargetInput ? c.inputMute[uiInputChannel] : o.mute) ? "ON" : "OFF";
      if (index == 4) return uiDspTargetInput ? "N/A" : (o.polarityInvert ? "INV" : "NORM");
      break;
    case UI_EQ: {
      const EqBand &e = uiDspTargetInput ? c.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      if (index == 1) return channelLabel();
      if (index == 2) return String("B") + String(uiEqBand + 1);
      if (index == 3) return e.enabled ? "ON" : "OFF";
      if (index == 4) return formatHz(e.frequency);
      if (index == 5) return String(e.gainDb, 1);
      if (index == 6) return String(e.q, 2);
      break;
    }
    case UI_CROSS:
      if (index == 1) return channelLabel();
      if (index == 2) return (uiDspTargetInput ? in.crossoverBypass : o.crossoverBypass) ? "BYP" : "ON";
      if (index == 3) return formatHz(uiDspTargetInput ? in.hpfHz : o.hpfHz);
      if (index == 4) return combinedFilterSlope(uiDspTargetInput ? in.hpfType : o.hpfType,
                                                  uiDspTargetInput ? in.hpfSlope : o.hpfSlope);
      if (index == 5) return formatHz(uiDspTargetInput ? in.lpfHz : o.lpfHz);
      if (index == 6) return combinedFilterSlope(uiDspTargetInput ? in.lpfType : o.lpfType,
                                                  uiDspTargetInput ? in.lpfSlope : o.lpfSlope);
      break;
    case UI_DELAY:
      if (index == 1) return channelLabel();
      if (index == 2) return String(uiDspTargetInput ? in.delayMs : o.delayMs, 1);
      break;
    case UI_DYNAMICS:
      if (index == 1) return channelLabel();
      if (index == 2) return (uiDspTargetInput ? in.dynamicsEnabled : o.dynamicsEnabled) ? "ON" : "OFF";
      if (index == 3) return String(uiDspTargetInput ? in.thresholdDb : o.thresholdDb, 1);
      if (index == 4) return String((int)lroundf(uiDspTargetInput ? in.ratio : o.ratio)) + ":1";
      if (index == 5) return String(uiDspTargetInput ? in.attackMs : o.attackMs, 0) + "ms";
      if (index == 6) return String(uiDspTargetInput ? in.releaseMs : o.releaseMs, 0) + "ms";
      break;
    case UI_POLARITY:
      if (index == 1) return String("OUT") + String(uiOutputChannel + 1);
      if (index == 2) return o.polarityInvert ? "INV" : "NORM";
      break;
    case UI_PRESET:
      if (index == 1) return String("P") + String(uiPresetSlot) + (presetSlotSaved(uiPresetSlot) ? "S" : "E");
      if (index == 2) {
        String name = String(gPresetNames[uiPresetSlot - 1]);
        if (!uiEditing) name.trim(); // Keep padded spaces visible while editing the last name characters.
        return name.substring(0, 10);
      }
      if (index == 3) return "SAVE";
      if (index == 4) return "LOAD";
      if (index == 5) return "STD";
      break;
    case UI_SYSTEM:
      if (index == 1) return audioReady ? "READY" : "STOP";
      if (index == 2) return "48kHz";
      if (index == 3) return storageReady ? "READY" : "ERROR";
      break;
    default: break;
  }
  return "";
}

static void markConfigChanged(bool preserveActivePreset = false) {
  configDirty = true;
  lastConfigChange = millis();
  if (!preserveActivePreset && activePresetSlot > 0) {
    // Defer pointer removal until the modified active state has been safely
    // committed to FFat. A sudden power loss cannot mark unsaved edits as saved.
    lastPresetPointerClearPending = true;
    activePresetSlot = 0;
  }
}
static int pageFirstVisibleRow(int cursor) { return (cursor > 5) ? cursor - 5 : 0; }
static void requestMenuPartial(int oldIndex, int oldWindow) {
  if (uiPartialMode != UI_PARTIAL_MENU) {
    uiPartialOldIndex = oldIndex;
    uiPartialOldWindow = oldWindow;
  }
  uiPartialMode = UI_PARTIAL_MENU;
  uiDirty = false;
}
static void requestPagePartial(int oldCursor, bool graphDirty) {
  if (uiPartialMode != UI_PARTIAL_PAGE) {
    uiPartialOldIndex = oldCursor;
    uiPartialOldWindow = pageFirstVisibleRow(oldCursor);
  }
  uiPartialMode = UI_PARTIAL_PAGE;
  uiPartialGraphDirty = uiPartialGraphDirty || graphDirty;
  uiDirty = false;
}
static void requestPageValuePartial(bool presetNameOnly = false) {
  uiPartialMode = presetNameOnly ? UI_PARTIAL_PRESET_NAME : UI_PARTIAL_VALUE;
  uiPartialOldIndex = uiCursor;
  uiPartialOldWindow = pageFirstVisibleRow(uiCursor);
  uiPartialGraphDirty = false;
  uiPartialValueOnly = true;
  uiDirty = false;
}
static void clearPartialUiState() {
  uiPartialMode = UI_PARTIAL_NONE;
  uiPartialOldIndex = -1;
  uiPartialOldWindow = -1;
  uiPartialGraphDirty = false;
  uiPartialValueOnly = false;
}
static float rotaryStepFactor() { return 1.0f; }

static void trimPresetName(uint8_t slot) {
  if (slot < 1 || slot > 5) return;
  char *name = gPresetNames[slot - 1];
  int end = 9;
  while (end >= 0 && (name[end] == ' ' || name[end] == '\0')) name[end--] = '\0';
  name[10] = '\0';
  if (name[0] == '\0') snprintf(name, 13, "STANDARD");
}
static void beginPresetNameEdit() {
  char *name = gPresetNames[uiPresetSlot - 1];
  const size_t len = strlen(name);
  for (size_t i = len; i < 10; ++i) name[i] = ' ';
  name[10] = '\0';
  presetNamePos = 0;
  uiEditing = true;
}
static void adjustPresetNameChar(int direction) {
  char *name = gPresetNames[uiPresetSlot - 1];
  int current = 0;
  const int count = (int)sizeof(PRESET_CHARSET) - 1;
  for (int i = 0; i < count; ++i) if (PRESET_CHARSET[i] == name[presetNamePos]) { current = i; break; }
  const int step = (int)rotaryStepFactor();
  current = (current + (direction > 0 ? step : -step) + count * 4) % count;
  name[presetNamePos] = PRESET_CHARSET[current];
}
static void finishPresetNameEdit() {
  trimPresetName(uiPresetSlot);
  uiEditing = false;
  // Name-only edits update only the name cell; the DSP graph is unchanged.
  requestPageValuePartial(true);
}
static char *currentChannelNameBuffer() {
  if (uiPage == UI_INPUT) return gInputNames[uiInputChannel];
  if (uiPage == UI_OUTPUT) return gOutputNames[uiOutputChannel];
  return nullptr;
}
static void beginChannelNameEdit() {
  char *name = currentChannelNameBuffer();
  if (!name) return;
  size_t len = strlen(name);
  for (size_t i = len; i < 10; ++i) name[i] = ' ';
  name[10] = '\0';
  channelNamePos = 0;
  uiEditing = true;
}
static void adjustChannelNameChar(int direction) {
  char *name = currentChannelNameBuffer();
  if (!name) return;
  int current = 0;
  const int count = (int)sizeof(PRESET_CHARSET) - 1;
  for (int i = 0; i < count; ++i) if (PRESET_CHARSET[i] == name[channelNamePos]) { current = i; break; }
  current = (current + (direction > 0 ? 1 : -1) + count) % count;
  name[channelNamePos] = PRESET_CHARSET[current];
}
static void trimChannelName(char *name, const char *fallback) {
  if (!name) return;
  int end = 9;
  while (end >= 0 && (name[end] == ' ' || name[end] == '\0')) name[end--] = '\0';
  name[10] = '\0';
  if (!name[0]) snprintf(name, 11, "%s", fallback);
}
static bool saveChannelNames() {
  if (!storageReady) return false;
  engageMasterMuteForStorage(); // keep FFat writes away from active audio playback
  JsonDocument doc;
  doc["version"] = 1;
  JsonArray in = doc["inputs"].to<JsonArray>();
  for (int i = 0; i < 2; ++i) in.add(gInputNames[i]);
  JsonArray out = doc["outputs"].to<JsonArray>();
  for (int i = 0; i < 4; ++i) out.add(gOutputNames[i]);
  String payload;
  serializeJson(doc, payload);
  return storageWriteAtomic(CHANNEL_NAMES_PATH, payload);
}
static void loadChannelNames() {
  if (!storageReady) return;
  const String payload = storageReadText(CHANNEL_NAMES_PATH);
  if (!payload.length()) return;
  JsonDocument doc;
  if (deserializeJson(doc, payload)) return;
  JsonArrayConst in = doc["inputs"].as<JsonArrayConst>();
  JsonArrayConst out = doc["outputs"].as<JsonArrayConst>();
  if (in.size() == 2) {
    for (int i = 0; i < 2; ++i) {
      String value = in[i].as<String>();
      value.trim();
      if (value.length() > 0) snprintf(gInputNames[i], sizeof(gInputNames[i]), "%s", value.substring(0, 10).c_str());
    }
  }
  if (out.size() == 4) {
    for (int i = 0; i < 4; ++i) {
      String value = out[i].as<String>();
      value.trim();
      if (value.length() > 0) snprintf(gOutputNames[i], sizeof(gOutputNames[i]), "%s", value.substring(0, 10).c_str());
    }
  }
}
static void finishChannelNameEdit() {
  char *name = currentChannelNameBuffer();
  if (!name) { uiEditing = false; return; }
  const bool isInput = (uiPage == UI_INPUT);
  const uint8_t channel = isInput ? uiInputChannel : uiOutputChannel;
  char fallback[11];
  if (isInput) snprintf(fallback, sizeof(fallback), "IN %u", channel + 1);
  else snprintf(fallback, sizeof(fallback), "OUT %u", channel + 1);
  trimChannelName(name, fallback);
  const bool saved = saveChannelNames();
  uiEditing = false;
  snprintf(uiNotice, sizeof(uiNotice), saved ? "NAME SAVED - MUTED" : "NAME RAM ONLY");
  requestPageValuePartial(false);
  uiPendingGraphRefresh = true;
}
static uint8_t currentDspChannelIndex() {
  return uiDspTargetInput ? uiInputChannel : (uint8_t)(2 + uiOutputChannel);
}
static void setDspChannelIndex(uint8_t index) {
  index %= 6;
  if (index < 2) { uiDspTargetInput = true; uiInputChannel = index; }
  else { uiDspTargetInput = false; uiOutputChannel = (uint8_t)(index - 2); }
}
static void cycleDspChannel(int direction) {
  const int next = (currentDspChannelIndex() + (direction > 0 ? 1 : 5)) % 6;
  setDspChannelIndex((uint8_t)next);
}

static bool isNumericEditChar(char ch) {
  return (ch >= '0' && ch <= '9') || ch == '+' || ch == '-';
}

static bool numericEditRange(NumericEditField field, float &minimum, float &maximum) {
  switch (field) {
    case NUM_EDIT_INPUT_GAIN:   minimum = -30.0f; maximum = 12.0f; return true;
    case NUM_EDIT_OUTPUT_GAIN:  minimum = -60.0f; maximum = 12.0f; return true;
    case NUM_EDIT_EQ_FREQ:
    case NUM_EDIT_HPF_FREQ:
    case NUM_EDIT_LPF_FREQ:     minimum = 20.0f; maximum = 20000.0f; return true;
    case NUM_EDIT_EQ_GAIN:      minimum = -15.0f; maximum = 15.0f; return true;
    case NUM_EDIT_EQ_Q:         minimum = 0.4f; maximum = 12.0f; return true;
    case NUM_EDIT_DELAY_MS:     minimum = 0.0f; maximum = 300.0f; return true;
    case NUM_EDIT_THRESHOLD_DB: minimum = -60.0f; maximum = 12.0f; return true;
    case NUM_EDIT_RATIO:        minimum = 1.0f; maximum = 20.0f; return true;
    case NUM_EDIT_ATTACK_MS:    minimum = 0.1f; maximum = 100.0f; return true;
    case NUM_EDIT_RELEASE_MS:   minimum = 10.0f; maximum = 1000.0f; return true;
    default: return false;
  }
}

static float readNumericEditValue(NumericEditField field, const DeviceConfig &c) {
  const OutputConfig &o = c.output[uiOutputChannel];
  const InputDspConfig &in = c.inputDsp[uiInputChannel];
  switch (field) {
    case NUM_EDIT_INPUT_GAIN: return c.inputGainDb[uiInputChannel];
    case NUM_EDIT_OUTPUT_GAIN: return o.gainDb;
    case NUM_EDIT_EQ_FREQ: {
      const EqBand &e = uiDspTargetInput ? c.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      return e.frequency;
    }
    case NUM_EDIT_EQ_GAIN: {
      const EqBand &e = uiDspTargetInput ? c.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      return e.gainDb;
    }
    case NUM_EDIT_EQ_Q: {
      const EqBand &e = uiDspTargetInput ? c.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      return e.q;
    }
    case NUM_EDIT_HPF_FREQ: return uiDspTargetInput ? in.hpfHz : o.hpfHz;
    case NUM_EDIT_LPF_FREQ: return uiDspTargetInput ? in.lpfHz : o.lpfHz;
    case NUM_EDIT_DELAY_MS: return uiDspTargetInput ? in.delayMs : o.delayMs;
    case NUM_EDIT_THRESHOLD_DB: return uiDspTargetInput ? in.thresholdDb : o.thresholdDb;
    case NUM_EDIT_RATIO: return uiDspTargetInput ? in.ratio : o.ratio;
    case NUM_EDIT_ATTACK_MS: return uiDspTargetInput ? in.attackMs : o.attackMs;
    case NUM_EDIT_RELEASE_MS: return uiDspTargetInput ? in.releaseMs : o.releaseMs;
    default: return 0.0f;
  }
}

static void formatNumericEditBuffer(NumericEditField field, float value) {
  if (fabsf(value) < 0.0005f) value = 0.0f;
  switch (field) {
    case NUM_EDIT_INPUT_GAIN:
    case NUM_EDIT_OUTPUT_GAIN:
    case NUM_EDIT_EQ_GAIN:
    case NUM_EDIT_THRESHOLD_DB:
      snprintf(numericEditBuffer, sizeof(numericEditBuffer), "%+05.1f", (double)value);
      break;
    case NUM_EDIT_EQ_FREQ:
    case NUM_EDIT_HPF_FREQ:
    case NUM_EDIT_LPF_FREQ:
      snprintf(numericEditBuffer, sizeof(numericEditBuffer), "%05d", constrain((int)lroundf(value), 20, 20000));
      break;
    case NUM_EDIT_EQ_Q:
      snprintf(numericEditBuffer, sizeof(numericEditBuffer), "%05.2f", (double)value);
      break;
    case NUM_EDIT_DELAY_MS:
    case NUM_EDIT_ATTACK_MS:
      snprintf(numericEditBuffer, sizeof(numericEditBuffer), "%05.1f", (double)value);
      break;
    case NUM_EDIT_RATIO:
      snprintf(numericEditBuffer, sizeof(numericEditBuffer), "%02d", constrain((int)lroundf(value), 1, 20));
      break;
    case NUM_EDIT_RELEASE_MS:
      snprintf(numericEditBuffer, sizeof(numericEditBuffer), "%04d", constrain((int)lroundf(value), 10, 1000));
      break;
    default:
      numericEditBuffer[0] = '\0';
      break;
  }
}

static float parseNumericEditBuffer() {
  return (float)atof(numericEditBuffer);
}

static void writeNumericEditValue(NumericEditField field, float value) {
  portENTER_CRITICAL(&gConfigMux);
  OutputConfig &o = gConfig.output[uiOutputChannel];
  InputDspConfig &in = gConfig.inputDsp[uiInputChannel];
  switch (field) {
    case NUM_EDIT_INPUT_GAIN: gConfig.inputGainDb[uiInputChannel] = value; break;
    case NUM_EDIT_OUTPUT_GAIN: o.gainDb = value; break;
    case NUM_EDIT_EQ_FREQ: {
      EqBand &e = uiDspTargetInput ? gConfig.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      e.frequency = value; break;
    }
    case NUM_EDIT_EQ_GAIN: {
      EqBand &e = uiDspTargetInput ? gConfig.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      e.gainDb = value; break;
    }
    case NUM_EDIT_EQ_Q: {
      EqBand &e = uiDspTargetInput ? gConfig.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      e.q = value; break;
    }
    case NUM_EDIT_HPF_FREQ:
      if (uiDspTargetInput) in.hpfHz = value; else o.hpfHz = value;
      break;
    case NUM_EDIT_LPF_FREQ:
      if (uiDspTargetInput) in.lpfHz = value; else o.lpfHz = value;
      break;
    case NUM_EDIT_DELAY_MS:
      if (uiDspTargetInput) in.delayMs = value; else o.delayMs = value;
      break;
    case NUM_EDIT_THRESHOLD_DB:
      if (uiDspTargetInput) in.thresholdDb = value; else o.thresholdDb = value;
      break;
    case NUM_EDIT_RATIO:
      if (uiDspTargetInput) in.ratio = value; else o.ratio = value;
      break;
    case NUM_EDIT_ATTACK_MS:
      if (uiDspTargetInput) in.attackMs = value; else o.attackMs = value;
      break;
    case NUM_EDIT_RELEASE_MS:
      if (uiDspTargetInput) in.releaseMs = value; else o.releaseMs = value;
      break;
    default: break;
  }
  ++gConfigRevision;
  portEXIT_CRITICAL(&gConfigMux);
  markConfigChanged();
}

static void beginNumericEdit(NumericEditField field) {
  if (field == NUM_EDIT_NONE) return;
  uint32_t revision = 0;
  const DeviceConfig c = copyConfig(revision);
  numericEditField = field;
  formatNumericEditBuffer(field, readNumericEditValue(field, c));
  numericEditPos = 0;
  while (numericEditBuffer[numericEditPos] && !isNumericEditChar(numericEditBuffer[numericEditPos])) ++numericEditPos;
  if (!numericEditBuffer[numericEditPos]) numericEditPos = 0;
  uiEditing = true;
  requestPageValuePartial(false);
}

static void finishNumericEdit() {
  if (numericEditField == NUM_EDIT_NONE) return;
  float minimum = 0.0f, maximum = 0.0f;
  if (numericEditRange(numericEditField, minimum, maximum)) {
    float finalValue = clampf(parseNumericEditBuffer(), minimum, maximum);
    if (numericEditField == NUM_EDIT_EQ_FREQ || numericEditField == NUM_EDIT_HPF_FREQ || numericEditField == NUM_EDIT_LPF_FREQ)
      finalValue = (float)constrain((int)lroundf(finalValue), 20, 20000);
    else if (numericEditField == NUM_EDIT_RATIO || numericEditField == NUM_EDIT_RELEASE_MS)
      finalValue = (float)lroundf(finalValue);
    else if (numericEditField == NUM_EDIT_EQ_GAIN || numericEditField == NUM_EDIT_THRESHOLD_DB ||
             numericEditField == NUM_EDIT_INPUT_GAIN || numericEditField == NUM_EDIT_OUTPUT_GAIN)
      finalValue = roundf(finalValue * 10.0f) / 10.0f;
    else if (numericEditField == NUM_EDIT_EQ_Q)
      finalValue = roundf(finalValue * 100.0f) / 100.0f;
    else
      finalValue = roundf(finalValue * 10.0f) / 10.0f;
    writeNumericEditValue(numericEditField, finalValue);
  }
  numericEditField = NUM_EDIT_NONE;
  numericEditBuffer[0] = '\0';
  numericEditPos = 0;
  uiEditing = false;
  requestPageValuePartial(false);
  uiPendingGraphRefresh = true;
}

static void advanceNumericEditDigit() {
  if (numericEditField == NUM_EDIT_NONE) return;
  uint8_t next = (uint8_t)(numericEditPos + 1);
  while (numericEditBuffer[next] && !isNumericEditChar(numericEditBuffer[next])) ++next;
  if (!numericEditBuffer[next]) finishNumericEdit();
  else {
    numericEditPos = next;
    requestPageValuePartial(false);
  }
}

static void adjustNumericEditDigit(int direction) {
  if (numericEditField == NUM_EDIT_NONE || direction == 0) return;
  const char original = numericEditBuffer[numericEditPos];
  char candidate[sizeof(numericEditBuffer)];
  snprintf(candidate, sizeof(candidate), "%s", numericEditBuffer);
  if (original == '+' || original == '-') {
    candidate[numericEditPos] = (original == '+') ? '-' : '+';
  } else if (original >= '0' && original <= '9') {
    int digit = original - '0';
    digit = (digit + (direction > 0 ? 1 : 9)) % 10;
    candidate[numericEditPos] = (char)('0' + digit);
  } else {
    return;
  }
  snprintf(numericEditBuffer, sizeof(numericEditBuffer), "%s", candidate);

  float minimum = 0.0f, maximum = 0.0f;
  const float value = parseNumericEditBuffer();
  // Keep the edit buffer free while a user assembles a multi-digit value. Only
  // values inside the DSP range are sent to the audio engine; finish clamps once.
  if (numericEditRange(numericEditField, minimum, maximum) && value >= minimum && value <= maximum) {
    float accepted = value;
    if (numericEditField == NUM_EDIT_EQ_FREQ || numericEditField == NUM_EDIT_HPF_FREQ || numericEditField == NUM_EDIT_LPF_FREQ)
      accepted = (float)lroundf(value);
    else if (numericEditField == NUM_EDIT_RATIO || numericEditField == NUM_EDIT_RELEASE_MS)
      accepted = (float)lroundf(value);
    else if (numericEditField == NUM_EDIT_EQ_Q)
      accepted = roundf(value * 100.0f) / 100.0f;
    else
      accepted = roundf(value * 10.0f) / 10.0f;
    writeNumericEditValue(numericEditField, accepted);
    uiPendingGraphRefresh = true;
  }
  requestPageValuePartial(false);
}

static void uiAdjust(int direction) {
  if (direction == 0) return;
  // Keep a snapshot of the displayed DSP target. A CH change alters every value
  // shown on the page (gain, filters/slopes, EQ, phase, dynamics), not just the
  // CH selector row, so the whole page must be refreshed immediately afterward.
  const uint8_t channelBeforeAdjust = currentDspChannelIndex();
  if (numericEditField != NUM_EDIT_NONE) {
    adjustNumericEditDigit(direction);
    return;
  }
  if (uiPage == UI_PRESET && uiCursor == 2 && uiEditing) {
    adjustPresetNameChar(direction);
    requestPageValuePartial(true);
    return;
  }
  if ((uiPage == UI_INPUT || uiPage == UI_OUTPUT) && uiCursor == 2 && uiEditing) {
    adjustChannelNameChar(direction);
    requestPageValuePartial(false);
    return;
  }
  bool changed = false;
  bool phaseTargetChanged = false;
  const float step = rotaryStepFactor();
  portENTER_CRITICAL(&gConfigMux);
  OutputConfig &o = gConfig.output[uiOutputChannel];
  InputDspConfig &in = gConfig.inputDsp[uiInputChannel];
  switch (uiPage) {
    case UI_LEVEL:
      if (uiCursor == 1) cycleDspChannel(direction);
      else if (uiCursor == 2) {
        if (uiDspTargetInput) gConfig.inputGainDb[uiInputChannel] = clampf(gConfig.inputGainDb[uiInputChannel] + direction * 0.1f * step, -30.0f, 12.0f);
        else o.gainDb = clampf(o.gainDb + direction * 0.1f * step, -60.0f, 12.0f);
        changed = true;
      } else if (uiCursor == 3) {
        if (uiDspTargetInput) gConfig.inputMute[uiInputChannel] = !gConfig.inputMute[uiInputChannel];
        else o.mute = !o.mute;
        changed = true;
      } else if (uiCursor == 4) {
        if (uiDspTargetInput) {
          uiDspTargetInput = false;
          uiOutputChannel = 0;
          phaseTargetChanged = true;
        } else {
          o.polarityInvert = !o.polarityInvert;
          changed = true;
        }
      }
      break;
    case UI_INPUT:
      if (uiCursor == 1) uiInputChannel = (uint8_t)(1U - uiInputChannel);
      else if (uiCursor == 3) { gConfig.inputGainDb[uiInputChannel] = clampf(gConfig.inputGainDb[uiInputChannel] + direction * 0.1f * step, -30.0f, 12.0f); changed = true; }
      else if (uiCursor == 4) { gConfig.inputMute[uiInputChannel] = !gConfig.inputMute[uiInputChannel]; changed = true; }
      else if (uiCursor == 5) { in.delayMs = clampf(in.delayMs + direction * 0.1f * step, 0.0f, 300.0f); changed = true; }
      else if (uiCursor == 6) { in.crossoverBypass = !in.crossoverBypass; changed = true; }
      else if (uiCursor == 7) { in.dynamicsEnabled = !in.dynamicsEnabled; changed = true; }
      else if (uiCursor == 8) { uiDspTargetInput = true; uiPage = UI_EQ; uiCursor = 0; uiEditing = false; uiDirty = true; }
      break;
    case UI_OUTPUT:
      if (uiCursor == 1) uiOutputChannel = (uint8_t)((uiOutputChannel + (direction > 0 ? 1 : 3)) % 4);
      else if (uiCursor == 3) { o.source = (uint8_t)((o.source + (direction > 0 ? 1 : 2)) % 3); changed = true; }
      else if (uiCursor == 4) { o.gainDb = clampf(o.gainDb + direction * 0.1f * step, -60.0f, 12.0f); changed = true; }
      else if (uiCursor == 5) { o.mute = !o.mute; changed = true; }
      else if (uiCursor == 6) { o.polarityInvert = !o.polarityInvert; changed = true; }
      break;
    case UI_EQ: {
      EqBand &e = uiDspTargetInput ? gConfig.inputEq[uiInputChannel][uiEqBand] : o.eq[uiEqBand];
      if (uiCursor == 1) cycleDspChannel(direction);
      else if (uiCursor == 2) uiEqBand = (uint8_t)((uiEqBand + (direction > 0 ? 1 : 8)) % 9);
      else if (uiCursor == 3) { e.enabled = !e.enabled; changed = true; }
      else if (uiCursor == 5) { e.gainDb = clampf(e.gainDb + direction * 0.1f * step, -15.0f, 15.0f); changed = true; }
      else if (uiCursor == 6) { e.q = clampf(e.q + direction * 0.01f * step, 0.4f, 12.0f); changed = true; }
      break;
    }
    case UI_CROSS: {
      if (uiCursor == 1) cycleDspChannel(direction);
      else if (uiCursor == 2) { if (uiDspTargetInput) in.crossoverBypass = !in.crossoverBypass; else o.crossoverBypass = !o.crossoverBypass; changed = true; }
      else if (uiCursor == 4 || uiCursor == 6) {
        const bool hpf = (uiCursor == 4);
        uint8_t &type = (uiDspTargetInput ? (hpf ? in.hpfType : in.lpfType) : (hpf ? o.hpfType : o.lpfType));
        uint8_t &slope = (uiDspTargetInput ? (hpf ? in.hpfSlope : in.lpfSlope) : (hpf ? o.hpfSlope : o.lpfSlope));
        const uint8_t slopeIndex = (slope <= 12) ? 0 : (slope <= 24) ? 1 : (slope <= 36) ? 2 : 3;
        int combinedIndex = (int)type * 4 + slopeIndex;
        combinedIndex = (combinedIndex + (direction > 0 ? 1 : 11)) % 12;
        type = (uint8_t)(combinedIndex / 4);
        static const uint8_t slopes[4] = {12, 24, 36, 48};
        slope = slopes[combinedIndex % 4];
        changed = true;
      }
      break;
    }
    case UI_DELAY:
      if (uiCursor == 1) cycleDspChannel(direction);
      else if (uiCursor == 2) { float &d = uiDspTargetInput ? in.delayMs : o.delayMs; d = clampf(d + direction * 0.1f * step, 0.0f, 300.0f); changed = true; }
      break;
    case UI_DYNAMICS:
      if (uiCursor == 1) cycleDspChannel(direction);
      else if (uiCursor == 2) { if (uiDspTargetInput) in.dynamicsEnabled = !in.dynamicsEnabled; else o.dynamicsEnabled = !o.dynamicsEnabled; changed = true; }
      else if (uiCursor == 3) { float &v = uiDspTargetInput ? in.thresholdDb : o.thresholdDb; v = clampf(v + direction * 0.1f * step, -60.0f, 12.0f); changed = true; }
      else if (uiCursor == 4) { float &v = uiDspTargetInput ? in.ratio : o.ratio; v = clampf(v + direction * 0.1f * step, 1.0f, 20.0f); changed = true; }
      else if (uiCursor == 5) { float &v = uiDspTargetInput ? in.attackMs : o.attackMs; v = clampf(v + direction * 0.1f * step, 0.1f, 100.0f); changed = true; }
      else if (uiCursor == 6) { float &v = uiDspTargetInput ? in.releaseMs : o.releaseMs; v = clampf(v + direction * 1.0f * step, 10.0f, 1000.0f); changed = true; }
      break;
    case UI_POLARITY:
      if (uiCursor == 1) uiOutputChannel = (uint8_t)((uiOutputChannel + (direction > 0 ? 1 : 3)) % 4);
      else if (uiCursor == 2) { o.polarityInvert = !o.polarityInvert; changed = true; }
      break;
    case UI_PRESET:
      if (uiCursor == 1) uiPresetSlot = (uint8_t)constrain((int)uiPresetSlot + direction, 1, 5);
      break;
    default: break;
  }
  if (changed) ++gConfigRevision;
  portEXIT_CRITICAL(&gConfigMux);
  if (changed) markConfigChanged();

  const bool channelTargetChanged = (channelBeforeAdjust != currentDspChannelIndex());
  const bool eqBandChanged = (uiPage == UI_EQ && uiCursor == 2);
  if (channelTargetChanged || eqBandChanged) {
    // The selected channel/band is the data source for several visible rows.
    // A one-row partial update leaves stale values until the encoder reaches
    // those rows. Schedule one coherent page redraw (including its graph).
    uiPendingGraphRefresh = false;
    uiDirty = true;
    clearPartialUiState();
    return;
  }

  const bool selectionChanged = ((uiPage == UI_LEVEL || uiPage == UI_DELAY || uiPage == UI_DYNAMICS || uiPage == UI_POLARITY || uiPage == UI_CROSS || uiPage == UI_EQ) && uiCursor == 1) ||
      (uiPage == UI_PRESET && uiCursor == 1) || phaseTargetChanged;
  if (changed || selectionChanged) {
    requestPageValuePartial(false);
    if (changed || selectionChanged) uiPendingGraphRefresh = true;
  } else {
    requestPagePartial(uiCursor, false);
  }
}

static uint32_t presetChecksum(const String &text) {
  uint32_t hash = 2166136261UL;
  for (size_t i = 0; i < text.length(); ++i) {
    hash ^= (uint8_t)text[i];
    hash *= 16777619UL;
  }
  return hash;
}

static bool readPresetEnvelope(uint8_t slot, JsonDocument &doc, String &stateOut, String &nameOut) {
  if (slot < 1 || slot > 5 || !storageReady) return false;
  const String path = programPath(slot);
  const String payload = storageReadText(path.c_str());
  if (payload.length() == 0 || deserializeJson(doc, payload)) return false;
  const char *magic = doc["magic"] | "";
  const int version = doc["version"] | 0;
  const int storedSlot = doc["slot"] | 0;
  if (strcmp(magic, "LEON_DLMS_PRESET_V9") != 0 || version != 9 || storedSlot != slot) {
    Serial.printf("PRESET ENVELOPE MISMATCH: requested=%u stored=%d version=%d path=%s\n",
                  slot, storedSlot, version, path.c_str());
    return false;
  }
  stateOut = doc["state"] | "";
  if (stateOut.length() == 0) return false;
  const uint32_t expected = doc["checksum"] | 0UL;
  if (expected != presetChecksum(stateOut)) {
    Serial.printf("PRESET CHECKSUM ERROR: slot %u\n", slot);
    return false;
  }
  JsonDocument stateDoc;
  if (deserializeJson(stateDoc, stateOut) || !validateStateDocument(stateDoc)) {
    Serial.printf("PRESET STATE INVALID: slot %u\n", slot);
    return false;
  }
  nameOut = doc["name"] | "STANDARD";
  if (nameOut.length() > 12) nameOut.remove(12);
  if (nameOut.length() == 0) nameOut = "STANDARD";
  return true;
}

static bool presetSlotSaved(uint8_t slot) {
  if (slot < 1 || slot > 5 || !storageReady) return false;
  return gPresetSavedCache[slot - 1];
}

static constexpr const char *LAST_ACTIVE_PRESET_PATH = "/leon_last_active_preset_v086.json";

static bool writeLastActivePreset(uint8_t slot, const String &state, bool activeStateSaved) {
  if (slot < 1 || slot > 5 || state.length() == 0 || !storageReady) return false;
  JsonDocument meta;
  meta["magic"] = "LEON_LAST_ACTIVE_PRESET_V086";
  meta["version"] = 1;
  meta["slot"] = slot;
  meta["checksum"] = presetChecksum(state);
  meta["activeSaved"] = activeStateSaved;
  meta["restore"] = true;
  String payload;
  const size_t n = serializeJson(meta, payload);
  // storageWriteAtomic already reads the committed file back byte-for-byte and
  // validates its JSON; a second open/read/parse here was redundant.
  return n > 0 && payload.length() == n && storageWriteAtomic(LAST_ACTIVE_PRESET_PATH, payload);
}

static bool writeNoAutoRestoreMarker(uint8_t selectedSlot) {
  if (!storageReady) return false;
  if (selectedSlot < 1 || selectedSlot > 5) selectedSlot = 1;
  JsonDocument meta;
  meta["magic"] = "LEON_LAST_ACTIVE_PRESET_V086";
  meta["version"] = 1;
  meta["slot"] = selectedSlot;
  meta["checksum"] = 0UL;
  meta["activeSaved"] = true;
  meta["restore"] = false;
  String payload;
  const size_t n = serializeJson(meta, payload);
  return n > 0 && payload.length() == n && storageWriteAtomic(LAST_ACTIVE_PRESET_PATH, payload);
}

static void clearLastActivePresetPointer() {
  // Keep a tombstone so legacy-P5 fallback does not unexpectedly reactivate a
  // preset after the user deliberately chose STANDARD.
  const bool markerSaved = writeNoAutoRestoreMarker(uiPresetSlot);
  lastPresetPointerClearPending = false;
  activePresetSlot = 0;
  if (!markerSaved) Serial.println("WARNING: no-auto-restore marker could not be saved.");
}

// Restores the last saved/loaded slot on boot. If no v0.8.6 pointer exists,
// a valid legacy P5 is selected once as a compatibility fallback for users
// who reported that P5 appeared to disappear after power cycling.
static bool restoreLastActivePresetAtBoot() {
  if (!storageReady) return false;
  uint8_t slot = 0;
  uint32_t expectedChecksum = 0;
  bool activeStateSaved = false;
  bool havePointer = false;
  bool haveValidMetadata = false;
  bool restoreRequested = true;

  const String metaText = storageReadText(LAST_ACTIVE_PRESET_PATH);
  if (metaText.length() > 0) {
    JsonDocument meta;
    if (!deserializeJson(meta, metaText) &&
        String(meta["magic"] | "") == "LEON_LAST_ACTIVE_PRESET_V086" &&
        (meta["version"] | 0) == 1) {
      const int requestedSlot = meta["slot"] | 0;
      if (requestedSlot >= 1 && requestedSlot <= 5) {
        slot = (uint8_t)requestedSlot;
        expectedChecksum = meta["checksum"] | 0UL;
        activeStateSaved = meta["activeSaved"] | false;
        restoreRequested = meta["restore"].is<bool>() ? meta["restore"].as<bool>() : true;
        havePointer = restoreRequested;
        haveValidMetadata = true;
      }
    }
  }

  if (haveValidMetadata && !restoreRequested) {
    uiPresetSlot = slot;
    activePresetSlot = 0;
    lastPresetPointerClearPending = false;
    Serial.printf("PRESET RESTORE: auto-load disabled; P%u remains saved and selected.\n", slot);
    return false;
  }

  // Compatibility path for a P5 saved by v0.8.5, which did not persist the
  // last selected slot. Do not guess among several old slots: prefer P5 only.
  if (!haveValidMetadata && presetSlotSaved(5)) {
    slot = 5;
    Serial.println("PRESET RESTORE: no v0.8.6 pointer; using valid legacy P5 once.");
  }
  if (slot < 1 || slot > 5) return false;

  JsonDocument envelope;
  String state, name;
  if (!readPresetEnvelope(slot, envelope, state, name)) {
    Serial.printf("PRESET RESTORE: slot %u is missing or invalid; leaving active config unchanged.\n", slot);
    return false;
  }
  if (havePointer && expectedChecksum != presetChecksum(state)) {
    Serial.printf("PRESET RESTORE: pointer checksum mismatch for P%u; leaving active config unchanged.\n", slot);
    return false;
  }

  // If a previous manual edit was already saved after this preset, its active
  // state is newer. Keep that newer active state instead of overwriting it.
  const String activeText = storageReadText("/active_tft_v059.json");
  if (havePointer && activeStateSaved && activeText.length() > 0 && activeText != state) {
    uiPresetSlot = slot; // still show the saved slot as selected in the UI
    activePresetSlot = 0;
    writeNoAutoRestoreMarker(slot);
    Serial.printf("PRESET RESTORE: P%u remains saved; newer active edits kept.\n", slot);
    return false;
  }

  if (!applyJsonState(state) || !activeConfigMatchesJson(state)) {
    Serial.printf("PRESET RESTORE: applying P%u failed; leaving safe active state.\n", slot);
    return false;
  }
  snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "%s", name.c_str());
  trimPresetName(slot);
  uiPresetSlot = slot;
  activePresetSlot = slot;
  lastPresetPointerClearPending = false;
  const bool activeSaved = storageWriteAtomic("/active_tft_v059.json", state);
  configDirty = !activeSaved;
  lastConfigChange = millis();
  const bool pointerSaved = writeLastActivePreset(slot, state, activeSaved);
  Serial.printf("PRESET RESTORE: P%u %s; active-file=%s pointer=%s\n",
                slot, name.c_str(), activeSaved ? "VERIFIED" : "RETRY", pointerSaved ? "VERIFIED" : "RETRY");
  return true;
}


// Mute the audio before FFat operations. This avoids flash/cache activity while
// audible program material is passing through the DSP. The audio task ramps each
// output mute over about 10 ms; allow it to finish before reading/writing flash.
static void engageMasterMuteForStorage() {
  if (!gMasterMute) {
    gMasterMute = true;
    delay(20);
  }
}

static void savePreset(uint8_t slot) {
  if (slot < 1 || slot > 5) return;
  engageMasterMuteForStorage();
  if (!storageReady || !FFat.exists(PRESET_DIRECTORY)) {
    snprintf(uiNotice, sizeof(uiNotice), "STORAGE NOT READY");
    Serial.println("PRESET SAVE FAILED: preset directory unavailable.");
    uiDirty = true;
    return;
  }

  const uint8_t targetSlot = slot;
  const String state = serializeState();
  JsonDocument stateCheck;
  if (deserializeJson(stateCheck, state) || !validateStateDocument(stateCheck)) {
    snprintf(uiNotice, sizeof(uiNotice), "STATE INVALID");
    Serial.printf("PRESET SAVE REJECTED: slot %u, active state incomplete.\n", targetSlot);
    uiDirty = true;
    return;
  }

  JsonDocument stored;
  stored["magic"] = "LEON_DLMS_PRESET_V9";
  stored["version"] = 9;
  stored["slot"] = targetSlot;
  stored["name"] = String(gPresetNames[targetSlot - 1]);
  stored["state"] = state;
  stored["checksum"] = presetChecksum(state);
  String payload;
  const size_t jsonBytes = serializeJson(stored, payload);
  const String path = programPath(targetSlot);
  const bool writeOk = jsonBytes > 0 && payload.length() == jsonBytes && storageWriteAtomic(path.c_str(), payload);

  bool readBackOk = false;
  if (writeOk) {
    JsonDocument verifyDoc;
    String verifyState, verifyName;
    readBackOk = readPresetEnvelope(targetSlot, verifyDoc, verifyState, verifyName) &&
                 verifyState == state && verifyName == String(gPresetNames[targetSlot - 1]);
  }
  if (writeOk) gPresetSavedCache[targetSlot - 1] = readBackOk;

  bool pointerSaved = false;
  bool fallbackActiveSaved = false;
  if (readBackOk) {
    uiPresetSlot = targetSlot;
    activePresetSlot = targetSlot;
    lastPresetPointerClearPending = false;
    // The saved slot itself is the durable copy. Tell boot to restore from that
    // verified slot instead of redundantly writing the same large JSON to active_tft.
    configDirty = false;
    pointerSaved = writeLastActivePreset(targetSlot, state, false);
    // Rare recovery path: if the small pointer cannot be committed, also save the
    // active snapshot so the current configuration is not lost at next power-up.
    if (!pointerSaved) {
      fallbackActiveSaved = storageWriteAtomic("/active_tft_v059.json", state);
      if (fallbackActiveSaved) pointerSaved = writeLastActivePreset(targetSlot, state, true);
      configDirty = !pointerSaved;
      if (configDirty) lastConfigChange = millis();
    }
  }
  Serial.printf("PRESET SAVE: slot=%u file=%s result=%s bytes=%u crc=%08lX pointer=%s fallback=%s\n",
                targetSlot, path.c_str(), readBackOk ? "VERIFIED" : "FAILED",
                (unsigned)payload.length(), (unsigned long)presetChecksum(state),
                pointerSaved ? "SAVED" : "FAILED", fallbackActiveSaved ? "SAVED" : "NOT_NEEDED");
  if (!readBackOk) snprintf(uiNotice, sizeof(uiNotice), "SAVE FAILED");
  else if (pointerSaved) snprintf(uiNotice, sizeof(uiNotice), "P%u SAVED OK", targetSlot);
  else snprintf(uiNotice, sizeof(uiNotice), "P%u SAVED CHECK", targetSlot);
  uiDirty = true;
}

static void returnToLastConfigPage() {
  if (uiLastConfigPage == UI_HOME || uiLastConfigPage == UI_MENU_PAGE ||
      uiLastConfigPage == UI_MATRIX || uiLastConfigPage == UI_PRESET || uiLastConfigPage == UI_RTA ||
      uiLastConfigPage == UI_SYSTEM || uiLastConfigPage == UI_LEVEL) uiLastConfigPage = UI_EQ;
  gRtaCaptureEnabled = false;
  uiPage = uiLastConfigPage;
  uiCursor = 1; // show current channel/section selector and freshly loaded values
  uiEditing = false;
  uiPendingGraphRefresh = false;
  uiDirty = true;
}

static void resetActiveToStandard() {
  engageMasterMuteForStorage();
  setDefaults();
  const String standardState = serializeState();
  const bool standardSaved = storageReady && storageWriteAtomic("/active_tft_v059.json", standardState);
  if (standardSaved) {
    configDirty = false;
    clearLastActivePresetPointer();
  } else {
    configDirty = true;
    lastConfigChange = millis();
    lastPresetPointerClearPending = true;
    activePresetSlot = 0;
    Serial.println("STANDARD state save pending; auto-restore will be disabled after active state is committed.");
  }
  snprintf(uiNotice, sizeof(uiNotice), "STANDARD SETTINGS");
  Serial.println("Active DSP configuration restored to factory STANDARD defaults. Stored preset slots are preserved.");
  returnToLastConfigPage();
}

static void loadPreset(uint8_t slot) {
  if (slot < 1 || slot > 5) return;
  engageMasterMuteForStorage();
  if (!storageReady) {
    snprintf(uiNotice, sizeof(uiNotice), "STORAGE NOT READY");
    uiDirty = true;
    return;
  }

  JsonDocument stored;
  String state, name;
  if (!readPresetEnvelope(slot, stored, state, name)) {
    gPresetSavedCache[slot - 1] = false;
    const String path = programPath(slot);
    const bool exists = FFat.exists(path.c_str());
    // A missing OR corrupt slot must never keep the previously active slot's
    // values. Load the complete neutral standard state instead.
    if (exists) {
      snprintf(uiNotice, sizeof(uiNotice), "INVALID: STANDARD");
      Serial.printf("Preset %u invalid; active config reset to factory STANDARD.\n", slot);
    } else {
      snprintf(uiNotice, sizeof(uiNotice), "EMPTY: STANDARD");
      Serial.printf("Preset %u empty; loading factory STANDARD.\n", slot);
    }
    snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "STANDARD");
    activePresetSlot = 0;
    resetActiveToStandard();
    return;
  }

  if (!applyJsonState(state)) {
    // Never leave the previously active program in place when a selected slot
    // has a valid envelope but an invalid/incomplete DSP payload.
    Serial.printf("Preset %u rejected: incomplete or invalid state; loading STANDARD.\n", slot);
    resetActiveToStandard();
    snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "STANDARD");
    snprintf(uiNotice, sizeof(uiNotice), "INVALID: STANDARD");
    return;
  }
  if (!activeConfigMatchesJson(state)) {
    Serial.printf("PRESET APPLY VERIFY FAILED: slot=%u; reverting to STANDARD.\n", slot);
    resetActiveToStandard();
    snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "STANDARD");
    snprintf(uiNotice, sizeof(uiNotice), "PRESET VERIFY FAIL");
    return;
  }

  snprintf(gPresetNames[slot - 1], sizeof(gPresetNames[slot - 1]), "%s", name.c_str());
  trimPresetName(slot);
  gPresetSavedCache[slot - 1] = true;
  activePresetSlot = slot;
  markConfigChanged(true);
  lastPresetPointerClearPending = false;
  // Normal LOAD needs only the small slot pointer: boot restores the same verified
  // preset envelope. Avoid rewriting the full active JSON on every preset load.
  bool pointerSaved = writeLastActivePreset(slot, state, false);
  bool activeStateSaved = false;
  if (pointerSaved) {
    configDirty = false;
  } else {
    // Recovery path if metadata storage fails: preserve the loaded DSP state in
    // the active snapshot so a power cycle still has a durable configuration.
    activeStateSaved = storageWriteAtomic("/active_tft_v059.json", state);
    if (activeStateSaved) pointerSaved = writeLastActivePreset(slot, state, true);
    configDirty = !pointerSaved;
    if (configDirty) lastConfigChange = millis();
  }
  Serial.printf("PRESET LOAD PERSIST: slot=%u active=%s pointer=%s\n", slot,
                activeStateSaved ? "SAVED" : "SLOT RESTORE", pointerSaved ? "SAVED" : "RETRY");
  uint32_t loadedRevision = 0;
  const DeviceConfig loaded = copyConfig(loadedRevision);
  // Audio applies the new revision on its next processing block. Never stall the
  // rotary/UI thread waiting for that acknowledgement.
  const bool dspAlreadyApplied = !audioReady || (gDspAppliedRevision == loadedRevision);
  snprintf(uiNotice, sizeof(uiNotice), "P%u LOAD OK", slot);
  Serial.printf("PRESET LOAD QUEUED: slot=%u name=%s rev=%lu DSPrev=%lu immediate=%s INL=%+.1fdB INR=%+.1fdB OUT1=%+.1fdB HPF1=%s%.0fHz LPF1=%s%.0fHz EQ1B1=%s%.1fdB DELAY1=%.2fms DYN1=%s\n",
    slot, gPresetNames[slot - 1],
    (unsigned long)loadedRevision, (unsigned long)gDspAppliedRevision,
    dspAlreadyApplied ? "YES" : "NEXT_BLOCK",
    loaded.inputGainDb[0], loaded.inputGainDb[1], loaded.output[0].gainDb,
    loaded.output[0].crossoverBypass ? "BYP:" : "ON:", loaded.output[0].hpfHz,
    loaded.output[0].crossoverBypass ? "BYP:" : "ON:", loaded.output[0].lpfHz,
    loaded.output[0].eq[0].enabled ? "ON:" : "OFF:", loaded.output[0].eq[0].gainDb,
    loaded.output[0].delayMs, loaded.output[0].dynamicsEnabled ? "ON" : "OFF");
  returnToLastConfigPage();
}


static void beginPresetConfirmation(PresetConfirmAction action) {
  if (uiPage != UI_PRESET || action == PRESET_CONFIRM_NONE) return;
  presetConfirmAction = action;
  presetConfirmYesSelected = false; // BATAL highlighted by default to prevent accidental changes.
  uiEditing = false;
  uiPendingGraphRefresh = false;
  uiPartialMode = UI_PARTIAL_NONE;
  uiPartialGraphDirty = false;
  snprintf(uiNotice, sizeof(uiNotice), "CONFIRM ACTION");
  uiDirty = true;
}

static void cancelPresetConfirmation() {
  if (presetConfirmAction == PRESET_CONFIRM_NONE) return;
  presetConfirmAction = PRESET_CONFIRM_NONE;
  presetConfirmYesSelected = false;
  snprintf(uiNotice, sizeof(uiNotice), "CANCELLED");
  uiDirty = true;
}

static void executePresetConfirmation() {
  const PresetConfirmAction action = presetConfirmAction;
  const bool accepted = presetConfirmYesSelected;
  const uint8_t slot = uiPresetSlot;
  presetConfirmAction = PRESET_CONFIRM_NONE;
  presetConfirmYesSelected = false;

  if (!accepted) {
    snprintf(uiNotice, sizeof(uiNotice), "CANCELLED");
    uiDirty = true;
    return;
  }

  // The destructive/overwriting operation is invoked only after explicit YA selection + press.
  switch (action) {
    case PRESET_CONFIRM_SAVE:  savePreset(slot); break;
    case PRESET_CONFIRM_LOAD:  loadPreset(slot); break;
    case PRESET_CONFIRM_RESET: resetActiveToStandard(); break;
    default:
      snprintf(uiNotice, sizeof(uiNotice), "CANCELLED");
      uiDirty = true;
      break;
  }
}

static void uiEnterPage(int index) {
  gRtaCaptureEnabled = false;
  switch (index) {
    case 0: uiPage = UI_MATRIX; break;
    case 1: uiPage = UI_EQ; uiDspTargetInput = true; uiInputChannel = 0; uiLastConfigPage = UI_EQ; break;
    case 2: uiPage = UI_CROSS; uiDspTargetInput = true; uiInputChannel = 0; uiLastConfigPage = UI_CROSS; break;
    case 3: uiPage = UI_DELAY; uiDspTargetInput = true; uiInputChannel = 0; uiLastConfigPage = UI_DELAY; break;
    case 4: uiPage = UI_DYNAMICS; uiDspTargetInput = true; uiInputChannel = 0; uiLastConfigPage = UI_DYNAMICS; break;
    case 5: uiPage = UI_LEVEL; uiDspTargetInput = true; uiInputChannel = 0; uiOutputChannel = 0; break;
    case 6: uiPage = UI_PRESET; break;
    case 7: uiPage = UI_SYSTEM; break;
    case 8:
      uiPage = UI_RTA;
      rtaHold = false;
      // Ignore an old frame from the previous visit; wait for a fresh 4096-sample block.
      gRtaDrawnSequence = gRtaSequence;
      gRtaCaptureEnabled = gRtaMemoryReady && audioReady;
      lastRtaCompute = 0;
      for (int ch = 0; ch < 2; ++ch) {
        for (int i = 0; i < (int)RTA_BANDS; ++i) gRtaLevels[ch][i] = -90.0f;
        gRtaPeakDb[ch] = -90.0f;
      }
      break;
    default: uiPage = UI_MATRIX; break;
  }
  uiCursor = 0;
  uiEditing = false;
  numericEditField = NUM_EDIT_NONE;
  numericEditBuffer[0] = '\0';
  uiDirty = true;
}
static void uiGoHome() {
  presetConfirmAction = PRESET_CONFIRM_NONE;
  presetConfirmYesSelected = false;
  gRtaCaptureEnabled = false;
  uiPage = UI_HOME;
  uiHomeIndex = 0;
  uiCursor = 0;
  uiEditing = false;
  numericEditField = NUM_EDIT_NONE;
  numericEditBuffer[0] = '\0';
  uiDirty = true;
}
static void uiBackToMenu() {
  presetConfirmAction = PRESET_CONFIRM_NONE;
  presetConfirmYesSelected = false;
  // BACK leaves the current page for the 3x3 application menu.
  // The live LEVEL MONITOR remains a separate HOME/dashboard screen.
  gRtaCaptureEnabled = false;
  uiPage = UI_MENU_PAGE;
  uiCursor = 0;
  uiEditing = false;
  numericEditField = NUM_EDIT_NONE;
  numericEditBuffer[0] = '\0';
  numericEditPos = 0;
  uiPartialMode = UI_PARTIAL_NONE;
  uiPartialGraphDirty = false;
  uiDirty = true;
}

static void toggleHomeChannelMute(int focusIndex) {
  portENTER_CRITICAL(&gConfigMux);
  if (focusIndex == 0 || focusIndex == 1) {
    const uint8_t ch = (uint8_t)focusIndex;
    gConfig.inputMute[ch] = !gConfig.inputMute[ch];
  } else if (focusIndex >= 2 && focusIndex <= 5) {
    const uint8_t ch = (uint8_t)(focusIndex - 2);
    gConfig.output[ch].mute = !gConfig.output[ch].mute;
  }
  ++gConfigRevision;
  portEXIT_CRITICAL(&gConfigMux);
  markConfigChanged();
}

static void uiShortPress() {
  if (presetConfirmAction != PRESET_CONFIRM_NONE) {
    executePresetConfirmation();
    return;
  }
  // The HOME page is a live 2-IN / 4-OUT level dashboard.
  // Each channel tile toggles its own mute; the separate bottom tile controls MASTER MUTE.
  if (uiPage == UI_HOME) {
    if (uiHomeIndex >= 0 && uiHomeIndex <= 5) {
      toggleHomeChannelMute(uiHomeIndex);
      uiDirty = true;
    } else if (uiHomeIndex == 6) {
      gMasterMute = !gMasterMute;
      snprintf(uiNotice, sizeof(uiNotice), gMasterMute ? "MASTER MUTED" : "MASTER ACTIVE");
      uiDirty = true;
    }
    return;
  }
  if (uiPage == UI_MENU_PAGE) { uiEnterPage(uiMenuIndex); return; }

  // PHASE is a direct two-state action: a short press immediately toggles
  // polarity for the selected output. It must not enter the generic edit mode.
  if ((uiPage == UI_LEVEL && uiCursor == 4) || (uiPage == UI_POLARITY && uiCursor == 2)) {
    if (uiDspTargetInput) {
      // The GAIN page opens on IN1. PHASE belongs to outputs, so make the first
      // press select OUT1 rather than appearing to ignore the user's action.
      uiDspTargetInput = false;
      uiOutputChannel = 0;
      snprintf(uiNotice, sizeof(uiNotice), "SELECT OUT1 - PRESS PHASE");
      uiEditing = false;
      uiDirty = true;
      requestPageValuePartial(false);
      return;
    }
    bool phaseNowInverted = false;
    portENTER_CRITICAL(&gConfigMux);
    gConfig.output[uiOutputChannel].polarityInvert = !gConfig.output[uiOutputChannel].polarityInvert;
    phaseNowInverted = gConfig.output[uiOutputChannel].polarityInvert;
    ++gConfigRevision;
    portEXIT_CRITICAL(&gConfigMux);
    markConfigChanged();
    snprintf(uiNotice, sizeof(uiNotice), "OUT%u PHASE %s", uiOutputChannel + 1,
             phaseNowInverted ? "INV" : "NORM");
    uiPendingGraphRefresh = true;
    uiEditing = false;
    uiDirty = true;
    requestPageValuePartial(false);
    return;
  }

  // Every continuous numeric parameter uses the same per-character workflow.
  // Press starts editing; each following press advances to the next digit/sign.
  const NumericEditField numericField = currentNumericEditField();
  if (numericField != NUM_EDIT_NONE) {
    if (numericEditField == NUM_EDIT_NONE) beginNumericEdit(numericField);
    else advanceNumericEditDigit();
    return;
  }
  if (uiPage == UI_MATRIX) {
    const uint8_t inCh = (uint8_t)(uiCursor / 4);
    const uint8_t outCh = (uint8_t)(uiCursor % 4);
    portENTER_CRITICAL(&gConfigMux);
    gConfig.inputRoute[inCh][outCh] = !gConfig.inputRoute[inCh][outCh];
    ++gConfigRevision;
    portEXIT_CRITICAL(&gConfigMux);
    markConfigChanged();
    uiDirty = true;
    return;
  }
  if ((uiPage == UI_INPUT || uiPage == UI_OUTPUT) && !uiEditing && uiCursor == 2) {
    beginChannelNameEdit();
    requestPageValuePartial(false);
    return;
  }
  if (uiPage == UI_INPUT && !uiEditing && uiCursor >= 5 && uiCursor <= 8) {
    uiDspTargetInput = true;
    if (uiCursor == 5) uiPage = UI_DELAY;
    else if (uiCursor == 6) uiPage = UI_CROSS;
    else if (uiCursor == 7) uiPage = UI_DYNAMICS;
    else uiPage = UI_EQ;
    uiCursor = 0; uiEditing = false; uiDirty = true;
    return;
  }
  if ((uiPage == UI_INPUT || uiPage == UI_OUTPUT) && uiEditing && uiCursor == 2) {
    ++channelNamePos;
    if (channelNamePos >= 10) finishChannelNameEdit();
    else requestPageValuePartial(false);
    return;
  }
  if (uiPage == UI_RTA) {
    if (gRtaMemoryReady && audioReady) {
      rtaHold = !rtaHold;
      if (!rtaHold) {
        // Restart capture cleanly and do not immediately redraw the previous held frame.
        gRtaDrawnSequence = gRtaSequence;
        gRtaCaptureEnabled = true;
      } else {
        gRtaCaptureEnabled = false;
      }
    } else {
      snprintf(uiNotice, sizeof(uiNotice), !audioReady ? "RTA AUDIO NOT READY" : "RTA PSRAM ERROR");
    }
    uiDirty = true;
    return;
  }
  if (uiCursor == 0 && !uiEditing) {
    uiBackToMenu();
    return;
  }
  if (uiPage == UI_PRESET) {
    if (uiEditing && uiCursor == 1) {
      uiEditing = false;
      snprintf(uiNotice, sizeof(uiNotice), "SELECTED P%u - USE LOAD", uiPresetSlot);
      requestPageValuePartial(false);
      return;
    }
    if (uiEditing && uiCursor == 2) {
      ++presetNamePos;
      if (presetNamePos >= 10) finishPresetNameEdit();
      else requestPageValuePartial(true);
      return;
    }
    if (!uiEditing) {
      if (uiCursor == 2) { beginPresetNameEdit(); requestPageValuePartial(true); return; }
      if (uiCursor == 3) { beginPresetConfirmation(PRESET_CONFIRM_SAVE); return; }
      if (uiCursor == 4) { beginPresetConfirmation(PRESET_CONFIRM_LOAD); return; }
      if (uiCursor == 5) { beginPresetConfirmation(PRESET_CONFIRM_RESET); return; }
    }
  }
  if (uiPage == UI_SYSTEM) return;
  if (uiPage == UI_LEVEL && uiCursor == 4 && uiDspTargetInput) return; // Input channels have no polarity control.
  const bool wasEditing = uiEditing;
  uiEditing = !uiEditing;
  requestPagePartial(uiCursor, false);
  if (wasEditing && uiPage != UI_PRESET) uiPendingGraphRefresh = true;
}

static void uiLongPress() {
  if (presetConfirmAction != PRESET_CONFIRM_NONE) {
    cancelPresetConfirmation();
    return;
  }
  if (numericEditField != NUM_EDIT_NONE) {
    finishNumericEdit();
    return;
  }
  if (uiPage == UI_HOME) {
    uiPage = UI_MENU_PAGE;
    uiMenuIndex = 0;
    uiDirty = true;
    return;
  }
  if (uiPage == UI_MENU_PAGE) {
    uiGoHome();
    return;
  }
  if ((uiPage == UI_INPUT || uiPage == UI_OUTPUT) && uiEditing && uiCursor == 2) {
    finishChannelNameEdit();
    return;
  }
  if (uiPage == UI_PRESET && uiEditing && uiCursor == 2) {
    finishPresetNameEdit();
    return;
  }
  uiBackToMenu();
}
static int menuFirstVisibleIndex(int selected) {
  (void)selected;
  return 0;
}
static void uiRotate(int direction, uint8_t repeat = 1) {
  if (repeat < 1) repeat = 1;
  if (presetConfirmAction != PRESET_CONFIRM_NONE) {
    if (direction != 0) {
      const bool chooseYes = direction > 0;
      if (presetConfirmYesSelected != chooseYes) {
        presetConfirmYesSelected = chooseYes;
        uiDirty = true;
      }
    }
    return;
  }
  if (uiPage == UI_HOME) {
    const int oldIndex = uiHomeIndex;
    uiHomeIndex = (uiHomeIndex + direction * (int)repeat + 7 * 4) % 7;
    requestMenuPartial(oldIndex, 0);
    return;
  }
  if (uiPage == UI_MENU_PAGE) {
    const int oldIndex = uiMenuIndex;
    const int menuCount = (int)(sizeof(UI_MENU) / sizeof(UI_MENU[0]));
    uiMenuIndex = (uiMenuIndex + direction * (int)repeat + menuCount * 4) % menuCount;
    requestMenuPartial(oldIndex, 0);
    return;
  }
  if (uiPage == UI_RTA) {
    // RTA is always the stereo input L/R pair. Rotary has no output-channel selector here.
    return;
  }
  if (uiEditing) { uiAdjust(direction); return; }
  const int oldCursor = uiCursor;
  const int oldWindow = pageFirstVisibleRow(oldCursor);
  const int count = uiItemCount();
  uiCursor = (uiCursor + direction * (int)repeat + count * 4) % count;
  requestPagePartial(oldCursor, false);
  uiPartialOldWindow = oldWindow;
}

static void pollRotary() {
  const uint8_t state = (digitalRead(PIN_ROTARY_A) ? 2 : 0) | (digitalRead(PIN_ROTARY_B) ? 1 : 0);
  static const int8_t transition[16] = {0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0};
  rotaryQuarterSteps += transition[(rotaryPrevState << 2) | state];
  rotaryPrevState = state;
  int detentDirection = 0;
  if (rotaryQuarterSteps >= 4) { rotaryQuarterSteps = 0; detentDirection = 1; }
  else if (rotaryQuarterSteps <= -4) { rotaryQuarterSteps = 0; detentDirection = -1; }
  if (detentDirection != 0) {
    rotaryLastDetentUs = micros();
    // One encoder detent always equals one fixed parameter step.
    uiRotate(detentDirection, 1);
  }

  const bool rawPressed = digitalRead(PIN_ROTARY_SW) == LOW;
  if (rawPressed != rotaryRawLast) { rotaryRawLast = rawPressed; rotaryRawChangedAt = millis(); }
  if ((uint32_t)(millis() - rotaryRawChangedAt) >= 25 && rawPressed != rotaryButtonDown) {
    rotaryButtonDown = rawPressed;
    if (rotaryButtonDown) {
      rotaryLongHandled = false;
      rotaryDownAt = millis();
    } else if (!rotaryLongHandled) {
      uiShortPress();
    }
  }
  if (rotaryButtonDown && !rotaryLongHandled && (uint32_t)(millis() - rotaryDownAt) >= 700) {
    rotaryLongHandled = true;
    uiLongPress();
  }
}

static void drawHeader(const char *title) {
  // Shared header geometry: all page titles stop before the audio-status badge.
  tft.fillRect(0, 0, 160, 20, UI_PANEL);
  tft.fillRoundRect(6, 5, 12, 12, 4, UI_BLUE);
  tft.setTextSize(1);
  tft.setTextColor(UI_WHITE, UI_BLUE);
  tft.setCursor(9, 8); tft.print("L");

  char safeTitle[17];
  size_t n = title ? strlen(title) : 0;
  if (n > 16) n = 16; // 16 x 6px = 96px; x=23..119, before badge at x=127.
  if (n) memcpy(safeTitle, title, n);
  safeTitle[n] = '\0';
  tft.fillRect(22, 4, 101, 14, UI_PANEL);
  tft.setTextColor(UI_WHITE, UI_PANEL);
  tft.setCursor(23, 8); tft.print(safeTitle);

  tft.fillRoundRect(127, 4, 28, 12, 5, UI_PANEL2);
  tft.fillCircle(132, 10, 2, audioReady ? UI_GREEN : UI_YELLOW);
  tft.setTextColor(audioReady ? UI_GREEN : UI_YELLOW, UI_PANEL2);
  tft.setCursor(137, 6); tft.print(audioReady ? "OK" : "--");
  tft.drawFastHLine(5, 19, 150, UI_EDGE);
}

// ST7735S 1.8in, 160x128 active matrix: 2 pixels are approximately
// 0.4-0.45 mm (actual width depends on the panel active-area dimensions).
// Two adjacent rounded contours create a clean, ~0.4 mm neon-green frame.
// Keep this as the final paint operation after every full or partial redraw.
static void drawNeonDisplayFrame() {
  // Outer and inner contours are adjacent: 2 px total, with a subtle 4 px corner radius.
  // The 1 px inset preserves the rounded silhouette without filling the corners.
  tft.drawRoundRect(0, 0, 160, 128, 4, UI_NEON_GREEN);
  tft.drawRoundRect(1, 1, 158, 126, 3, UI_NEON_GREEN);
}
// Android-style 3x3 launcher grid with custom vector audio icons.
// Icons are drawn from TFT primitives: no emoji/font assets and low RAM use.
static void drawMenuIcon(uint8_t index, int x, int y, uint16_t color) {
  switch (index) {
    case 0: // matrix
      tft.drawRect(x + 1, y + 1, 13, 12, color);
      tft.drawFastVLine(x + 5, y + 1, 12, color); tft.drawFastVLine(x + 9, y + 1, 12, color);
      tft.drawFastHLine(x + 1, y + 5, 13, color); tft.drawFastHLine(x + 1, y + 9, 13, color);
      tft.fillRect(x + 2, y + 2, 2, 2, color); tft.fillRect(x + 10, y + 6, 3, 2, color);
      break;
    case 1: // EQ
      tft.drawFastVLine(x + 2, y + 1, 12, color); tft.drawFastVLine(x + 7, y + 1, 12, color); tft.drawFastVLine(x + 12, y + 1, 12, color);
      tft.fillRoundRect(x, y + 3, 5, 3, 1, color); tft.fillRoundRect(x + 5, y + 8, 5, 3, 1, color); tft.fillRoundRect(x + 10, y + 5, 5, 3, 1, color);
      break;
    case 2: // crossover
      tft.drawFastVLine(x + 1, y + 1, 12, color); tft.drawFastHLine(x + 1, y + 12, 13, color);
      tft.drawLine(x + 2, y + 2, x + 4, y + 3, color); tft.drawLine(x + 4, y + 3, x + 6, y + 6, color); tft.drawLine(x + 6, y + 6, x + 8, y + 10, color); tft.drawLine(x + 8, y + 10, x + 12, y + 11, color);
      tft.drawLine(x + 2, y + 11, x + 5, y + 10, color); tft.drawLine(x + 5, y + 10, x + 7, y + 6, color); tft.drawLine(x + 7, y + 6, x + 9, y + 3, color); tft.drawLine(x + 9, y + 3, x + 12, y + 2, color);
      break;
    case 3: // delay
      tft.drawCircle(x + 7, y + 7, 5, color); tft.drawFastVLine(x + 7, y + 3, 4, color); tft.drawLine(x + 7, y + 7, x + 10, y + 9, color); tft.drawPixel(x + 7, y + 7, color);
      break;
    case 4: // dynamics
      tft.drawFastVLine(x + 1, y + 1, 12, color); tft.drawFastHLine(x + 1, y + 12, 13, color); tft.drawLine(x + 2, y + 11, x + 5, y + 8, color); tft.drawLine(x + 5, y + 8, x + 8, y + 5, color); tft.drawLine(x + 8, y + 5, x + 12, y + 4, color);
      break;
    case 5: // gain meter
      tft.drawRect(x + 1, y + 2, 13, 11, color);
      tft.fillRect(x + 3, y + 8, 2, 3, color);
      tft.fillRect(x + 6, y + 5, 2, 6, color);
      tft.fillRect(x + 9, y + 3, 2, 8, color);
      tft.drawFastHLine(x + 1, y + 13, 13, color);
      break;
    case 6: // presets
      tft.drawRoundRect(x + 3, y + 1, 10, 12, 2, color); tft.drawFastHLine(x + 5, y + 4, 6, color); tft.drawFastHLine(x + 5, y + 7, 6, color); tft.drawFastHLine(x + 5, y + 10, 4, color); tft.drawLine(x, y + 4, x + 2, y + 6, color);
      break;
    case 7: // setup
      tft.drawCircle(x + 7, y + 7, 4, color); tft.drawCircle(x + 7, y + 7, 2, color); tft.drawFastVLine(x + 7, y, 3, color); tft.drawFastVLine(x + 7, y + 11, 3, color); tft.drawFastHLine(x, y + 7, 3, color); tft.drawFastHLine(x + 11, y + 7, 3, color);
      break;
    case 8: // RTA spectrum bars
      tft.drawFastHLine(x, y + 13, 15, color);
      tft.fillRect(x + 1, y + 8, 2, 5, color); tft.fillRect(x + 4, y + 4, 2, 9, color);
      tft.fillRect(x + 7, y + 1, 2, 12, color); tft.fillRect(x + 10, y + 6, 2, 7, color); tft.fillRect(x + 13, y + 9, 2, 4, color);
      break;
    default: break;
  }
}

static int menuFirstDisplayed() { return 0; }
static void drawMenuItemRow(int idx, int first) {
  (void)first;
  const int count = (int)(sizeof(UI_MENU) / sizeof(UI_MENU[0]));
  if (idx < 0 || idx >= count) return;

  const int col = idx % 3;
  const int row = idx / 3;
  const int x = 4 + col * 52;
  const int y = 23 + row * 30;
  const int w = 48;
  const int h = 27;
  const bool selected = (idx == uiMenuIndex);
  const uint16_t cardBg = selected ? UI_PANEL2 : UI_PANEL;
  const uint16_t edge = selected ? UI_NEON_GREEN : UI_EDGE;
  const uint16_t iconColor = selected ? UI_YELLOW : UI_CYAN;
  tft.fillRoundRect(x, y, w, h, 5, cardBg);
  tft.drawRoundRect(x, y, w, h, 5, edge);
  if (selected) tft.fillRoundRect(x + 17, y + 1, 14, 2, 1, UI_NEON_GREEN);
  tft.fillRoundRect(x + 14, y + 2, 20, 15, 4, selected ? UI_BG : UI_PANEL2);
  drawMenuIcon((uint8_t)idx, x + 17, y + 2, iconColor);
  static const char *const compactLabels[9] = {
    "MATRIX", "EQ", "X-OVER", "DELAY", "DYN", "GAIN", "PRESET", "SETUP", "RTA"
  };
  const int labelLen = (int)strlen(compactLabels[idx]);
  const int textX = x + (w - labelLen * 6) / 2;
  tft.setTextSize(1);
  tft.setTextColor(selected ? UI_YELLOW : UI_WHITE, cardBg);
  tft.setCursor(textX, y + 19);
  tft.print(compactLabels[idx]);
}
static void drawMenuBody(bool clearBody) {
  if (clearBody) tft.fillRect(0, 20, 160, 108, UI_BG);
  for (int idx = 0; idx < 9; ++idx) drawMenuItemRow(idx, 0);
  tft.fillRoundRect(4, 112, 152, 10, 5, UI_PANEL);
  tft.setTextColor(UI_EDGE, UI_PANEL);
  tft.setCursor(8, 113); tft.print("PUSH OPEN   HOLD HOME");
}
static void drawMainMenu() {
  tft.fillScreen(UI_BG);
  drawHeader("DSP APPS");
  drawMenuBody(true);
}
static void drawMainMenuPartial(int oldIndex, int oldFirst) {
  (void)oldFirst;
  drawMenuItemRow(oldIndex, 0);
  drawMenuItemRow(uiMenuIndex, 0);
}

static uint16_t homeMeterColor(float peak) {
  if (peak >= 0.50f) return UI_RED;
  if (peak >= 0.16f) return UI_YELLOW;
  return UI_GREEN;
}
static void readHomeMeterSnapshot(float inputPeak[2], float outputPeak[4]) {
  portENTER_CRITICAL(&gMeterMux);
  inputPeak[0] = gInputPeakLinear[0];
  inputPeak[1] = gInputPeakLinear[1];
  for (int ch = 0; ch < 4; ++ch) outputPeak[ch] = gOutputPeakLinear[ch];
  portEXIT_CRITICAL(&gMeterMux);
}
static void drawHomeMeterBar(int x, int y, int w, float peak) {
  const float safePeak = clampf(peak, 0.0f, 1.0f);
  const int fillW = (int)lroundf(safePeak * (float)(w - 2));
  tft.fillRoundRect(x, y, w, 5, 2, UI_BG);
  tft.drawRoundRect(x, y, w, 5, 2, UI_EDGE);
  if (fillW > 0) tft.fillRoundRect(x + 1, y + 1, min(w - 2, fillW), 3, 1, homeMeterColor(safePeak));
}
static void drawHomeChannelTile(int idx, const DeviceConfig &c, const float inputPeak[2], const float outputPeak[4]) {
  const bool selected = (uiHomeIndex == idx);
  const bool input = idx < 2;
  const int channel = input ? idx : idx - 2;
  const bool muted = input ? c.inputMute[channel] : c.output[channel].mute;
  const int x = input ? (4 + channel * 78) : (4 + channel * 39);
  const int y = input ? 24 : 54;
  const int w = input ? 74 : 35;
  const int h = 27;
  const uint16_t bg = selected ? UI_PANEL2 : UI_PANEL;
  const uint16_t edge = selected ? UI_CYAN : (muted ? UI_RED : UI_EDGE);
  tft.fillRoundRect(x, y, w, h, 4, bg);
  tft.drawRoundRect(x, y, w, h, 4, edge);
  tft.setTextSize(1);
  tft.setTextColor(muted ? UI_RED : (selected ? UI_YELLOW : UI_WHITE), bg);
  tft.setCursor(x + 3, y + 4);
  if (input) { tft.print("IN "); tft.print(channel + 1); }
  else { tft.print("O"); tft.print(channel + 1); }
  tft.setTextColor(muted ? UI_RED : UI_GREEN, bg);
  if (input) {
    tft.setCursor(x + 39, y + 4);
    tft.print(muted ? "MUTE" : "ON");
  } else {
    tft.setCursor(x + 23, y + 4);
    tft.print(muted ? "M" : "ON");
  }
  drawHomeMeterBar(x + 3, y + 18, w - 6, input ? inputPeak[channel] : outputPeak[channel]);
}
static void drawHomeControls() {
  const bool masterSelected = (uiHomeIndex == 6);
  const uint16_t masterBg = masterSelected ? UI_PANEL2 : UI_PANEL;
  const uint16_t masterEdge = masterSelected ? UI_CYAN : (gMasterMute ? UI_RED : UI_GREEN);
  tft.fillRoundRect(4, 86, 152, 37, 5, masterBg);
  tft.drawRoundRect(4, 86, 152, 37, 5, masterEdge);
  tft.setTextColor(masterSelected ? UI_YELLOW : UI_WHITE, masterBg);
  tft.setCursor(12, 92); tft.print("MUTE MASTER");
  tft.setTextColor(gMasterMute ? UI_RED : UI_GREEN, masterBg);
  tft.setCursor(12, 104); tft.print(gMasterMute ? "MUTED" : "SOUND ON");
  tft.setTextColor(UI_EDGE, masterBg);
  tft.setCursor(12, 115); tft.print("LONG PRESS: OPEN MENU");
}
static void drawHomeDashboard() {
  uint32_t rev = 0;
  const DeviceConfig c = copyConfig(rev);
  float inputPeak[2], outputPeak[4];
  readHomeMeterSnapshot(inputPeak, outputPeak);
  tft.fillScreen(UI_BG);
  drawHeader("LEVEL MONITOR");
  for (int idx = 0; idx < 6; ++idx) drawHomeChannelTile(idx, c, inputPeak, outputPeak);
  drawHomeControls();
  lastHomeMeterDraw = millis();
}
static void drawHomeDashboardPartial(int oldIndex) {
  uint32_t rev = 0;
  const DeviceConfig c = copyConfig(rev);
  float inputPeak[2], outputPeak[4];
  readHomeMeterSnapshot(inputPeak, outputPeak);
  if (oldIndex >= 0 && oldIndex < 6) drawHomeChannelTile(oldIndex, c, inputPeak, outputPeak);
  if (uiHomeIndex >= 0 && uiHomeIndex < 6) drawHomeChannelTile(uiHomeIndex, c, inputPeak, outputPeak);
  drawHomeControls();
}
static void drawHomeMetersDynamic() {
  // Update ONLY the six meter-bar areas. Do not redraw channel cards, ON/MUTE
  // labels, selection borders, or the MASTER MUTE panel on the live meter timer.
  // The previous implementation repainted all cards and the master control every
  // 90 ms, which made the status text and mute indicator appear to flicker.
  float inputPeak[2], outputPeak[4];
  readHomeMeterSnapshot(inputPeak, outputPeak);

  // IN1 / IN2: card x = 4 + ch*78, meter x = card x+3, y = 24+18, width = 74-6.
  for (int ch = 0; ch < 2; ++ch) {
    drawHomeMeterBar(7 + ch * 78, 42, 68, inputPeak[ch]);
  }
  // OUT1..OUT4: card x = 4 + ch*39, meter x = card x+3, y = 54+18, width = 35-6.
  for (int ch = 0; ch < 4; ++ch) {
    drawHomeMeterBar(7 + ch * 39, 72, 29, outputPeak[ch]);
  }
  lastHomeMeterDraw = millis();
}

static void drawMatrixPage() {
  uint32_t rev = 0;
  DeviceConfig c = copyConfig(rev);
  drawHeader("ROUTING MATRIX");
  tft.fillRect(0, 20, 160, 108, UI_BG);
  tft.setTextSize(1);
  tft.setTextColor(UI_CYAN, UI_BG);
  tft.setCursor(7, 27); tft.print("IN / OUT MAP");
  const int colX[4] = {40, 70, 100, 130};
  const int rowY[2] = {49, 81};
  tft.setTextColor(UI_EDGE, UI_BG);
  for (int outCh = 0; outCh < 4; ++outCh) {
    tft.setCursor(colX[outCh] + 1, 38); tft.print("OUT"); tft.print(outCh + 1);
  }
  for (int inCh = 0; inCh < 2; ++inCh) {
    tft.fillRoundRect(5, rowY[inCh] + 1, 30, 23, 4, UI_PANEL);
    tft.drawRoundRect(5, rowY[inCh] + 1, 30, 23, 4, UI_EDGE);
    tft.setTextColor(UI_WHITE, UI_PANEL);
    tft.setCursor(10, rowY[inCh] + 9); tft.print("IN"); tft.print(inCh + 1);
    for (int outCh = 0; outCh < 4; ++outCh) {
      const int idx = inCh * 4 + outCh;
      const bool selected = (uiCursor == idx);
      const bool checked = c.inputRoute[inCh][outCh];
      const int x = colX[outCh] + 4, y = rowY[inCh] + 4;
      tft.fillRoundRect(x, y, 18, 18, 3, checked ? UI_PANEL2 : UI_PANEL);
      tft.drawRoundRect(x, y, 18, 18, 3, selected ? UI_YELLOW : UI_EDGE);
      if (checked) {
        tft.drawLine(x + 4, y + 9, x + 7, y + 13, UI_GREEN);
        tft.drawLine(x + 7, y + 13, x + 14, y + 4, UI_GREEN);
      }
    }
  }
  tft.fillRoundRect(5, 112, 150, 10, 4, UI_PANEL);
  tft.setTextColor(UI_YELLOW, UI_PANEL); tft.setCursor(8, 113); tft.print("PUSH=CHECK  HOLD=BACK");
}

static bool updateRtaLevels() {
  if (rtaHold || !gRtaMemoryReady || !audioReady) return false;
  const uint32_t now = millis();
  if ((uint32_t)(now - lastRtaCompute) < 100U) return false;

  uint32_t seq = 0;
  int8_t readBank = -1;
  portENTER_CRITICAL(&gRtaMux);
  seq = gRtaSequence;
  if (seq != gRtaDrawnSequence && gRtaReadBank < 0) {
    readBank = (int8_t)gRtaPublishedBank;
    gRtaReadBank = readBank;
  }
  portEXIT_CRITICAL(&gRtaMux);
  if (readBank < 0) return false;

  // Snapshot both input channels from the same completed audio block.
  const size_t copyBytes = RTA_SAMPLES * sizeof(float);
  memcpy(gRtaSnapshot[0], gRtaBuffers[(uint8_t)readBank][0], copyBytes);
  memcpy(gRtaSnapshot[1], gRtaBuffers[(uint8_t)readBank][1], copyBytes);

  portENTER_CRITICAL(&gRtaMux);
  gRtaReadBank = -1;
  portEXIT_CRITICAL(&gRtaMux);

  for (int ch = 0; ch < 2; ++ch) {
    float peak = -90.0f;
    for (int bin = 0; bin < (int)RTA_BANDS; ++bin) {
      const float omega = 2.0f * PI * RTA_FREQUENCIES[bin] / (float)SAMPLE_RATE;
      const float coeff = 2.0f * cosf(omega);
      float s1 = 0.0f, s2 = 0.0f;
      for (size_t n = 0; n < RTA_SAMPLES; ++n) {
        const float sample = gRtaSnapshot[ch][n] * gRtaWindow[n];
        const float s0 = sample + coeff * s1 - s2;
        s2 = s1;
        s1 = s0;
      }
      const float power = max(0.0f, s1 * s1 + s2 * s2 - coeff * s1 * s2);
      // Hann coherent-gain correction: 4/N estimates sine peak amplitude.
      const float amplitude = sqrtf(power) * (4.0f / (float)RTA_SAMPLES);
      const float db = 20.0f * log10f(max(amplitude, 0.00001f));
      gRtaLevels[ch][bin] = db;
      if (db > peak) peak = db;
    }
    gRtaPeakDb[ch] = peak;
  }
  gRtaDrawnSequence = seq;
  lastRtaCompute = now;
  return true;
}

static void drawRtaPage() {
  tft.fillRect(0, 20, 160, 108, UI_BG);
  char title[22];
  snprintf(title, sizeof(title), "RTA INPUT L/R");
  drawHeader(title);
  if (!audioReady) {
    tft.setTextColor(UI_RED, UI_BG); tft.setCursor(10, 48); tft.print("AUDIO NOT READY");
    tft.setTextColor(UI_EDGE, UI_BG); tft.setCursor(10, 72); tft.print("CHECK I2S STATUS");
    tft.setCursor(10, 106); tft.print("LONG PRESS: BACK");
    return;
  }
  if (!gRtaMemoryReady) {
    tft.setTextColor(UI_RED, UI_BG); tft.setCursor(10, 48); tft.print("RTA MEMORY ERROR");
    tft.setTextColor(UI_EDGE, UI_BG); tft.setCursor(10, 65); tft.print("ESP32 PSRAM NEEDED");
    tft.setCursor(10, 106); tft.print("LONG PRESS: BACK");
    return;
  }

  // Separate peak readouts make the L/R pair explicit.
  tft.setTextColor(UI_CYAN, UI_BG); tft.setCursor(5, 23); tft.print("L:");
  tft.setTextColor(UI_WHITE, UI_BG); tft.print(gRtaPeakDb[0], 1);
  tft.setTextColor(UI_YELLOW, UI_BG); tft.print(" R:");
  tft.setTextColor(UI_WHITE, UI_BG); tft.print(gRtaPeakDb[1], 1); tft.print("dB");

  const int top = 36, bottom = 89, graphH = bottom - top;
  for (int i = 0; i < 4; ++i) tft.drawFastHLine(7, bottom - i * graphH / 3, 146, UI_GRID);
  for (int i = 0; i < (int)RTA_BANDS; ++i) {
    const int x = 8 + i * 7;
    const int hL = (int)lroundf((clampf(gRtaLevels[0][i], -90.0f, -10.0f) + 90.0f) / 80.0f * graphH);
    const int hR = (int)lroundf((clampf(gRtaLevels[1][i], -90.0f, -10.0f) + 90.0f) / 80.0f * graphH);
    if (hL > 0) tft.fillRect(x, bottom - hL, 2, hL, UI_CYAN);
    if (hR > 0) tft.fillRect(x + 3, bottom - hR, 2, hR, UI_YELLOW);
  }
  tft.setTextColor(UI_WHITE, UI_BG); tft.setCursor(8, 93); tft.print("20  125  1k  9k  20k");
  tft.fillRect(7, 105, 5, 5, UI_CYAN); tft.setTextColor(UI_CYAN, UI_BG); tft.setCursor(15, 104); tft.print("L");
  tft.fillRect(30, 105, 5, 5, UI_YELLOW); tft.setTextColor(UI_YELLOW, UI_BG); tft.setCursor(38, 104); tft.print("R");
  tft.setTextColor(UI_WHITE, UI_BG); tft.setCursor(56, 104); tft.print("PUSH:HOLD/RUN");
  tft.setTextColor(rtaHold ? UI_YELLOW : UI_GREEN, UI_BG); tft.setCursor(5, 113); tft.print(rtaHold ? "HOLD  PUSH=RUN  LONG=BACK" : "RUN  PUSH=HOLD  LONG=BACK");
}

static void drawRtaPageDynamic() {
  // Preserve header, labels and grid; refresh only L/R peak readouts and spectrum columns.
  tft.fillRect(5, 22, 112, 11, UI_BG);
  tft.setTextColor(UI_CYAN, UI_BG); tft.setCursor(5, 23); tft.print("L:");
  tft.setTextColor(UI_WHITE, UI_BG); tft.print(gRtaPeakDb[0], 1);
  tft.setTextColor(UI_YELLOW, UI_BG); tft.print(" R:");
  tft.setTextColor(UI_WHITE, UI_BG); tft.print(gRtaPeakDb[1], 1); tft.print("dB");
  const int top = 36, bottom = 89, graphH = bottom - top;
  for (int i = 0; i < (int)RTA_BANDS; ++i) {
    const int x = 8 + i * 7;
    tft.fillRect(x, top + 1, 5, graphH - 1, UI_BG);
  }
  for (int i = 0; i < 4; ++i) tft.drawFastHLine(7, bottom - i * graphH / 3, 146, UI_GRID);
  for (int i = 0; i < (int)RTA_BANDS; ++i) {
    const int x = 8 + i * 7;
    const int hL = (int)lroundf((clampf(gRtaLevels[0][i], -90.0f, -10.0f) + 90.0f) / 80.0f * graphH);
    const int hR = (int)lroundf((clampf(gRtaLevels[1][i], -90.0f, -10.0f) + 90.0f) / 80.0f * graphH);
    if (hL > 0) tft.fillRect(x, bottom - hL, 2, hL, UI_CYAN);
    if (hR > 0) tft.fillRect(x + 3, bottom - hR, 2, hR, UI_YELLOW);
  }
}
// Compact engineering diagrams for the 160x128 TFT.
// These are parameter visualizations; the audio task remains independent.
static void drawMiniGrid(int x, int y, int w, int h, uint16_t color = UI_GRID) {
  for (int i = 0; i <= 4; ++i) tft.drawFastVLine(x + (w * i) / 4, y, h, color);
  for (int i = 0; i <= 3; ++i) tft.drawFastHLine(x, y + (h * i) / 3, w, color);
  tft.drawRect(x, y, w, h, UI_EDGE);
}
static int graphY(float db, float minDb, float maxDb, int top, int bottom) {
  const float v = clampf(db, minDb, maxDb);
  return bottom - (int)lroundf((v - minDb) * (float)(bottom - top) / (maxDb - minDb));
}
static float peakingBandDb(float f, const EqBand &e) {
  if (!e.enabled || fabsf(e.gainDb) < 0.01f || e.frequency < 1.0f) return 0.0f;
  const float A = powf(10.0f, e.gainDb / 40.0f);
  const float w0 = 2.0f * PI * e.frequency / (float)SAMPLE_RATE;
  const float alpha = sinf(w0) / (2.0f * clampf(e.q, 0.1f, 20.0f));
  const float cw = cosf(w0), sw = sinf(w0);
  const float b0 = 1.0f + alpha * A, b1 = -2.0f * cw, b2 = 1.0f - alpha * A;
  const float a0 = 1.0f + alpha / A, a1 = -2.0f * cw, a2 = 1.0f - alpha / A;
  const float w = 2.0f * PI * f / (float)SAMPLE_RATE;
  const float c1 = cosf(w), s1 = sinf(w), c2 = cosf(2.0f * w), s2 = sinf(2.0f * w);
  const float nr = b0 + b1 * c1 + b2 * c2;
  const float ni = -b1 * s1 - b2 * s2;
  const float dr = a0 + a1 * c1 + a2 * c2;
  const float di = -a1 * s1 - a2 * s2;
  const float den = dr * dr + di * di;
  if (den < 1.0e-12f) return 0.0f;
  const float mag2 = (nr * nr + ni * ni) / den;
  return 10.0f * log10f(max(mag2, 1.0e-10f));
}
static float eqCurveDb(float f, const OutputConfig &o) {
  float sum = 0.0f;
  for (int b = 0; b < (int)EQ_BANDS; ++b) sum += peakingBandDb(f, o.eq[b]);
  return clampf(sum, -18.0f, 18.0f);
}
static float crossHpfDb(float f, float fc, uint8_t slope, bool enabled) {
  if (!enabled) return 0.0f;
  const float order = max(1.0f, (float)slope / 6.0f);
  const float ratio = clampf(fc / max(f, 1.0f), 0.0001f, 1000.0f);
  return -10.0f * log10f(1.0f + powf(ratio, 2.0f * order));
}
static float crossLpfDb(float f, float fc, uint8_t slope, bool enabled) {
  if (!enabled) return 0.0f;
  const float order = max(1.0f, (float)slope / 6.0f);
  const float ratio = clampf(f / max(fc, 1.0f), 0.0001f, 1000.0f);
  return -10.0f * log10f(1.0f + powf(ratio, 2.0f * order));
}
static int frequencyToGraphX(float hz, int x0, int x1) {
  const float safeHz = clampf(hz, 20.0f, 20000.0f);
  const float pos = log10f(safeHz / 20.0f) / 3.0f;
  return x0 + (int)lroundf(pos * (float)(x1 - x0));
}
static const char *uiPageTitle() {
  if (uiPage == UI_MATRIX) return "ROUTING MATRIX";
  if (uiPage == UI_LEVEL) return uiDspTargetInput ? "INPUT GAIN" : "OUTPUT GAIN";
  switch (uiPage) {
    case UI_EQ: return "EQUALIZER";
    case UI_CROSS: return "CROSSOVER";
    case UI_DELAY: return "DELAY";
    case UI_DYNAMICS: return "COMPRESSOR";
    case UI_POLARITY: return "POLARITY";
    case UI_PRESET: return "PRESETS";
    case UI_SYSTEM: return "SYSTEM";
    case UI_RTA: return "RTA ANALYSER";
    default: return "LEON DSP";
  }
}
static void drawCompactGraph(const DeviceConfig &c) {
  OutputConfig view = c.output[uiOutputChannel];
  if (uiDspTargetInput) {
    const InputDspConfig &in = c.inputDsp[uiInputChannel];
    view.hpfHz = in.hpfHz; view.hpfType = in.hpfType; view.hpfSlope = in.hpfSlope;
    view.lpfHz = in.lpfHz; view.lpfType = in.lpfType; view.lpfSlope = in.lpfSlope;
    view.crossoverBypass = in.crossoverBypass;
    view.delayMs = in.delayMs; view.dynamicsEnabled = in.dynamicsEnabled;
    view.thresholdDb = in.thresholdDb; view.ratio = in.ratio;
    view.attackMs = in.attackMs; view.releaseMs = in.releaseMs;
    for (int b = 0; b < (int)EQ_BANDS; ++b) view.eq[b] = c.inputEq[uiInputChannel][b];
  }

  const int gx0 = 10, gx1 = 69, gt = 47, gb = 91;
  tft.fillRoundRect(5, 22, 70, 100, 5, UI_PANEL);
  tft.drawRoundRect(5, 22, 70, 100, 5, UI_EDGE);
  tft.setTextSize(1);
  tft.setTextColor(UI_CYAN, UI_PANEL);
  tft.setCursor(8, 27);
  switch (uiPage) {
    case UI_LEVEL: tft.print("GAIN METER"); break;
    case UI_INPUT: tft.print("INPUT PATH"); break;
    case UI_OUTPUT: tft.print("OUTPUT PATH"); break;
    case UI_EQ: tft.print("EQ CURVE"); break;
    case UI_CROSS: tft.print("FILTER CURVE"); break;
    case UI_DELAY: tft.print("ALIGNMENT"); break;
    case UI_DYNAMICS: tft.print("DYN CURVE"); break;
    case UI_POLARITY: tft.print("PHASE WAVE"); break;
    case UI_PRESET: tft.print("MEMORY MAP"); break;
    case UI_SYSTEM: tft.print("SYSTEM MAP"); break;
    default: tft.print("GRAPH"); break;
  }
  tft.drawFastHLine(8, 39, 62, UI_EDGE);

  if (uiPage == UI_EQ) {
    drawMiniGrid(gx0, gt, gx1-gx0, gb-gt);
    int px = gx0;
    int py = graphY(eqCurveDb(20.0f, view), -12.0f, 12.0f, gt, gb);
    for (int i = 1; i < 28; ++i) {
      const float f = 20.0f * powf(1000.0f, (float)i / 27.0f);
      const int x = gx0 + (gx1-gx0) * i / 27;
      const int y = graphY(eqCurveDb(f, view), -12.0f, 12.0f, gt, gb);
      tft.drawLine(px, py, x, y, UI_CYAN); px=x; py=y;
    }
    const float f = clampf(view.eq[uiEqBand].frequency, 20.0f, 20000.0f);
    const int mx = gx0 + (int)lroundf(log10f(f/20.0f)/3.0f*(gx1-gx0));
    const int my = graphY(eqCurveDb(f, view), -12.0f, 12.0f, gt, gb);
    tft.drawFastVLine(mx, gt, gb-gt, UI_YELLOW); tft.fillCircle(mx,my,2,UI_YELLOW);
    tft.setTextColor(UI_EDGE, UI_PANEL); tft.setCursor(8, 105); tft.print("20Hz");
    tft.setCursor(42, 105); tft.print("20kHz");
  } else if (uiPage == UI_CROSS) {
    drawMiniGrid(gx0, gt, gx1-gx0, gb-gt);
    int oh=0, ol=0, os=0;
    for (int i=0;i<28;++i) {
      const float f=20.0f*powf(1000.0f,(float)i/27.0f);
      const int x=gx0+(gx1-gx0)*i/27;
      const int yh=graphY(crossHpfDb(f,view.hpfHz,view.hpfSlope,!view.crossoverBypass),-48,0,gt,gb);
      const int yl=graphY(crossLpfDb(f,view.lpfHz,view.lpfSlope,!view.crossoverBypass),-48,0,gt,gb);
      const int ys=graphY(crossHpfDb(f,view.hpfHz,view.hpfSlope,!view.crossoverBypass)+crossLpfDb(f,view.lpfHz,view.lpfSlope,!view.crossoverBypass),-48,0,gt,gb);
      if(i){const int xp=gx0+(gx1-gx0)*(i-1)/27;tft.drawLine(xp,oh,x,yh,UI_CYAN);tft.drawLine(xp,ol,x,yl,UI_YELLOW);tft.drawLine(xp,os,x,ys,UI_WHITE);}
      oh=yh;ol=yl;os=ys;
    }
    const int hx=frequencyToGraphX(view.hpfHz,gx0,gx1), lx=frequencyToGraphX(view.lpfHz,gx0,gx1);
    for(int y=gt;y<gb;y+=5){tft.drawFastVLine(hx,y,2,UI_CYAN);tft.drawFastVLine(lx,y,2,UI_YELLOW);}
    tft.setTextColor(UI_CYAN,UI_PANEL);tft.setCursor(8,105);tft.print("HPF");
    tft.setTextColor(UI_YELLOW,UI_PANEL);tft.setCursor(43,105);tft.print("LPF");
    tft.setTextColor(UI_WHITE,UI_PANEL);tft.setCursor(8,114);tft.print("RESPONSE");
  } else if (uiPage == UI_DYNAMICS) {
    drawMiniGrid(gx0, gt, gx1-gx0, gb-gt);
    int px=gx0, py=gb;
    for(int i=0;i<=28;++i){
      const float inDb=-60.0f+72.0f*(float)i/28.0f;
      const float outDb=(inDb<=view.thresholdDb)?inDb:view.thresholdDb+(inDb-view.thresholdDb)/max(1.0f,view.ratio);
      const int x=gx0+(gx1-gx0)*i/28, y=graphY(outDb,-60,12,gt,gb);
      if(i)tft.drawLine(px,py,x,y,UI_CYAN);px=x;py=y;
    }
    const int tx=gx0+(int)lroundf((clampf(view.thresholdDb,-60,12)+60)/72.0f*(gx1-gx0));
    for(int y=gt+2;y<gb;y+=6)tft.drawFastVLine(tx,y,2,UI_YELLOW);
    tft.setTextColor(UI_EDGE,UI_PANEL);tft.setCursor(8,108);tft.print("DYNAMICS");
  } else if (uiPage == UI_DELAY) {
    const int shift=(int)lroundf(clampf(view.delayMs/300.0f,0,1)*35.0f);
    tft.drawFastHLine(9,59,60,UI_EDGE);tft.drawFastHLine(9,78,60,UI_EDGE);
    for(int x=12;x<65;x+=17){tft.drawLine(x,59,x+3,50,UI_CYAN);tft.drawLine(x+3,50,x+6,59,UI_CYAN);const int xx=min(69,x+shift);tft.drawLine(xx,78,xx+3,69,UI_YELLOW);tft.drawLine(xx+3,69,xx+6,78,UI_YELLOW);}
    tft.setTextColor(UI_CYAN,UI_PANEL);tft.setCursor(8,47);tft.print("REF");
    tft.setTextColor(UI_YELLOW,UI_PANEL);tft.setCursor(8,66);tft.print("DELAY");
    tft.setTextColor(UI_EDGE,UI_PANEL);tft.setCursor(8,108);tft.print("REF TO DEL");
  } else if (uiPage == UI_LEVEL) {
    const float gain = uiDspTargetInput ? c.inputGainDb[uiInputChannel] : c.output[uiOutputChannel].gainDb;
    const bool muted = uiDspTargetInput ? c.inputMute[uiInputChannel] : c.output[uiOutputChannel].mute;
    tft.drawRect(8, 67, 60, 10, UI_EDGE);
    const float minGain = uiDspTargetInput ? -30.0f : -60.0f;
    const float gainSpan = 12.0f - minGain;
    const int bw = (int)lroundf((clampf(gain - minGain, 0.0f, gainSpan) / gainSpan) * 58.0f);
    if (bw > 0) tft.fillRect(9, 68, min(58, bw), 8, UI_CYAN);
    for (int tick = 0; tick <= 4; ++tick) tft.drawFastVLine(9 + tick * 14, 79, 3, UI_EDGE);
    tft.setTextColor(UI_EDGE, UI_PANEL); tft.setCursor(8, 91); tft.print("GAIN RANGE");
  } else if (uiPage == UI_POLARITY) {
    const int mid=70; tft.drawFastHLine(gx0,mid,gx1-gx0,UI_GRID);
    int px=gx0,py=mid;
    for(int x=gx0+1;x<=gx1;++x){const float phase=(float)(x-gx0)*2.0f*PI/18.0f;const float v=sinf(phase)*(view.polarityInvert?-1.0f:1.0f);const int y=mid-(int)lroundf(v*17.0f);tft.drawLine(px,py,x,y,view.polarityInvert?UI_YELLOW:UI_CYAN);px=x;py=y;}
    tft.setTextColor(UI_EDGE,UI_PANEL);tft.setCursor(8,108);tft.print("PHASE");
  } else if (uiPage == UI_INPUT) {
    tft.drawRoundRect(8,50,60,20,3,UI_CYAN);tft.drawRoundRect(8,80,60,20,3,UI_BLUE);
    tft.setTextColor(UI_WHITE,UI_PANEL);tft.setCursor(14,57);tft.print("ADC IN");tft.setCursor(14,87);tft.print("DSP IN");
    tft.drawFastVLine(38,70,10,UI_YELLOW);tft.fillTriangle(34,77,42,77,38,82,UI_YELLOW);
    tft.setTextColor(UI_CYAN,UI_PANEL);tft.setCursor(8,106);tft.print(gInputNames[uiInputChannel]);
  } else if (uiPage == UI_OUTPUT) {
    tft.drawRoundRect(8,51,60,18,3,UI_CYAN);tft.drawRoundRect(8,82,60,18,3,UI_GREEN);
    tft.setTextColor(UI_WHITE,UI_PANEL);tft.setCursor(14,57);tft.print(view.source==0?"LEFT":(view.source==1?"RIGHT":"MIX"));
    tft.drawFastVLine(38,69,13,UI_YELLOW);tft.fillTriangle(34,78,42,78,38,83,UI_YELLOW);
    tft.setCursor(14,88);tft.print("OUT ");tft.print(uiOutputChannel+1);
    tft.setTextColor(view.mute?UI_RED:UI_GREEN,UI_PANEL);tft.setCursor(8,106);tft.print(view.mute?"MUTED":"ACTIVE");
  } else if (uiPage == UI_PRESET) {
    for(int i=0;i<5;++i){const int x=8+(i%3)*21,y=52+(i/3)*23;const bool saved=presetSlotSaved(i+1);const bool sel=(uiPresetSlot==i+1);tft.fillRoundRect(x,y,17,18,3,sel?UI_PANEL2:UI_PANEL);tft.drawRoundRect(x,y,17,18,3,sel?UI_YELLOW:(saved?UI_GREEN:UI_EDGE));tft.setTextColor(sel?UI_YELLOW:UI_WHITE,sel?UI_PANEL2:UI_PANEL);tft.setCursor(x+6,y+6);tft.print(i+1);}
    tft.setTextColor(UI_EDGE,UI_PANEL);tft.setCursor(8,108);tft.print("5 SLOTS");
  } else if (uiPage == UI_SYSTEM) {
    tft.drawRoundRect(8,52,60,18,3,UI_CYAN);tft.drawRoundRect(8,80,60,18,3,UI_BLUE);
    tft.setTextColor(UI_WHITE,UI_PANEL);tft.setCursor(14,58);tft.print("PCM1808");tft.setCursor(14,86);tft.print("2x PCM5102");
    tft.setTextColor(audioReady?UI_GREEN:UI_RED,UI_PANEL);tft.setCursor(8,107);tft.print(audioReady?"AUDIO READY":"AUDIO STOP");
  }
}

static void drawPageDiagram(const DeviceConfig &c) {
  // Called on full-page draw and on graph refresh; never clear the edit list here.
  drawCompactGraph(c);
  tft.drawFastVLine(77, 23, 99, UI_EDGE);
}
static void drawPageRow(int idx, const DeviceConfig &c) {
  const int first = pageFirstVisibleRow(uiCursor);
  if (idx < first || idx >= first + 6 || idx >= uiItemCount()) return;
  const int y = 24 + (idx - first) * 16;
  const bool selected = (idx == uiCursor);
  int numericMarkerPos = -1;
  int choiceMarkerStart = -1;
  int choiceMarkerLength = 0;
  const uint16_t rowBg = selected ? UI_PANEL2 : UI_PANEL;
  tft.fillRoundRect(83, y, 70, 14, 3, rowBg);
  // Each setting remains inside its own box. Focus is cyan; edit is yellow.
  const uint16_t rowOutline = selected ? (uiEditing ? UI_YELLOW : UI_CYAN) : UI_EDGE;
  tft.drawRoundRect(83, y, 70, 14, 3, rowOutline);
  String label = uiItemLabel(idx);
  String value = uiItemValue(idx, c);
  String line;
  const bool presetNameOnly = (uiPage == UI_PRESET && idx == 2);
  if (presetNameOnly) line = value;
  else {
    line = label;
    if (value.length()) { line += ':'; line += value; }
  }

  // Numeric edit: retain every character and draw an underline below the active digit.
  if (selected && numericEditField != NUM_EDIT_NONE && numericEditField == currentNumericEditField()) {
    const int prefixChars = presetNameOnly ? 0 : (int)label.length() + 1;
    const int activePos = prefixChars + (int)numericEditPos;
    if (activePos >= 0 && activePos < (int)line.length()) numericMarkerPos = activePos;
  } else if (selected && uiEditing && uiPage == UI_PRESET && idx == 2) {
    // Name editing intentionally uses the underscore as the selected character.
    const int activePos = (int)presetNamePos;
    if (activePos >= 0 && activePos < (int)line.length()) line.setCharAt(activePos, '_');
  } else if (selected && uiEditing && (uiPage == UI_INPUT || uiPage == UI_OUTPUT) && idx == 2) {
    // Channel-name editing intentionally uses the underscore as the selected character.
    const int activePos = (int)label.length() + 1 + (int)channelNamePos;
    if (activePos >= 0 && activePos < (int)line.length()) line.setCharAt(activePos, '_');
  } else if (selected && uiEditing && line.length() > 0) {
    // Discrete fields (CH, band, ON/OFF, filter type, slope, polarity, slot)
    // keep their full text; underline the value rather than replacing a letter.
    choiceMarkerStart = presetNameOnly ? 0 : (int)label.length() + 1;
  }

  // The right panel is 73px wide; 11 built-in 6px glyphs fit from x=86 to x=152.
  if (line.length() > 11) line.remove(11);
  if (choiceMarkerStart >= 0 && choiceMarkerStart < (int)line.length()) {
    choiceMarkerLength = (int)line.length() - choiceMarkerStart;
  }
  tft.setTextSize(1);
  tft.setTextColor(selected ? (uiEditing ? UI_YELLOW : UI_WHITE) : UI_WHITE, rowBg);
  tft.setCursor(86, y + 4);
  tft.print(line);

  if (numericMarkerPos >= 0 && numericMarkerPos < 11) {
    const int markerX = 86 + numericMarkerPos * 6;
    tft.drawFastHLine(markerX, y + 12, 5, UI_YELLOW);
  } else if (choiceMarkerStart >= 0 && choiceMarkerLength > 0) {
    const int markerX = 86 + choiceMarkerStart * 6;
    const int markerW = min(66 - choiceMarkerStart * 6, choiceMarkerLength * 6);
    if (markerW > 0) tft.drawFastHLine(markerX, y + 12, markerW, UI_YELLOW);
  }
}
static void drawPageValuePartial(int idx, const DeviceConfig &c) {
  drawPageRow(idx, c);
}
static void drawPresetNamePartial() {
  if (uiPage != UI_PRESET) return;
  uint32_t rev = 0;
  DeviceConfig c = copyConfig(rev);
  drawPageRow(2, c);
}
static void drawPageRows(const DeviceConfig &c, bool clearRows) {
  if (clearRows) {
    tft.fillRoundRect(81, 22, 74, 100, 4, UI_BG);
    tft.drawRoundRect(81, 22, 74, 100, 4, UI_EDGE);
  }
  const int first = pageFirstVisibleRow(uiCursor);
  for (int row = 0; row < 6 && first + row < uiItemCount(); ++row) drawPageRow(first + row, c);
}
static void drawPage() {
  uint32_t snapshotRevision = 0;
  DeviceConfig c = copyConfig(snapshotRevision);
  drawHeader(uiPageTitle());
  tft.fillRect(0, 20, 160, 108, UI_BG);
  tft.fillRoundRect(81, 22, 74, 100, 4, UI_BG);
  tft.drawRoundRect(81, 22, 74, 100, 4, UI_EDGE);
  drawPageDiagram(c);
  drawPageRows(c, false);
}
static void drawPresetConfirmationOverlay() {
  if (uiPage != UI_PRESET || presetConfirmAction == PRESET_CONFIRM_NONE) return;

  const char *title = "CONFIRM ACTION";
  const char *message = "";
  char titleBuffer[22];
  switch (presetConfirmAction) {
    case PRESET_CONFIRM_SAVE:
      snprintf(titleBuffer, sizeof(titleBuffer), "SAVE P%u?", uiPresetSlot);
      title = titleBuffer;
      message = "STORE CURRENT STATE?";
      break;
    case PRESET_CONFIRM_LOAD:
      snprintf(titleBuffer, sizeof(titleBuffer), "LOAD P%u?", uiPresetSlot);
      title = titleBuffer;
      message = "REPLACE ACTIVE DSP?";
      break;
    case PRESET_CONFIRM_RESET:
      title = "RESET ACTIVE?";
      message = "SAVED SLOTS KEPT";
      break;
    default: break;
  }

  // Compact modal remains inside the 4px neon frame on the 160x128 ST7735S.
  const int x = 13, y = 34, w = 134, h = 62;
  tft.fillRoundRect(x, y, w, h, 7, UI_PANEL);
  tft.drawRoundRect(x, y, w, h, 7, UI_CYAN);
  tft.setTextSize(1);
  tft.setTextColor(UI_CYAN, UI_PANEL);
  int titleX = x + (w - (int)strlen(title) * 6) / 2;
  if (titleX < x + 4) titleX = x + 4;
  tft.setCursor(titleX, y + 6);
  tft.print(title);

  tft.setTextColor(UI_WHITE, UI_PANEL);
  int messageX = x + (w - (int)strlen(message) * 6) / 2;
  if (messageX < x + 3) messageX = x + 3;
  tft.setCursor(messageX, y + 20);
  tft.print(message);

  const int buttonY = y + 35;
  const int yesX = x + 15, yesW = 43;
  const int cancelX = x + 73, cancelW = 48;
  const uint16_t yesBg = presetConfirmYesSelected ? UI_GREEN : UI_PANEL2;
  const uint16_t cancelBg = presetConfirmYesSelected ? UI_PANEL2 : UI_RED;
  tft.fillRoundRect(yesX, buttonY, yesW, 17, 4, yesBg);
  tft.drawRoundRect(yesX, buttonY, yesW, 17, 4, UI_EDGE);
  tft.fillRoundRect(cancelX, buttonY, cancelW, 17, 4, cancelBg);
  tft.drawRoundRect(cancelX, buttonY, cancelW, 17, 4, UI_EDGE);
  tft.setTextColor(presetConfirmYesSelected ? UI_BG : UI_WHITE, yesBg);
  tft.setCursor(yesX + (yesW - 2 * 6) / 2, buttonY + 5);
  tft.print("YA");
  tft.setTextColor(presetConfirmYesSelected ? UI_WHITE : UI_WHITE, cancelBg);
  tft.setCursor(cancelX + (cancelW - 5 * 6) / 2, buttonY + 5);
  tft.print("BATAL");

  tft.setTextColor(UI_EDGE, UI_PANEL);
  tft.setCursor(x + 25, y + 54);
  tft.print("ROTATE / PRESS");
}

static void drawPagePartial(int oldCursor, int oldWindow) {
  uint32_t rev = 0;
  DeviceConfig c = copyConfig(rev);
  const int newWindow = pageFirstVisibleRow(uiCursor);
  if (oldWindow != newWindow) {
    drawPageRows(c, true);
  } else {
    if (oldCursor >= 0) drawPageRow(oldCursor, c);
    drawPageRow(uiCursor, c);
  }
}
static void renderUi() {
  if (!displayReady) return;
  const uint32_t now = millis();
  const bool rtaUpdated = (uiPage == UI_RTA) ? updateRtaLevels() : false;

  if (uiDirty) {
    uiPendingGraphRefresh = false; // discard a queued graph from the previous page
    if (uiPage == UI_HOME) drawHomeDashboard();
    else if (uiPage == UI_MENU_PAGE) drawMainMenu();
    else if (uiPage == UI_MATRIX) drawMatrixPage();
    else if (uiPage == UI_RTA) drawRtaPage();
    else drawPage();
    if (uiPage == UI_PRESET && presetConfirmAction != PRESET_CONFIRM_NONE) {
      drawPresetConfirmationOverlay();
    }
    uiDirty = false;
    clearPartialUiState();
    drawNeonDisplayFrame();
    lastUiDraw = now;
    return;
  }

  // Encoder navigation is incremental: redraw only old/new focus, menu rows,
  // or the active parameter rows. Never fillScreen() while the knob is moving.
  bool frameNeedsRedraw = false;
  if (uiPartialMode != UI_PARTIAL_NONE) {
    const UiPartialMode mode = uiPartialMode;
    const int oldIndex = uiPartialOldIndex;
    const int oldWindow = uiPartialOldWindow;
    const bool graphDirty = uiPartialGraphDirty;
    clearPartialUiState();
    if (mode == UI_PARTIAL_MENU && uiPage == UI_HOME) drawHomeDashboardPartial(oldIndex);
    else if (mode == UI_PARTIAL_MENU && uiPage == UI_MENU_PAGE) drawMainMenuPartial(oldIndex, oldWindow);
    else if (mode == UI_PARTIAL_PAGE && uiPage == UI_MATRIX) {
      drawMatrixPage();
    } else if (mode == UI_PARTIAL_PAGE && uiPage != UI_HOME && uiPage != UI_MENU_PAGE && uiPage != UI_RTA) {
      if (graphDirty) uiPendingGraphRefresh = true;
      drawPagePartial(oldIndex, oldWindow);
    } else if (mode == UI_PARTIAL_VALUE && uiPage != UI_HOME && uiPage != UI_MENU_PAGE && uiPage != UI_RTA) {
      uint32_t rev = 0; DeviceConfig c = copyConfig(rev);
      drawPageValuePartial(uiCursor, c);
    } else if (mode == UI_PARTIAL_PRESET_NAME && uiPage == UI_PRESET) {
      drawPresetNamePartial();
    }
    frameNeedsRedraw = true;
    lastUiDraw = now;
  }

  // Coalesce graph repainting while the encoder is spun quickly. The graph
  // card is refreshed even during editing, so EQ/crossover curves and cutoff
  // markers follow the live value. Only the 156x56 card is repainted; the whole
  // TFT page is never cleared during a parameter turn.
  if (presetConfirmAction == PRESET_CONFIRM_NONE && uiPendingGraphRefresh &&
      uiPage != UI_HOME && uiPage != UI_MENU_PAGE && uiPage != UI_MATRIX && uiPage != UI_RTA &&
      (uint32_t)(now - lastGraphRefreshAt) >= 100) {
    uint32_t rev = 0;
    DeviceConfig c = copyConfig(rev);
    drawPageDiagram(c);
    lastGraphRefreshAt = now;
    uiPendingGraphRefresh = false;
    frameNeedsRedraw = true;
  }

  if (uiPage == UI_HOME && (uint32_t)(now - lastHomeMeterDraw) >= 90U) {
    drawHomeMetersDynamic();
    lastUiDraw = now;
    frameNeedsRedraw = true;
  }
  if (rtaUpdated && uiPage == UI_RTA) {
    drawRtaPageDynamic();
    lastUiDraw = now;
    frameNeedsRedraw = true;
  }

  // Last paint operation on any incremental UI update: guarantee continuous green edges.
  if (frameNeedsRedraw) drawNeonDisplayFrame();
}
static void setupLocalUi() {
  gRtaCaptureEnabled = false;
  pinMode(PIN_ROTARY_A, INPUT_PULLUP);
  pinMode(PIN_ROTARY_B, INPUT_PULLUP);
  pinMode(PIN_ROTARY_SW, INPUT_PULLUP);
  rotaryPrevState = (digitalRead(PIN_ROTARY_A) ? 2 : 0) | (digitalRead(PIN_ROTARY_B) ? 1 : 0);
  // RTA spectrum buffers are allocated during setup when PSRAM is available.
  for (int ch = 0; ch < 2; ++ch) {
    for (int i = 0; i < (int)RTA_BANDS; ++i) gRtaLevels[ch][i] = -90.0f;
    gRtaPeakDb[ch] = -90.0f;
  }
  SPI.begin(PIN_TFT_SCLK, -1, PIN_TFT_MOSI, PIN_TFT_CS);
  tft.initR(INITR_BLACKTAB);
  tft.setRotation(1);       // ST7735S landscape: 160x128
  tft.setSPISpeed(16000000); // conservative SPI clock for stable wiring
  tft.fillScreen(UI_BG);
  displayReady = true;
  // Centered five-second LEON AUDIO boot screen, drawn at native 160x128 resolution.
  // The complete logo/text/progress group is horizontally centered inside a double frame.
  tft.fillScreen(UI_BG);
  tft.drawRoundRect(6, 6, 148, 116, 9, UI_CYAN);
  tft.drawRoundRect(10, 10, 140, 108, 7, UI_EDGE);
  // Corner accents make the boot frame look like a finished processor front panel.
  tft.drawFastHLine(14, 16, 10, UI_BLUE); tft.drawFastVLine(14, 16, 7, UI_BLUE);
  tft.drawFastHLine(136, 16, 10, UI_BLUE); tft.drawFastVLine(145, 16, 7, UI_BLUE);
  tft.drawFastHLine(14, 111, 10, UI_BLUE); tft.drawFastVLine(14, 104, 7, UI_BLUE);
  tft.drawFastHLine(136, 111, 10, UI_BLUE); tft.drawFastVLine(145, 104, 7, UI_BLUE);

  // Centered animated equalizer emblem.
  tft.fillRoundRect(41, 10, 78, 40, 8, UI_PANEL);
  tft.drawRoundRect(41, 10, 78, 40, 8, UI_CYAN);
  tft.drawRoundRect(45, 14, 70, 32, 5, UI_GRID);
  // Only the large LEON AUDIO wordmark is an image. The original byline,
  // status text, equalizer animation, frame, and 5-second loading animation stay unchanged.
  tft.drawRGBBitmap((160 - LEON_AUDIO_LOGO_WIDTH) / 2,
                    53,
                    LEON_AUDIO_LOGO,
                    LEON_AUDIO_LOGO_WIDTH,
                    LEON_AUDIO_LOGO_HEIGHT);
  tft.setTextSize(1);
  const char *subtitle = "by Leon Production";
  tft.setTextColor(UI_CYAN, UI_BG);
  tft.setCursor((160 - (int)strlen(subtitle) * 6) / 2, 73); tft.print(subtitle);
  const char *status = "AUDIO ENGINE STARTUP";
  tft.setTextColor(UI_EDGE, UI_BG);
  tft.setCursor((160 - (int)strlen(status) * 6) / 2, 84); tft.print(status);
  tft.drawRoundRect(15, 104, 130, 10, 3, UI_EDGE);
  tft.fillRoundRect(17, 106, 126, 6, 2, UI_PANEL2);

  const uint32_t bootStart = millis();
  const uint32_t bootDuration = 5000;
  static const uint8_t bootBars[8] = {7, 13, 20, 25, 25, 20, 13, 7};
  int lastPercent = -1;
  while ((uint32_t)(millis() - bootStart) < bootDuration) {
    const uint32_t elapsed = millis() - bootStart;
    const int progress = (int)min(100UL, elapsed * 100UL / bootDuration);
    // Repaint only the interior of the framed emblem; the outer border and type stay fixed.
    tft.fillRect(48, 17, 64, 25, UI_PANEL);
    for (int i = 0; i < 8; ++i) {
      const float wave = 0.28f + 0.72f * fabsf(sinf((float)elapsed * 0.0065f + (float)i * 0.58f));
      const int h = max(3, (int)lroundf((float)bootBars[i] * wave));
      const int x = 51 + i * 8;
      const int y = 41 - h;
      const uint16_t color = (i == 3 || i == 4) ? UI_CYAN : UI_BLUE;
      tft.fillRoundRect(x, y, 4, h, 1, color);
    }
    // Subtle moving highlight on the lower frame.
    tft.drawFastHLine(15, 119, 130, UI_GRID);
    const int pulseX = 16 + (int)((elapsed / 18U) % 128U);
    tft.drawFastVLine(pulseX, 117, 4, UI_CYAN);

    tft.fillRoundRect(17, 106, 126, 6, 2, UI_PANEL2);
    const int fillW = (126 * progress) / 100;
    if (fillW > 0) tft.fillRoundRect(17, 106, fillW, 6, 2, UI_CYAN);
    if (progress != lastPercent) {
      tft.fillRect(48, 92, 64, 9, UI_BG);
      char percentText[12];
      snprintf(percentText, sizeof(percentText), "START %d%%", progress);
      tft.setTextColor(UI_YELLOW, UI_BG);
      tft.setCursor((160 - (int)strlen(percentText) * 6) / 2, 93);
      tft.print(percentText);
      lastPercent = progress;
    }
    delay(35);
  }
  tft.fillRoundRect(17, 106, 126, 6, 2, UI_CYAN);
  tft.fillRect(10, 81, 140, 14, UI_BG); // Clear the full centered startup line, not only its middle.
  const char *readyText = "SYSTEM READY";
  tft.setTextColor(UI_GREEN, UI_BG);
  tft.setCursor((160 - (int)strlen(readyText) * 6) / 2, 84); tft.print(readyText);
  drawNeonDisplayFrame();
  clearPartialUiState();
  uiDirty = true;
}

// ----------------------------- ARDUINO ENTRY ----------------------------
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println();
  Serial.println("====================================");
  Serial.println(" LEON PRODUCTION - DLMS MINI");
  Serial.println(" LOCAL TFT / v0.9.4 ORIGINAL BOOT LAYOUT + LOGO ONLY + CHANNEL REFRESH");
  Serial.println(" 2 INPUT / 4 OUTPUT / 48 kHz");
  Serial.println(" FIXED DSP: INPUT L/R TRIM +1dB (5dB LOWER); OUT1..4 9kHz FIXED EQ 0dB (FLAT)");
  Serial.println(" RTA: INPUT L/R ONLY, ON-DEMAND PSRAM BUFFER");
  Serial.println(" SAFETY: MASTER MUTE ON AT POWER-UP; HOME IS 2-IN/4-OUT LEVEL GRID");
  Serial.println(" DIAG: I2S RX/TX error warnings enabled; active FFat writes wait for MASTER MUTE.");
  Serial.println("====================================");

  setDefaults();
  gMasterMute = true; // release master mute from the HOME dashboard MUTE MASTER tile

  storageReady = FFat.begin(false);
  if (!storageReady) {
    Serial.println("FATFS mount failed; automatic format skipped to protect existing presets.");
  }
  Serial.printf("FATFS: %s; total=%u; used=%u; free=%u bytes\n",
                storageReady ? "READY" : "UNAVAILABLE",
                (unsigned)(storageReady ? FFat.totalBytes() : 0),
                (unsigned)(storageReady ? FFat.usedBytes() : 0),
                (unsigned)(storageReady ? FFat.freeBytes() : 0));
  if (storageReady) {
    if (!FFat.exists(PRESET_DIRECTORY)) {
      if (!FFat.mkdir(PRESET_DIRECTORY)) Serial.println("WARNING: cannot create dedicated preset directory.");
    }
    loadPresetNameCache();
    loadChannelNames();
    Serial.printf("PRESET DIRECTORY: %s\n", PRESET_DIRECTORY);
    // v0.5.9 starts in clean factory STANDARD state and isolates slot files. Previous-version active
    // files and preset folders are intentionally not imported, because earlier
    // firmware revisions could have duplicated slot data. Old files remain on FFat.
    String savedState = storageReadText("/active_tft_v059.json");
    if (savedState.length() > 0) {
      if (applyJsonState(savedState)) configDirty = false;
      else Serial.println("Saved local config invalid; using defaults.");
    }
    // Apply once after upgrading: active INPUT + OUTPUT EQ starts flat, while
    // the five saved program slots remain untouched and retain their own EQ.
    // IMPORTANT: persist and verify the flattened active state BEFORE writing
    // the migration marker. If power is lost or storage fails, the missing marker
    // forces a safe retry on the next boot instead of silently keeping old EQ.
    if (!FFat.exists(EQ_FLAT_MIGRATION_PATH)) {
      const bool changed = flattenActiveEqForV085();
      const bool activeSaved = storageWriteAtomic("/active_tft_v059.json", serializeState());
      if (activeSaved) {
        configDirty = false;
        const bool markerOk = storageWriteAtomic(
          EQ_FLAT_MIGRATION_PATH, "{\"version\":2,\"eq\":\"flat\",\"activeSaved\":true}");
        Serial.printf("EQ FLAT MIGRATION: active=%s saved=VERIFIED marker=%s; preset slots preserved\n",
                      changed ? "RESET" : "ALREADY FLAT", markerOk ? "SAVED" : "RETRY NEXT BOOT");
      } else {
        configDirty = true;
        lastConfigChange = millis();
        Serial.println("EQ FLAT MIGRATION: active state write FAILED; marker NOT written; will retry next boot.");
      }
    } else {
      Serial.println("EQ FLAT MIGRATION: already applied; saved active EQ settings preserved.");
    }
    restoreLastActivePresetAtBoot();
    int validPresetCount = 0;
    for (uint8_t slot = 1; slot <= 5; ++slot) {
      const bool saved = presetSlotSaved(slot);
      if (saved) ++validPresetCount;
      Serial.printf("PRESET SLOT %u: %s\n", slot, saved ? "SAVED / VERIFIED" : "EMPTY OR INVALID");
    }
    Serial.printf("PRESET SCAN: %d/5 valid slots; selected=P%u\n", validPresetCount, uiPresetSlot);
  }

  Serial.printf("PSRAM: %s (%u bytes free)\n", psramFound() ? "YES" : "NO", (unsigned)ESP.getFreePsram());
  if (!psramFound()) Serial.println("WARNING: PSRAM not detected; delay buffers may use internal RAM.");
  const bool delayReady = allocateDelayMemory();
  if (!delayReady) Serial.println("WARNING: Delay RAM unavailable; delay may be bypassed.");
  gRtaMemoryReady = false;
  gRtaCaptureEnabled = false;
  if (psramFound() && allocateRtaMemory()) {
    for (size_t n = 0; n < RTA_SAMPLES; ++n) {
      gRtaWindow[n] = 0.5f - 0.5f * cosf((2.0f * PI * (float)n) / (float)(RTA_SAMPLES - 1));
    }
    Serial.println("RTA: READY (capture only while RTA page is open)");
  } else {
    Serial.println("RTA: UNAVAILABLE (PSRAM buffer allocation failed; menu will report this)");
  }

  if (setupAudioI2S()) {
    audioReady = true;
    const BaseType_t taskOk = xTaskCreatePinnedToCore(audioTask, "leon_audio", 12288, nullptr, 18, nullptr, 1);
    if (taskOk == pdPASS) Serial.println("Audio engine started.");
    else { audioReady = false; Serial.println("ERROR: Audio task creation failed."); }
  } else {
    Serial.println("Audio engine NOT started. Check I2S wiring/configuration.");
  }
  // Show the five-second logo/loading animation after storage and audio startup.
  setupLocalUi();
  uiDirty = true;
}

void loop() {
  pollRotary();
  renderUi();

  // Flash writes are deferred until MASTER MUTE is on. Flash/cache stalls while
  // audio is live can be heard as periodic ticks on some ESP32-S3/I2S builds.
  if (configDirty && gMasterMute && (uint32_t)(millis() - lastConfigChange) > 2500) {
    if (storageReady && storageWriteAtomic("/active_tft_v059.json", serializeState())) {
      configDirty = false;
      if (lastPresetPointerClearPending) {
        if (writeNoAutoRestoreMarker(uiPresetSlot)) {
          lastPresetPointerClearPending = false;
          Serial.println("PRESET AUTO-RESTORE DISABLED: newer active edits are now saved.");
        }
      } else if (activePresetSlot >= 1 && activePresetSlot <= 5) {
        const String committedState = serializeState();
        if (writeLastActivePreset(activePresetSlot, committedState, true)) {
          Serial.printf("PRESET AUTO-RESTORE POINTER UPDATED: P%u\n", activePresetSlot);
        }
      }
    } else {
      if ((uint32_t)(millis() - lastActiveSaveLog) > 5000) {
        Serial.println("Warning: local config not saved; check FFat partition/storage.");
        lastActiveSaveLog = millis();
      }
      lastConfigChange = millis();
    }
  }
  if (lastPresetPointerClearPending && !configDirty && gMasterMute && storageReady) {
    if (writeNoAutoRestoreMarker(uiPresetSlot)) {
      lastPresetPointerClearPending = false;
      Serial.println("PRESET AUTO-RESTORE DISABLED: metadata verified.");
    }
  }
  delay(1);
}
