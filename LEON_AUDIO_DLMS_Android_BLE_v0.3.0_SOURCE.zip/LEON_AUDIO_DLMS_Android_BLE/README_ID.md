# LEON AUDIO DLMS Android — v0.3.0

Aplikasi Android native berbasis Kotlin + Jetpack Compose untuk antarmuka pengendali DSP LEON AUDIO. Branding: **LEON AUDIO — by Leon Production**.

## Pembaruan v0.3.0
- Tampilan dashboard dirapikan dengan kartu status, ringkasan 2 input / 4 output, dan alur sinyal.
- Grafik respons frekuensi EQ 9-band yang mengikuti nilai frequency, gain, dan Q pada UI.
- Grafik respons crossover HPF dan LPF yang mengikuti cutoff, slope, dan pilihan keluarga filter.
- Grafik spektrum RTA demo dengan label DEMO yang jelas.
- Versi aplikasi dinaikkan menjadi 0.3.0.

## Fitur antarmuka
- HOME: koneksi BLE, ringkasan DSP 2 IN / 4 OUT, signal flow, grafik respons EQ, dan master mute.
- INPUT: IN1/IN2, gain, dan delay.
- OUTPUT: OUT1–OUT4, gain, phase reverse, mute, HPF, LPF, dan delay.
- DSP → EQ: 9-band EQ, pemilihan Input/Output, frequency, gain, dan Q.
- DSP → X-OVER: Linkwitz-Riley, Butterworth, Bessel; slope 12/24/36/48 dB/oct; HPF/LPF dan grafik respons indikatif.
- DSP → DELAY, COMP, MATRIX, RTA (grafik contoh), dan SYSTEM.
- PRESET: 5 slot P1–P5 dengan SAVE / LOAD / RESET.
- BLE scanner/GATT client dengan UUID pada `BLE_PROTOCOL.md`.

## Grafik dan batasannya
- Kurva EQ dihitung dari parameter yang sedang tampil di aplikasi. Kurva ini adalah visualisasi matematis untuk membantu penyetelan, bukan hasil pengukuran mikrofon/akustik ruangan.
- Kurva crossover merupakan preview indikatif. Respons akhir bergantung pada implementasi filter yang benar-benar digunakan oleh firmware DSP.
- RTA pada versi ini masih berupa data demo statis, bukan analisis audio langsung. Untuk RTA live, firmware ESP32 perlu mengirim bin spektrum/level melalui BLE.

## Build APK melalui GitHub Actions
Project ZIP ini adalah source project, bukan APK. Workflow repository perlu: (1) mengekstrak file ZIP versi terbaru, (2) menggunakan JDK 17, (3) memasang Gradle 8.10.2, (4) menjalankan `gradle --no-daemon assembleDebug`, dan (5) mengunggah `app/build/outputs/apk/debug/*.apk` sebagai Artifact. Karena ZIP ini tidak membawa Gradle Wrapper, workflow harus menggunakan perintah `gradle`, bukan `./gradlew`.

## Status fungsi BLE — penting
Firmware referensi `LEON_AUDIO_DLMS_MINI_v0.9.4_BOOT_LOGO_ONLY.ino` yang disertakan **belum memiliki BLE/GATT server** yang cocok dengan aplikasi ini. Jadi APK bisa dipakai untuk melihat/menguji UI demo, tetapi belum bisa mengubah DSP/audio fisik sampai layanan BLE ditambahkan ke firmware ESP32-S3 dan setiap perintah aplikasi dihubungkan ke parameter DSP.

## Versi dan spesifikasi
- App version: 0.3.0
- Package: `com.leonaudio.dlms`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Teknologi: Kotlin, Jetpack Compose, Material 3
