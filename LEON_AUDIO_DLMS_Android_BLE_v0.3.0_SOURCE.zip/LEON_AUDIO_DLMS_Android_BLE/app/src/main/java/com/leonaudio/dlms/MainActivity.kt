package com.leonaudio.dlms

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090D0B)
private val Panel = Color(0xFF151D19)
private val PanelAlt = Color(0xFF1C2821)
private val Green = Color(0xFF39E879)
private val Muted = Color(0xFF9BAAA1)
private val White = Color(0xFFF1F7F3)
private val Orange = Color(0xFFFFB454)

class MainActivity : ComponentActivity() {
    private lateinit var ble: BleController

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.isNotEmpty() && result.values.all { it }) ble.startScan()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ble = BleController(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Green,
                    secondary = Green,
                    background = Bg,
                    surface = Panel,
                    onPrimary = Color.Black,
                    onBackground = White,
                    onSurface = White
                )
            ) {
                LeonAudioApp(
                    ble = ble,
                    onRequestScan = { requestBlePermissions() }
                )
            }
        }
    }

    private fun requestBlePermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_CONNECT
            )
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        permissionLauncher.launch(permissions)
    }

    override fun onDestroy() {
        if (::ble.isInitialized) ble.disconnect()
        super.onDestroy()
    }
}

@Composable
private fun LeonAudioApp(ble: BleController, onRequestScan: () -> Unit) {
    var page by remember { mutableStateOf("HOME") }
    var dspTab by remember { mutableStateOf("EQ") }
    var inputChannel by remember { mutableIntStateOf(0) }
    var outputChannel by remember { mutableIntStateOf(0) }
    var selectedPreset by remember { mutableIntStateOf(1) }
    var demoMode by remember { mutableStateOf(true) }

    val bleState by ble.state.collectAsState()
    val deviceName by ble.deviceName.collectAsState()
    val connected = bleState == "Terhubung"

    val inputGain = remember { mutableStateListOf(0f, 0f) }
    val inputDelay = remember { mutableStateListOf(0f, 0f) }
    val outputGain = remember { mutableStateListOf(0f, 0f, 0f, 0f) }
    val outputDelay = remember { mutableStateListOf(0f, 0f, 0f, 0f) }
    val outputHpf = remember { mutableStateListOf(35f, 35f, 35f, 35f) }
    val outputLpf = remember { mutableStateListOf(18000f, 18000f, 18000f, 18000f) }
    val outputPhase = remember { mutableStateListOf(false, false, false, false) }
    val outputMute = remember { mutableStateListOf(false, false, false, false) }
    val eqGains = remember { mutableStateListOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f) }
    val route = remember {
        mutableStateListOf(
            mutableStateListOf(true, false, false, false),
            mutableStateListOf(false, true, false, false)
        )
    }
    val compThreshold = remember { mutableFloatStateOf(-18f) }
    val compRatio = remember { mutableFloatStateOf(3f) }
    val compAttack = remember { mutableFloatStateOf(10f) }
    val compRelease = remember { mutableFloatStateOf(100f) }
    var filterType by remember { mutableStateOf("Linkwitz-Riley") }
    var filterSlope by remember { mutableStateOf("24 dB/oct") }
    var eqTarget by remember { mutableStateOf("OUTPUT") }
    var eqChannel by remember { mutableIntStateOf(0) }
    var masterMute by remember { mutableStateOf(false) }
    val eqFreqs = remember { mutableStateListOf(31.5f, 63f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f) }
    val eqQs = remember { mutableStateListOf(1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f) }

    fun send(target: String, ch: Int, param: String, value: Any) {
        if (connected && !demoMode) ble.send(BleProtocol.set(target, ch, param, value))
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                val items = listOf(
                    Triple("HOME", "Home", Icons.Default.Home),
                    Triple("INPUT", "Input", Icons.Default.Input),
                    Triple("OUTPUT", "Output", Icons.Default.GraphicEq),
                    Triple("DSP", "DSP", Icons.Default.Tune),
                    Triple("PRESET", "Preset", Icons.Default.Save)
                )
                items.forEach { item ->
                    NavigationBarItem(
                        selected = page == item.first,
                        onClick = { page = item.first },
                        icon = { Icon(item.third, contentDescription = item.second) },
                        label = { Text(item.second, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green,
                            selectedTextColor = Green,
                            indicatorColor = Color(0xFF26392E),
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 15.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
        ) {
            item {
                Header(
                    connected = connected,
                    onSettings = { page = "SYSTEM"; dspTab = "SYSTEM" }
                )
            }
            item {
                ConnectionCard(
                    state = bleState,
                    deviceName = deviceName,
                    connected = connected,
                    demoMode = demoMode,
                    onScan = onRequestScan,
                    onDisconnect = { ble.disconnect() },
                    onDemoToggle = { demoMode = !demoMode }
                )
            }

            when (page) {
                "HOME" -> {
                    item { SectionTitle("DSP OVERVIEW", "2 INPUT  /  4 OUTPUT  /  48 kHz") }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricCard("INPUT", "2 CH", Modifier.weight(1f))
                            MetricCard("OUTPUT", "4 CH", Modifier.weight(1f))
                            MetricCard("RATE", "48 kHz", Modifier.weight(1f))
                        }
                    }
                    item { SignalFlowCard() }
                    item { EqResponseCard(eqFreqs, eqGains, eqQs) }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("MASTER CONTROL", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Text(if (masterMute) "MUTED" else "ACTIVE", color = if (masterMute) Orange else Green, fontSize = 11.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Master Mute", color = Muted, modifier = Modifier.weight(1f))
                                    Switch(
                                        checked = masterMute,
                                        onCheckedChange = {
                                            masterMute = it
                                            send("master", 0, "mute", it)
                                        }
                                    )
                                }
                                Text("Pengaturan lokal dapat dicoba dalam Demo Mode. Untuk mengubah DSP fisik, firmware ESP32 harus memiliki layanan BLE yang cocok.", color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                }

                "INPUT" -> {
                    item { SectionTitle("INPUT PROCESSING", "PCM1808 • STEREO ADC") }
                    item { ChannelSelector(inputChannel, { inputChannel = it }, 2, "IN") }
                    item {
                        SliderCard("INPUT GAIN", "%.1f dB".format(inputGain[inputChannel]), inputGain[inputChannel], -30f..12f, {
                            inputGain[inputChannel] = it
                        }) {
                            send("input", inputChannel, "gain", inputGain[inputChannel])
                        }
                    }
                    item {
                        SliderCard("INPUT DELAY", "%.2f ms".format(inputDelay[inputChannel]), inputDelay[inputChannel], 0f..300f, {
                            inputDelay[inputChannel] = it
                        }) {
                            send("input", inputChannel, "delay", inputDelay[inputChannel])
                        }
                    }
                    item { InfoCard("INPUT EQ", "Pengaturan 9-band tersedia di menu DSP → EQ. Pilih sumber INPUT untuk mengatur IN1 atau IN2.") }
                }

                "OUTPUT" -> {
                    item { SectionTitle("OUTPUT PROCESSING", "2 × PCM5102 • 4 CHANNEL") }
                    item { ChannelSelector(outputChannel, { outputChannel = it }, 4, "OUT") }
                    item {
                        SliderCard("OUTPUT GAIN", "%.1f dB".format(outputGain[outputChannel]), outputGain[outputChannel], -60f..12f, {
                            outputGain[outputChannel] = it
                        }) {
                            send("output", outputChannel, "gain", outputGain[outputChannel])
                        }
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ToggleCard("PHASE REVERSE", outputPhase[outputChannel], Modifier.weight(1f)) {
                                outputPhase[outputChannel] = it
                                send("output", outputChannel, "phase", it)
                            }
                            Spacer(Modifier.width(8.dp))
                            ToggleCard("MUTE", outputMute[outputChannel], Modifier.weight(1f)) {
                                outputMute[outputChannel] = it
                                send("output", outputChannel, "mute", it)
                            }
                        }
                    }
                    item {
                        SliderCard("HPF FREQUENCY", "${outputHpf[outputChannel].toInt()} Hz", outputHpf[outputChannel], 20f..1000f, {
                            outputHpf[outputChannel] = it
                        }) {
                            send("output", outputChannel, "hpf", outputHpf[outputChannel])
                        }
                    }
                    item {
                        SliderCard("LPF FREQUENCY", "${outputLpf[outputChannel].toInt()} Hz", outputLpf[outputChannel], 1000f..20000f, {
                            outputLpf[outputChannel] = it
                        }) {
                            send("output", outputChannel, "lpf", outputLpf[outputChannel])
                        }
                    }
                    item {
                        SliderCard("OUTPUT DELAY", "%.2f ms".format(outputDelay[outputChannel]), outputDelay[outputChannel], 0f..300f, {
                            outputDelay[outputChannel] = it
                        }) {
                            send("output", outputChannel, "delay", outputDelay[outputChannel])
                        }
                    }
                    item { InfoCard("CROSSOVER", "Jenis filter dan slope dapat diatur pada menu DSP → X-OVER.") }
                }

                "DSP" -> {
                    item { SectionTitle("DSP TOOLS", "PARAMETER CONTROL") }
                    item {
                        ScrollableTabRow(
                            selectedTabIndex = listOf("EQ", "X-OVER", "DELAY", "COMP", "MATRIX", "RTA", "SYSTEM").indexOf(dspTab),
                            containerColor = Bg,
                            contentColor = Green,
                            edgePadding = 0.dp
                        ) {
                            listOf("EQ", "X-OVER", "DELAY", "COMP", "MATRIX", "RTA", "SYSTEM").forEach { tab ->
                                Tab(
                                    selected = dspTab == tab,
                                    onClick = { dspTab = tab },
                                    text = { Text(tab, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    when (dspTab) {
                        "EQ" -> {
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(selected = eqTarget == "INPUT", onClick = {
                                        eqTarget = "INPUT"; eqChannel = eqChannel.coerceAtMost(1)
                                    }, label = { Text("INPUT EQ") })
                                    FilterChip(selected = eqTarget == "OUTPUT", onClick = {
                                        eqTarget = "OUTPUT"; eqChannel = eqChannel.coerceAtMost(3)
                                    }, label = { Text("OUTPUT EQ") })
                                }
                            }
                            item {
                                ChannelSelector(eqChannel, { eqChannel = it },
                                    if (eqTarget == "INPUT") 2 else 4,
                                    if (eqTarget == "INPUT") "IN" else "OUT")
                            }
                            item { Text("9-BAND EQUALIZER", color = Green, fontWeight = FontWeight.Bold) }
                            item { EqResponseCard(eqFreqs, eqGains, eqQs) }
                            item {
                                val freq = listOf("31.5", "63", "125", "250", "500", "1k", "2k", "4k", "8k")
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    eqGains.forEachIndexed { index, gain ->
                                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
                                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text("BAND ${index + 1}", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                SliderCard("FREQUENCY", "${eqFreqs[index].toInt()} Hz", eqFreqs[index], 20f..20000f, {
                                                    eqFreqs[index] = it
                                                }) {
                                                    send(eqTarget.lowercase(), eqChannel, "eq${index + 1}_freq", eqFreqs[index])
                                                }
                                                SliderCard("GAIN", "%.1f dB".format(gain), gain, -12f..12f, {
                                                    eqGains[index] = it
                                                }) {
                                                    send(eqTarget.lowercase(), eqChannel, "eq${index + 1}_gain", eqGains[index])
                                                }
                                                SliderCard("Q FACTOR", "%.2f".format(eqQs[index]), eqQs[index], 0.1f..10f, {
                                                    eqQs[index] = it
                                                }) {
                                                    send(eqTarget.lowercase(), eqChannel, "eq${index + 1}_q", eqQs[index])
                                                }
                                                Text("Center reference: ${freq[index]} Hz", color = Muted, fontSize = 9.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        "X-OVER" -> {
                            item { ChannelSelector(outputChannel, { outputChannel = it }, 4, "OUT") }
                            item { FilterSelector(filterType, filterSlope, onType = { filterType = it }, onSlope = { filterSlope = it }) }
                            item { CrossoverResponseCard(outputHpf[outputChannel], outputLpf[outputChannel], filterSlope, filterType) }
                            item {
                                SliderCard("HPF", "${outputHpf[outputChannel].toInt()} Hz", outputHpf[outputChannel], 20f..1000f, {
                                    outputHpf[outputChannel] = it
                                }) {
                                    send("output", outputChannel, "hpf", outputHpf[outputChannel])
                                }
                            }
                            item {
                                SliderCard("LPF", "${outputLpf[outputChannel].toInt()} Hz", outputLpf[outputChannel], 1000f..20000f, {
                                    outputLpf[outputChannel] = it
                                }) {
                                    send("output", outputChannel, "lpf", outputLpf[outputChannel])
                                }
                            }
                            item {
                                Button(onClick = {
                                    send("output", outputChannel, "filter_type", filterType)
                                    send("output", outputChannel, "filter_slope", filterSlope)
                                }, modifier = Modifier.fillMaxWidth()) { Text("APPLY CROSSOVER") }
                            }
                        }
                        "DELAY" -> {
                            item { ChannelSelector(outputChannel, { outputChannel = it }, 4, "OUT") }
                            item {
                                SliderCard("OUTPUT DELAY", "%.2f ms".format(outputDelay[outputChannel]), outputDelay[outputChannel], 0f..300f, {
                                    outputDelay[outputChannel] = it
                                }) {
                                    send("output", outputChannel, "delay", outputDelay[outputChannel])
                                }
                            }
                            item { InfoCard("DELAY RANGE", "0–300 ms • Pengaturan dikirim ketika slider dilepas.") }
                        }
                        "COMP" -> {
                            item { Text("COMPRESSOR / DYNAMICS", color = Green, fontWeight = FontWeight.Bold) }
                            item {
                                SliderCard("THRESHOLD", "%.1f dB".format(compThreshold.floatValue), compThreshold.floatValue, -60f..0f, {
                                    compThreshold.floatValue = it
                                }) { send("dynamics", outputChannel, "threshold", compThreshold.floatValue) }
                            }
                            item {
                                SliderCard("RATIO", "%.1f : 1".format(compRatio.floatValue), compRatio.floatValue, 1f..20f, {
                                    compRatio.floatValue = it
                                }) { send("dynamics", outputChannel, "ratio", compRatio.floatValue) }
                            }
                            item {
                                SliderCard("ATTACK", "%.1f ms".format(compAttack.floatValue), compAttack.floatValue, 0.1f..100f, {
                                    compAttack.floatValue = it
                                }) { send("dynamics", outputChannel, "attack", compAttack.floatValue) }
                            }
                            item {
                                SliderCard("RELEASE", "%.0f ms".format(compRelease.floatValue), compRelease.floatValue, 10f..1000f, {
                                    compRelease.floatValue = it
                                }) { send("dynamics", outputChannel, "release", compRelease.floatValue) }
                            }
                        }
                        "MATRIX" -> {
                            item { Text("INPUT → OUTPUT ROUTING", color = Green, fontWeight = FontWeight.Bold) }
                            item { MatrixCard(route) { input, output, enabled ->
                                route[input][output] = enabled
                                send("matrix", input, "out${output + 1}", enabled)
                            } }
                        }
                        "RTA" -> {
                            item { RtaGraphCard() }
                            item { InfoCard("RTA LIVE", "Mode ini masih berupa grafik demo. RTA aktual akan aktif setelah firmware mengirim data spektrum melalui BLE.") }
                        }
                        "SYSTEM" -> {
                            item { SystemInfoCard(bleState, deviceName) }
                        }
                    }
                }

                "PRESET" -> {
                    item { SectionTitle("PROGRAM PRESET", "5 MEMORY SLOTS") }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            (1..5).forEach { slot ->
                                FilterChip(
                                    selected = selectedPreset == slot,
                                    onClick = { selectedPreset = slot },
                                    label = { Text("P$slot") }
                                )
                            }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("PROGRAM $selectedPreset", color = Green, fontWeight = FontWeight.Bold)
                                Text("Simpan atau panggil seluruh konfigurasi DSP melalui slot preset.", color = Muted, fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { if (connected && !demoMode) ble.send(BleProtocol.preset("save", selectedPreset)) },
                                        modifier = Modifier.weight(1f)
                                    ) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(5.dp)); Text("SAVE") }
                                    OutlinedButton(
                                        onClick = { if (connected && !demoMode) ble.send(BleProtocol.preset("load", selectedPreset)) },
                                        modifier = Modifier.weight(1f)
                                    ) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(5.dp)); Text("LOAD") }
                                }
                                OutlinedButton(
                                    onClick = { if (connected && !demoMode) ble.send(BleProtocol.preset("reset", selectedPreset)) },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("RESET SLOT") }
                            }
                        }
                    }
                    item { InfoCard("PENTING", "Pada versi tampilan ini tombol preset mengirim perintah BLE jika perangkat terhubung. Fungsi simpan/panggil fisik aktif setelah firmware BLE terintegrasi.") }
                }
            }
            item { FooterStatus(connected, demoMode) }
        }
    }
}

@Composable
private fun Header(connected: Boolean, onSettings: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("LEON AUDIO", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("DIGITAL LOUDSPEAKER MANAGEMENT  •  by Leon Production", color = Muted, fontSize = 10.sp)
        }
        Surface(color = if (connected) Color(0xFF173B27) else PanelAlt, shape = RoundedCornerShape(20.dp)) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bluetooth, null, tint = if (connected) Green else Muted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text(if (connected) "ONLINE" else "OFFLINE", color = if (connected) Green else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, null, tint = Muted) }
    }
}

@Composable
private fun ConnectionCard(
    state: String,
    deviceName: String,
    connected: Boolean,
    demoMode: Boolean,
    onScan: () -> Unit,
    onDisconnect: () -> Unit,
    onDemoToggle: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DEVICE CONNECTION", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(if (connected) "CONNECTED" else "NOT CONNECTED", color = if (connected) Green else Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (connected) deviceName else "LEON AUDIO DLMS", color = White, fontWeight = FontWeight.SemiBold)
                    Text(state, color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.BluetoothSearching, null, tint = if (connected) Green else Muted, modifier = Modifier.size(28.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onScan, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Search, null); Spacer(Modifier.width(5.dp)); Text("SCAN BLE")
                }
                OutlinedButton(onClick = onDisconnect) { Text("DISCONNECT") }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Demo UI", color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Switch(checked = demoMode, onCheckedChange = { onDemoToggle() })
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(subtitle, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
        Column(Modifier.padding(11.dp)) {
            Text(label, color = Muted, fontSize = 9.sp)
            Text(value, color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
private fun SignalFlowCard() {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("SIGNAL FLOW", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SignalBlock("IN 1", "ADC L", Modifier.weight(1f))
                Text("→", color = Green, fontWeight = FontWeight.Bold)
                SignalBlock("DSP", "EQ / XO", Modifier.weight(1f))
                Text("→", color = Green, fontWeight = FontWeight.Bold)
                SignalBlock("OUT 1–4", "DAC", Modifier.weight(1f))
            }
            Text("ESP32-S3  •  PCM1808  •  2 × PCM5102", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SignalBlock(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier.background(PanelAlt, RoundedCornerShape(10.dp)).padding(vertical = 11.dp, horizontal = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(subtitle, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun ChannelSelector(selected: Int, onSelect: (Int) -> Unit, count: Int, prefix: String) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("CHANNEL SELECT", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(count) { index ->
                FilterChip(
                    selected = selected == index,
                    onClick = { onSelect(index) },
                    label = { Text("$prefix ${index + 1}") }
                )
            }
        }
    }
}

@Composable
private fun SliderCard(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    onCommit: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(valueLabel, color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Slider(
                value = value.coerceIn(range),
                onValueChange = onValueChange,
                valueRange = range,
                onValueChangeFinished = onCommit
            )
        }
    }
}

@Composable
private fun ToggleCard(title: String, checked: Boolean, modifier: Modifier = Modifier, onChecked: (Boolean) -> Unit) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChecked)
        }
    }
}

@Composable
private fun FilterSelector(type: String, slope: String, onType: (String) -> Unit, onSlope: (String) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("FILTER TYPE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("Linkwitz-Riley", "Butterworth", "Bessel").forEach { value ->
                    FilterChip(selected = type == value, onClick = { onType(value) },
                        label = { Text(when (value) { "Linkwitz-Riley" -> "LR"; else -> value }, fontSize = 10.sp) })
                }
            }
            Text("SLOPE", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                listOf("12 dB/oct", "24 dB/oct", "36 dB/oct", "48 dB/oct").forEach { value ->
                    FilterChip(selected = slope == value, onClick = { onSlope(value) },
                        label = { Text(value.substringBefore(" "), fontSize = 10.sp) })
                }
            }
            Text("$type • $slope", color = Green, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun MatrixCard(routes: SnapshotStateList<SnapshotStateList<Boolean>>, onChange: (Int, Int, Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("SOURCE", color = Muted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                (1..4).forEach { Text("O$it", color = Green, fontSize = 10.sp, modifier = Modifier.weight(0.7f)) }
            }
            repeat(2) { input ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("IN${input + 1}", color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    repeat(4) { output ->
                        Box(Modifier.weight(0.7f), contentAlignment = Alignment.Center) {
                            Checkbox(
                                checked = routes[input][output],
                                onCheckedChange = { onChange(input, output, it) },
                                colors = CheckboxDefaults.colors(checkedColor = Green, uncheckedColor = Muted)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SystemInfoCard(connection: String, deviceName: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("SYSTEM INFORMATION", color = Green, fontWeight = FontWeight.Bold)
            InfoRow("Product", "LEON AUDIO DLMS")
            InfoRow("Controller", "ESP32-S3 DevKitC-1 N16R8")
            InfoRow("ADC", "PCM1808 • 2 CH")
            InfoRow("DAC", "2 × PCM5102 • 4 CH")
            InfoRow("Sample rate", "48 kHz")
            InfoRow("Bluetooth", connection)
            InfoRow("Device", deviceName)
            InfoRow("App", "Android Native 0.3.0")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(value, color = White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun InfoCard(title: String, message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = PanelAlt), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(message, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun FooterStatus(connected: Boolean, demoMode: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(if (connected) Green else Orange, RoundedCornerShape(50)))
        Spacer(Modifier.width(6.dp))
        Text(
            when {
                connected -> "BLE LINK READY"
                demoMode -> "DEMO MODE • BELUM TERHUBUNG KE DSP"
                else -> "OFFLINE • CARI PERANGKAT BLE"
            },
            color = Muted,
            fontSize = 9.sp
        )
    }
}
