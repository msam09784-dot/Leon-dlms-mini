package com.leonaudio.dlms

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

private val GraphPanel = Color(0xFF0B1210)
private val GraphGrid = Color(0xFF26352E)
private val GraphGreen = Color(0xFF52F28B)
private val GraphCyan = Color(0xFF54D6E8)
private val GraphOrange = Color(0xFFFFB454)
private val GraphText = Color(0xFF9BAAA1)

@Composable
fun EqResponseCard(
    frequencies: List<Float>,
    gains: List<Float>,
    qs: List<Float>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151D19)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("FREQUENCY RESPONSE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("9-band parametric EQ • preview", color = GraphText, fontSize = 10.sp)
                }
                Text("dB", color = GraphGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Canvas(
                Modifier.fillMaxWidth().height(178.dp)
                    .background(GraphPanel, RoundedCornerShape(10.dp))
            ) {
                val left = 8.dp.toPx()
                val right = size.width - 8.dp.toPx()
                val top = 8.dp.toPx()
                val bottom = size.height - 8.dp.toPx()
                val plotWidth = right - left
                val plotHeight = bottom - top

                for (i in 0..6) {
                    val y = top + plotHeight * i / 6f
                    drawLine(GraphGrid, Offset(left, y), Offset(right, y), 1.dp.toPx())
                }
                val ticks = listOf(20f, 50f, 100f, 500f, 1000f, 5000f, 10000f, 20000f)
                ticks.forEach { f ->
                    val x = left + (ln(f / 20f) / ln(1000f)) * plotWidth
                    drawLine(GraphGrid.copy(alpha = 0.72f), Offset(x, top), Offset(x, bottom), 1.dp.toPx())
                }
                val zeroY = top + plotHeight * 0.5f
                drawLine(GraphGreen.copy(alpha = 0.5f), Offset(left, zeroY), Offset(right, zeroY), 1.2.dp.toPx())

                val path = Path()
                val samples = 240
                for (i in 0..samples) {
                    val ratio = i / samples.toFloat()
                    val frequency = 20f * exp(ln(1000f) * ratio)
                    var db = 0.0
                    for (band in 0 until minOf(9, frequencies.size, gains.size, qs.size)) {
                        val center = frequencies[band].coerceAtLeast(20f)
                        val q = qs[band].coerceIn(0.1f, 10f)
                        val sigma = (0.34f / sqrt(q)).coerceIn(0.075f, 0.9f)
                        val distance = ln(frequency / center) / sigma
                        db += gains[band] * exp(-0.5 * distance * distance)
                    }
                    val response = db.toFloat().coerceIn(-18f, 18f)
                    val x = left + ratio * plotWidth
                    val y = top + ((18f - response) / 36f) * plotHeight
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, GraphGreen.copy(alpha = 0.16f), style = Stroke(width = 8.dp.toPx()))
                drawPath(path, GraphGreen, style = Stroke(width = 2.5.dp.toPx()))

                for (band in 0 until minOf(9, frequencies.size, gains.size)) {
                    val f = frequencies[band].coerceIn(20f, 20000f)
                    val x = left + (ln(f / 20f) / ln(1000f)) * plotWidth
                    drawCircle(GraphCyan, radius = 3.dp.toPx(), center = Offset(x, zeroY))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("20 Hz", "100", "1k", "10k", "20k").forEach {
                    Text(it, color = GraphText, fontSize = 9.sp)
                }
            }
            Text("Kurva dihitung dari nilai EQ yang sedang dipilih. Ini preview visual, bukan hasil ukur akustik.", color = GraphText, fontSize = 9.sp)
        }
    }
}

@Composable
fun CrossoverResponseCard(
    hpfHz: Float,
    lpfHz: Float,
    slope: String,
    filterType: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151D19)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text("CROSSOVER RESPONSE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("$filterType  •  $slope", color = GraphText, fontSize = 10.sp)
            Canvas(
                Modifier.fillMaxWidth().height(168.dp)
                    .background(GraphPanel, RoundedCornerShape(10.dp))
            ) {
                val left = 8.dp.toPx()
                val right = size.width - 8.dp.toPx()
                val top = 8.dp.toPx()
                val bottom = size.height - 8.dp.toPx()
                val plotWidth = right - left
                val plotHeight = bottom - top
                for (i in 0..4) {
                    val y = top + plotHeight * i / 4f
                    drawLine(GraphGrid, Offset(left, y), Offset(right, y), 1.dp.toPx())
                }
                for (i in 0..6) {
                    val x = left + plotWidth * i / 6f
                    drawLine(GraphGrid.copy(alpha = 0.65f), Offset(x, top), Offset(x, bottom), 1.dp.toPx())
                }

                val slopeNumber = slope.substringBefore(" ").toFloatOrNull() ?: 24f
                val order = (slopeNumber / 6f).coerceIn(2f, 8f)
                // The selected filter family changes the preview shape slightly; firmware remains authoritative.
                val shapeFactor = when (filterType) {
                    "Bessel" -> 0.78f
                    "Butterworth" -> 1.08f
                    else -> 1f
                }
                val effectiveOrder = order * shapeFactor
                fun attenuation(frequency: Float, cutoff: Float, highPass: Boolean): Float {
                    val logRatio = ln((frequency / cutoff.coerceAtLeast(20f)).toDouble())
                    val exponent = if (highPass) -2.0 * effectiveOrder * logRatio else 2.0 * effectiveOrder * logRatio
                    val term = exp(exponent.coerceIn(-50.0, 50.0))
                    return (-10.0 * ln(1.0 + term) / ln(10.0)).toFloat().coerceIn(-48f, 0f)
                }
                fun yFor(db: Float): Float = top + ((3f - db.coerceIn(-48f, 3f)) / 51f) * plotHeight
                val hp = Path()
                val lp = Path()
                val samples = 220
                for (i in 0..samples) {
                    val ratio = i / samples.toFloat()
                    val frequency = 20f * exp(ln(1000f) * ratio)
                    val x = left + ratio * plotWidth
                    val hpY = yFor(attenuation(frequency, hpfHz, true))
                    val lpY = yFor(attenuation(frequency, lpfHz, false))
                    if (i == 0) { hp.moveTo(x, hpY); lp.moveTo(x, lpY) }
                    else { hp.lineTo(x, hpY); lp.lineTo(x, lpY) }
                }
                drawPath(hp, GraphGreen.copy(alpha = 0.16f), style = Stroke(width = 8.dp.toPx()))
                drawPath(hp, GraphGreen, style = Stroke(width = 2.5.dp.toPx()))
                drawPath(lp, GraphCyan.copy(alpha = 0.16f), style = Stroke(width = 8.dp.toPx()))
                drawPath(lp, GraphCyan, style = Stroke(width = 2.5.dp.toPx()))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(7.dp).background(GraphGreen, RoundedCornerShape(50)))
                    Text("HPF ${hpfHz.toInt()} Hz", color = GraphGreen, fontSize = 10.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.size(7.dp).background(GraphCyan, RoundedCornerShape(50)))
                    Text("LPF ${lpfHz.toInt()} Hz", color = GraphCyan, fontSize = 10.sp)
                }
            }
            Text("Preview karakteristik filter. Respons aktual bergantung implementasi filter di firmware DSP.", color = GraphText, fontSize = 9.sp)
        }
    }
}

@Composable
fun RtaGraphCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151D19)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("REAL-TIME ANALYZER", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Spectrum visualization", color = GraphText, fontSize = 10.sp)
                }
                Text("DEMO", color = GraphOrange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Canvas(
                Modifier.fillMaxWidth().height(178.dp)
                    .background(GraphPanel, RoundedCornerShape(10.dp))
            ) {
                val left = 8.dp.toPx()
                val right = size.width - 8.dp.toPx()
                val top = 8.dp.toPx()
                val bottom = size.height - 8.dp.toPx()
                for (i in 1..4) {
                    val y = top + (bottom - top) * i / 5f
                    drawLine(GraphGrid, Offset(left, y), Offset(right, y), 1.dp.toPx())
                }
                val count = 48
                val gap = 2.dp.toPx()
                val width = (right - left - gap * (count - 1)) / count
                repeat(count) { i ->
                    val x = i / (count - 1f)
                    val peakA = exp(-((x - 0.24f) / 0.12f).let { it * it } * 0.5f)
                    val peakB = 0.72f * exp(-((x - 0.66f) / 0.17f).let { it * it } * 0.5f)
                    val ripple = 0.08f * (0.5f + 0.5f * sin(i * 1.73f))
                    val level = (0.08f + 0.58f * peakA + 0.42f * peakB + ripple).coerceIn(0.05f, 0.96f)
                    val barHeight = (bottom - top) * level
                    val color = when {
                        level > 0.72f -> GraphOrange
                        level > 0.42f -> GraphCyan
                        else -> GraphGreen
                    }
                    drawRoundRect(
                        color = color,
                        topLeft = Offset(left + i * (width + gap), bottom - barHeight),
                        size = Size(width, barHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("20 Hz", "100", "1k", "10k", "20k").forEach {
                    Text(it, color = GraphText, fontSize = 9.sp)
                }
            }
            Text("Grafik contoh, belum membaca sinyal audio langsung. RTA live memerlukan data spektrum dari firmware ESP32.", color = GraphText, fontSize = 9.sp)
        }
    }
}
