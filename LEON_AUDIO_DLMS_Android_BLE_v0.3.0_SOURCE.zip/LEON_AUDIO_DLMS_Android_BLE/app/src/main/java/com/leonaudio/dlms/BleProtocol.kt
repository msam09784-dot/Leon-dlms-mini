package com.leonaudio.dlms
import java.util.UUID

/** LEON AUDIO BLE protocol v1. Must match the ESP32-S3 GATT server. */
object BleProtocol {
    val SERVICE_UUID: UUID = UUID.fromString("8d7f1000-6b5a-4c2d-9e10-4f2a6c8b0001")
    val WRITE_UUID: UUID = UUID.fromString("8d7f1001-6b5a-4c2d-9e10-4f2a6c8b0001")
    val NOTIFY_UUID: UUID = UUID.fromString("8d7f1002-6b5a-4c2d-9e10-4f2a6c8b0001")
    val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    fun set(target: String, channel: Int, parameter: String, value: Any) =
        """{"cmd":"set","target":"$target","ch":$channel,"param":"$parameter","value":$value}"""
    fun preset(action: String, slot: Int) =
        """{"cmd":"preset","action":"$action","slot":$slot}"""
    const val GET_STATUS = """{"cmd":"status"}"""
    const val GET_CONFIG = """{"cmd":"get_config"}"""
}
