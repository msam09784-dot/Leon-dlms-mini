package com.leonaudio.dlms

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Build
import android.os.ParcelUuid
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class BleController(context: Context) {
    private val appContext = context.applicationContext
    private val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val scanner get() = adapter.bluetoothLeScanner
    private val _state = MutableStateFlow("Belum terhubung")
    val state: StateFlow<String> = _state
    private val _deviceName = MutableStateFlow("—")
    val deviceName: StateFlow<String> = _deviceName
    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            // Scan is filtered by the unique LEON AUDIO service UUID, so the
            // matching result is the intended DSP even when its advertised name is hidden.
            stopScan()
            connect(result.device)
        }
        override fun onScanFailed(errorCode: Int) { _state.value = "Scan gagal: $errorCode" }
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        if (!adapter.isEnabled) { _state.value = "Bluetooth HP belum aktif"; return }
        _state.value = "Mencari LEON AUDIO…"
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(BleProtocol.SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanner.startScan(listOf(filter), settings, scanCallback)
    }

    @SuppressLint("MissingPermission")
    fun stopScan() { try { scanner.stopScan(scanCallback) } catch (_: Exception) {} }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        _state.value = "Menghubungkan…"
        _deviceName.value = try { device.name ?: "LEON AUDIO DLMS" } catch (_: Exception) { "LEON AUDIO DLMS" }
        gatt?.close()
        gatt = device.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                _state.value = "Koneksi gagal ($status)"
                g.close()
            } else if (newState == BluetoothProfile.STATE_CONNECTED) {
                _state.value = "Terhubung — mencari layanan"
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                _state.value = "Terputus"
                writeChar = null
                g.close()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val service = g.getService(BleProtocol.SERVICE_UUID)
            writeChar = service?.getCharacteristic(BleProtocol.WRITE_UUID)
            if (writeChar == null) {
                _state.value = "Firmware belum menyediakan layanan LEON AUDIO BLE"
            } else {
                _state.value = "Terhubung"
                val notify = service?.getCharacteristic(BleProtocol.NOTIFY_UUID)
                if (notify != null) {
                    g.setCharacteristicNotification(notify, true)
                    val descriptor = notify.getDescriptor(BleProtocol.CCCD_UUID)
                    if (descriptor != null) {
                        if (Build.VERSION.SDK_INT >= 33) {
                            g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                        } else {
                            @Suppress("DEPRECATION")
                            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                            @Suppress("DEPRECATION")
                            g.writeDescriptor(descriptor)
                        }
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun send(json: String): Boolean {
        val g = gatt ?: return false
        val characteristic = writeChar ?: return false
        val payload = json.toByteArray(Charsets.UTF_8)
        if (payload.size > 180) return false
        return if (Build.VERSION.SDK_INT >= 33) {
            g.writeCharacteristic(characteristic, payload, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            characteristic.value = payload
            @Suppress("DEPRECATION")
            characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            @Suppress("DEPRECATION")
            g.writeCharacteristic(characteristic)
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        stopScan()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        writeChar = null
        _state.value = "Belum terhubung"
        _deviceName.value = "—"
    }
}
